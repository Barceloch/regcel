/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef ENTITY_H
#define ENTITY_H
#include <QString>
#include <QList>
#include <iostream>
#include "types.h"

namespace Model
{
    namespace Domain
    {
        class Entity
        {
            friend std::ostream &operator<<(std::ostream &os, const Entity &entity);
        public:
            Entity(int id = NO_ID);
            Entity(const Entity &entity);
            Entity &operator=(const Entity &entity);
            bool operator==(const Entity &entity) const;
            bool operator!=(const Entity &entity) const;

            void setId(int id);
            int id() const;

            void setFolio(int folio);
            int folio() const;

            void setName(const QString &name);
            const QString &name() const;

            void setCountry(const QString &country);
            const QString &country() const;

            void setProvince(const QString &province);
            const QString &province() const;

            void setCity(const QString &city);
            const QString &city() const;

            void setAddress(const QString &address);
            const QString &address() const;

            void setPc(const QString &pc);
            const QString &pc() const;

            void setTelephone(int telephone);
            int telephone() const;

            void setMobile(int mobile);
            int mobile() const;

            void setFax(int fax);
            int fax() const;

            void setEmail(const QString &email);
            const QString &email() const;

            void setWeb(const QString &web);
            const QString &web() const;

        protected:
            int _id;
            int _folio;
            QString _name;
            QString _country;
            QString _province;
            QString _city;
            QString _address;
            QString _pc;
            int _telephone;
            int _mobile;
            int _fax;
            QString _email;
            QString _web;

        };
    }
}

#endif // ENTITY_H
