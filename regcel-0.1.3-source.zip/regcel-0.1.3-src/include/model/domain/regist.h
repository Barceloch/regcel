/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef REGIST_H
#define REGIST_H
#include <QDate>
#include <QTime>
#include <QString>
#include <iostream>
#include "types.h"

namespace Model
{
    namespace Domain
    {
        class Entity;

        class Regist
        {
            friend std::ostream &operator<<(std::ostream &os, const Regist &regist);
        public:
            Regist(int id = NO_ID);

            Regist(const Regist &regist);
            ~Regist();
            Regist &operator=(const Regist &regist);

            bool operator==(const Regist &regist) const;
            bool operator!=(const Regist &regist) const;
            // SET ID
            void setId(int id);
            int id() const;

            void setEntity(Entity *entity);
            Entity *entity() const;

            void setEntityFolio(int entityFolio);
            int entityFolio() const;

            void setEntityName(const QString &entityName);
            const QString &entityName() const;

            //SET DATE
            void setDate(const QDate &date);
            const QDate &date() const;
            //SET TIME
            void setTime(const QTime &time);
            const QTime &time() const;
            //SET LECT I
            void setLectI(double lecti);
            double lecti() const;
            //SET LECT F
            void setLectF(double lectf);
            double lectf() const;
            //SET Kw/h
            void setKwh(double kwh);
            double kwh() const;
            //SET IMPORT
            void setImport(double import);
            double import() const;

        private:
            int _id;
            Entity *_entity;
            int _entityFolio;
            QString _entityName;
            QDate _date;
            QTime _time;
            double _lecti;
            double _lectf;
            double _kwh;
            double _import;

        };
    }
}

#endif // REGIST_H
