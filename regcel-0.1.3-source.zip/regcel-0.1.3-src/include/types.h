/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef TYPES_H
#define TYPES_H

// Maximum Authentication Attempts.
#define MAX_AUTH_ATTEMPTS 3

// Maximum Decimal Number used on money, tax and weight units.
#define MAX_MONEY_PRECISION  2
#define MAX_TAX_PRECISION    2
#define MAX_WEIGHT_PRECISION 3

// Maximum Value used on debt and delay payments.
#define MAX_DEBT  999999
#define MAX_DELAY 999

// Maximum Value for database port.
#define MAX_PORT 65535

// Time and Date Format
#define DATE_FORMAT "yyyy-MM-dd"
//#define DATE_FORMAT "dd/MM/yyyy"
#define TIME_FORMAT "hh:mm ap"


// ID doesn't assigned yet.
#define NO_ID -1
#define IS_NEW(id) (id == NO_ID)

namespace View
{
    namespace Invoicing
    {
        typedef enum ColumnRegistEnum
        {
            ColumnRegistId,
            ColumnRegistEntityFolio,
            ColumnRegistEntityName,
            ColumnRegistDate,
            ColumnRegistTime,
            ColumnRegistLectI,
            ColumnRegistLectF,
            ColumnRegistKwh,
            ColumnRegistImport,
            ColumnRegistCount
        } ColumnRegist;
    }
    namespace Management
    {
        typedef enum ColumnRegistEnum
        {
            ColumnRegistId,
            ColumnRegistEntityFolio,
            ColumnRegistEntityName,
            ColumnRegistDate,
            ColumnRegistTime,
            ColumnRegistLectI,
            ColumnRegistLectF,
            ColumnRegistKwh,
            ColumnRegistImport,
            ColumnRegistCount
        } ColumnRegist;


        typedef enum ColumnRangeEnum
        {
            ColumnRangeId,
            //ColumnRangeRateId,
            ColumnRangeFromNumber,
            ColumnRangeToNumber,
            ColumnRangePrice,
            ColumnRangeCount
        } ColumnRange;

        typedef enum DirRangeEditingEnum
        {
            BackRange = -1,
            NextRange = 1
        } DirRangeEditing;

        typedef enum ColumnEntityEnum
        {
            ColumnEntityId,
            ColumnEntityName,
            ColumnEntityFolio,
            ColumnEntityCount
        } ColumnEntity;

        typedef enum ColumnRateEnum
        {
            ColumnRateId,
            ColumnRateName,
            ColumnRateCount
        } ColumnRate;

       typedef enum SelectorBehaviorEnum
       {
            SelectOnly,
            CreateAndSelect
       } SelectorBehavior; 

    }
}

namespace Model
{

    namespace Management
    {
        typedef enum SearchModeEnum
        {
            SearchByTypeOnly = 0x00,
            SearchByDateRange = 0x01,
            SearchByEntity = 0x02,
            SearchByTotalRange = 0x04,
            SearchByState = 0x08,
            SearchByAllParameters = 0x15
        } SearchMode;

        typedef int SearchFlag;
    }
}

namespace Persistence
{
    typedef enum DBMSTypeEnum
    {
        SQLITE
    } DBMSType;
}

#endif // TYPES_H
