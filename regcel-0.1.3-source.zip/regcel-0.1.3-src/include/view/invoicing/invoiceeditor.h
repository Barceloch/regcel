/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef INVOICEEDITOR_H
#define INVOICEEDITOR_H

#include <QWidget>

#define INVOICE_EDITOR_MINIMUM_WIDTH 830
#define INVOICE_EDITOR_MINIMUM_HEIGHT 500

QT_BEGIN_NAMESPACE
class QLabel;
class QLineEdit;
class QTextEdit;
class QTableWidget;
class QTableView;
class QComboBox;
class QCheckBox;
class QDateEdit;
class QPushButton;
class QTextDocument;
class QPrinter;
QT_END_NAMESPACE

namespace Model
{
    namespace Domain
    {
        class Entity;
        class Regist;
        class Rate;
    }
}

namespace View
{

    namespace Management
    {
        class RegistModel; 
    }
    namespace Invoicing
    {

        class InvoiceEditor : public QWidget
        {
            Q_OBJECT

        public:
            InvoiceEditor(QWidget *parent = 0);

        public slots:
            //Print
            void printInvoice();
            void printInvoicePreview();
            void exportInvoiceToPdf();

        protected:
            void closeEvent(QCloseEvent *event);
        signals:
            void finished();
            void enablePrint();
            void disablePrint();
        private slots:
            void rowSelectionChanged();
            void insertRegist();  
            void removeRegist();  
            //Print
            void printPreview(QPrinter *);
            void printEnabled();

            void selectedEntity();
            void detailEntity();

            void selectRate();
            void selectedRate();
            void detailRate();

            void importANDkwhTotals();
            void calculateImport(double kwh, Model::Domain::Rate *rate);
        private:
            void createWidgets();
            void createEntityWidgets();
            void createRegistWidgets();  
            void createConnections();
            bool verifyCloseInvoice();

            //Entidad principal
            QLabel *_entityNameLabel;
            QComboBox *_entityComboBox;
            QPushButton *_detailEntityPushButton;
            QCheckBox *_setEntityDefaultCheckBox;

            QLabel *_invoiceDateLabel;
            QDateEdit *_invoiceDateEdit;

            //Tarifa para calcular importe
            QLabel *_rateLabel;
            QComboBox *_rateComboBox;
            QPushButton *_detailRatePushButton;
            QCheckBox *_calImportCheckBox;

            //Agrepar registros por
            QLabel *_entityLabel;
            QComboBox *_entityRegistComboBox;

            QLabel *_beginDateLabel;
            QDateEdit *_beginDateDateEdit;

            QLabel *_endDateLabel;
            QDateEdit *_endDateDateEdit;


            //Registro para facturar
            QTableView *_invoiceTable;
            QLabel *_warnImportLabel;
            QTextEdit *_notes;

            QLabel *_totalKwhLabel;
            QLabel *_totalKwhResultLabel;
            QLabel *_totalImportLabel;
            QLabel *_totalImportResultLabel;

            QPushButton *_printButton;
            QPushButton *_printPreviewButton;
            QPushButton *_exportPdfButton;

            QPushButton *_addButton;
            QPushButton *_deleteButton;
            QPushButton *_closeButton;

            //TEST
            QTextEdit *_testTextEdit;

            Model::Domain::Entity *_entityPrincipal;
            Model::Domain::Entity *_entityRegist; 
            QList<Model::Domain::Regist *> *_invoiceRegists; 
            View::Management::RegistModel *_registModel;
            Model::Domain::Regist *_regist;

            static QString makeHeader(const Model::Domain::Entity &entity, const QDateEdit &date);
            static QString makeRegistTable(const View::Management::RegistModel &registModel);
            static QString makeNotesTable(const QTextEdit &notes);
            static QString makeTotalsTable(const QLabel &totalK, const QLabel &totalI);
            static const QString _css;
        };
    }
}

#endif // INVOICEEDITOR_H
