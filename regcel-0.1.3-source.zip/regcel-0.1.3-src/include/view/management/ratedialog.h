/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef RATEDIALOG_H
#define RATEDIALOG_H

#include <QDialog>
#include <QWidget>
#include "types.h"

QT_BEGIN_NAMESPACE
class QLabel;
class QLineEdit;
class QCheckBox;
class QTextEdit;
class QDialogButtonBox;
class QPushButton;
class QTableView;
class RangesEditor;
QT_END_NAMESPACE

namespace Model
{
    namespace Domain
    {
        class Rate;
    }
}


namespace View
{
    namespace Management
    {
        class RangesEditor;

        class RateDialog : public QDialog
        {
            Q_OBJECT
        public:
            RateDialog(Model::Domain::Rate *rate, int rateId, bool showR, QWidget *parent = 0);
            void done(int result);
        private slots:
            void rateModified(bool modified = true);
            void moreOf();
        private:
            void createWidgets();
            void createRangesWidgets();
            void createConnections();
            void loadRate();
            void saveRate();
            bool isSaveable();
            bool itemsEnable();

            QLabel *_idLabel;
            QLineEdit *_idLineEdit;

            QLabel *_nameLabel;
            QLineEdit *_nameLineEdit;

            QLabel *_descriptionLabel;
            QTextEdit *_descriptionTextEdit;

            RangesEditor *_rangesEditor;

            QLabel *_moreofLabel;
            QLineEdit *_moreofLineEdit;

            QLabel *_priceLabel;
            QLineEdit *_priceLineEdit;

            QPushButton *_saveButton;
            QPushButton *_cancelButton;

            Model::Domain::Rate *_rate;
            int _precisionMoney;
            int _rateId;
            int _rateIndex;
            bool _showR;
        };
    }
}
#endif // RATEDIALOG_H
