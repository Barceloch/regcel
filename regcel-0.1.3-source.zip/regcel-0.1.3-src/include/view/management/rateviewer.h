/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef RATEVIEWER_H
#define RATEVIEWER_H
#define RATE_VIEWER_MINIMUM_WIDTH        300
#define COLUMN_RANGE_ID_WIDTH              50
#define COLUMN_RANGE_FROMNUMBER_WIDTH      75
#define COLUMN_RANGE_TONUMBER_WIDTH        75
#define COLUMN_RANGE_PRICE_WIDTH           75

#include "range.h"
#include "types.h"
#include <QDialog>

QT_BEGIN_NAMESPACE
class QDialogButtonBox;
class QVBoxLayout;
class QPushButton;
class QTableView;
class QLineEdit;
class QLabel;
QT_END_NAMESPACE

namespace View
{
    namespace Management
    {
        class RangeModel;

        class RateViewer : public QDialog
        {
            Q_OBJECT
        public:
            RateViewer(Model::Domain::Rate *rate, QWidget *parent = 0);

        private:
            void createWidgets();
            void createRangeWidgets();
            void createConnections();

            RangeModel *_rangeModel;
            QTableView *_rangesTableView;
            QPushButton *_closeButton;

            QLabel *_moreOfLabel;
            QLineEdit *_moreOf;

            QLabel *_moreOfPriceLabel;
            QLineEdit *_moreOfPrice;

            int _precisionMoney;
            Model::Domain::Rate *_rate;
            //int _rateId;
          };
      }
}
#endif // RATEVIEWER_H
