/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef REGISTDIALOG_H
#define REGISTDIALOG_H
#include <QDialog>

QT_BEGIN_NAMESPACE
class QGroupBox;
class QLabel;
class QLineEdit;
class QCheckBox;
class QComboBox;
class QTextEdit;
class QDateEdit;
class QTimeEdit;
class QLCDNumber;
class QPushButton;
QT_END_NAMESPACE

namespace Model
{
    namespace Domain
    {
        class Regist;
        class Rate;
    }
}

namespace View
{
    namespace Management
    {
        class RangeModel;
        class RegistDialog : public QDialog
        {
            Q_OBJECT
        public:
            RegistDialog(Model::Domain::Regist *regist, QWidget *parent = 0);
            void done(int result);
        private slots:
            void registModified(bool modified = true);
            void on_lectiLabel_textChanged();
            void on_lectfLabel_textChanged();
            void selectRate();
            void selectedRate();
            void detailRate();
            void selectEntity();
            void detailEntity();
            void calculateKwh();
            void calculateImport(double kwh, Model::Domain::Rate *rate);
        private:
            void createWidgets();
            void createIdWidgets();
            void createEntityWidgets();
            void createRegistWidgets();
            void createConnections();
            void loadRegist();
            void saveRegist();
            bool isSaveable();


            QGroupBox *_newRegistGbox;

            //Id, Fecha y Hora del Registro
            QLabel *_idLabel;
            QLineEdit *_idLineEdit;

            QLabel *_dateLabel;
            QDateEdit *_dateEdit;

            QLabel *_timeLabel;
            QTimeEdit *_timeEdit;

            //Tarifa para calcular importe
            QLabel *_rateLabel;
            QComboBox *_rateComboBox;
            QPushButton *_detailRatePushButton;
            QCheckBox *_calImportCheckBox;

            //Datos de la entidad del registro
            QLabel *_entityIdLabel;
            QLineEdit *_entityIdLineEdit;

            QLabel *_entityNameLabel;
            QLineEdit *_entityNameLineEdit;

            QLabel *_entityFolioLabel;
            QLineEdit *_entityFolioLineEdit;

            QPushButton *_selectEntityPushButton;
            QPushButton *_detailEntityPushButton;

            //Lecturas, Kw/h e importe del registro

            QLabel *_lectiLabel;
            QLineEdit *_lectiLineEdit;

            QLabel *_lectfLabel;
            QLineEdit *_lectfLineEdit;

            QLabel *_kwhLabel;
            QLineEdit *_kwhLineEdit;

            QLabel *_importLabel;
            QLineEdit *_importLineEdit;

            QPushButton *_saveButton;
            QPushButton *_cancelButton;

            RangeModel *_rangeModel;
            Model::Domain::Regist *_regist;
        };
    }
}

#endif // REGISTDIALOG_H
