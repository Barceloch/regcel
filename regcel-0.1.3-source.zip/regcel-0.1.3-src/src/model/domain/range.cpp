/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "rate.h"
#include "range.h"

Model::Domain::Range::Range(int id)
    : _id(id)
{
    _rate = 0;
    _fromNumber = 0;
    _toNumber=0;
    _price=0.0;

}

Model::Domain::Range::Range(const Range &range)
{
    *this = range;
}

Model::Domain::Range::~Range()
{
    if(_rate)
        delete _rate;
}

Model::Domain::Range &Model::Domain::Range::operator=(const Range &range)
{
    _id = range._id;
    _rate = (range._rate) ? new Rate(*range._rate) : 0;
    _fromNumber = range._fromNumber;
    _toNumber = range._toNumber;
    _price = range._price;

    return *this;
}

bool Model::Domain::Range::operator==(const Range &range) const
{
    return _id == range._id;
}

bool Model::Domain::Range::operator!=(const Range &range) const
{
    return !(*this == range);
}

void Model::Domain::Range::setId(int id)
{
    _id = id;
}

int Model::Domain::Range::id() const
{
    return _id;
}
void Model::Domain::Range::setRate(Rate *rate)
{
    if(_rate)
        delete _rate;

    _rate = rate;
}

Model::Domain::Rate *Model::Domain::Range::rate() const
{
    return _rate;
}
void Model::Domain::Range::setFromNumber(int fromNumber)
{
    _fromNumber = fromNumber;
}

int Model::Domain::Range::fromNumber() const
{
    return _fromNumber;
}

void Model::Domain::Range::setToNumber(int toNumber)
{
    _toNumber = toNumber;
}

int Model::Domain::Range::toNumber() const
{
    return _toNumber;
}

void Model::Domain::Range::setPrice(double price)
{
    _price = price;
}

double Model::Domain::Range::price() const
{
    return _price;
}



