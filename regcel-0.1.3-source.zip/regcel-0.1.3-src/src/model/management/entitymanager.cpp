/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "entitymanager.h"
#include "sqlagent.h"
#include "types.h"

bool Model::Management::EntityManager::create(const Model::Domain::Entity &entity)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("INSERT INTO entity VALUES(%1, %2, '%3', '%4', '%5', '%6', '%7', '%8', '%9', '%10', '%11', '%12', '%13')")
                      .arg(entity.id())
                      .arg(entity.folio())
                      .arg(entity.name())
                      .arg(entity.country())
                      .arg(entity.province())
                      .arg(entity.city())
                      .arg(entity.address())
                      .arg(entity.pc())
                      .arg(entity.telephone())
                      .arg(entity.mobile())
                      .arg(entity.fax())
                      .arg(entity.email())
                      .arg(entity.web());


    return agent -> insert(sql);
}

bool Model::Management::EntityManager::modify(const Model::Domain::Entity &entity)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("UPDATE entity SET folio=%2, name='%3', country='%4', province='%5', city='%6', address='%7', pc='%8', telephone='%9', mobile='%10', fax='%11', email='%12', web='%13' WHERE id=%1")
                      .arg(entity.id())
                      .arg(entity.folio())
                      .arg(entity.name())
                      .arg(entity.country())
                      .arg(entity.province())
                      .arg(entity.city())
                      .arg(entity.address())
                      .arg(entity.pc())
                      .arg(entity.telephone())
                      .arg(entity.mobile())
                      .arg(entity.fax())
                      .arg(entity.email())
                      .arg(entity.web());


    return agent -> update(sql);
}

bool Model::Management::EntityManager::remove(int id)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("DELETE FROM entity WHERE id=%1")
                      .arg(id);

    return agent -> _delete(sql);
}

Model::Domain::Entity *Model::Management::EntityManager::get(int id)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM entity WHERE id=%1")
                      .arg(id);
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    Model::Domain::Entity *entity = 0;

    if(!(result -> isEmpty())) {
        int folio        = (result -> at(0)).at(1).toInt();
        QString name     = (result -> at(0)).at(2).toString();
        QString country  = (result -> at(0)).at(3).toString();
        QString province = (result -> at(0)).at(4).toString();
        QString city     = (result -> at(0)).at(5).toString();
        QString address  = (result -> at(0)).at(6).toString();
        QString pc       = (result -> at(0)).at(7).toString();
        int telephone    = (result -> at(0)).at(8).toInt();
        int mobile       = (result -> at(0)).at(9).toInt();
        int fax          = (result -> at(0)).at(10).toInt();
        QString email    = (result -> at(0)).at(11).toString();
        QString web      = (result -> at(0)).at(12).toString();


        entity = new Model::Domain::Entity(id);
        entity -> setFolio(folio);
        entity -> setName(name);
        entity -> setCountry(country);
        entity -> setProvince(province);
        entity -> setCity(city);
        entity -> setAddress(address);
        entity -> setPc(pc);
        entity -> setTelephone(telephone);
        entity -> setMobile(mobile);
        entity -> setFax(fax);
        entity -> setEmail(email);
        entity -> setWeb(web);

    }

    delete result;

    return entity;
}

QMap<QString, int> Model::Management::EntityManager::getAllNames()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT name, id FROM entity");
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QMap<QString, int> names;

    foreach(QVector<QVariant> row, *result)
        names.insert(row.at(0).toString(), row.at(1).toInt());

    delete result;

    return names;
}

QList<Model::Domain::Entity *> *Model::Management::EntityManager::getAll()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM entity");
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QList<Model::Domain::Entity *> *entities = new QList<Model::Domain::Entity *>;

    foreach(QVector<QVariant> row, *result) {
        int id           = row.at(0).toInt();
        int folio        = row.at(1).toInt();
        QString name     = row.at(2).toString();
        QString country  = row.at(3).toString();
        QString province = row.at(4).toString();
        QString city     = row.at(5).toString();
        QString address  = row.at(6).toString();
        QString pc       = row.at(7).toString();
        int telephone    = row.at(8).toInt();
        int mobile       = row.at(9).toInt();
        int fax          = row.at(10).toInt();
        QString email    = row.at(11).toString();
        QString web      = row.at(12).toString();


        Model::Domain::Entity *entity = new Model::Domain::Entity(id);
        entity -> setFolio(folio);
        entity ->setName(name);
        entity -> setCountry(country);
        entity -> setProvince(province);
        entity -> setCity(city);
        entity -> setAddress(address);
        entity -> setPc(pc);
        entity -> setTelephone(telephone);
        entity -> setMobile(mobile);
        entity -> setFax(fax);
        entity -> setEmail(email);
        entity -> setWeb(web);

        entities -> push_back(entity);
    }

    delete result;

    return entities;
}

int Model::Management::EntityManager::getId()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT count(*) FROM entity");
    QVector<QVector<QVariant> > *result = agent -> select(sql);

    if(!(result -> isEmpty())) {
        int count = (result -> at(0)).at(0).toInt();
        delete result;
        if(count == 0)
            return 1;
        else {
            sql = QString("SELECT max(id) FROM entity");
            result = agent -> select(sql);
            int id = (result -> at(0)).at(0).toInt();
            delete result;
            return id + 1;
        }
    }

    delete result;

    return NO_ID;
}

