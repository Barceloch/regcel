/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "rangemanager.h"
#include "ratemanager.h"
#include "sqlagent.h"
#include "types.h"

bool Model::Management::RangeManager::create(const Model::Domain::Range &range)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("INSERT INTO range VALUES(%1, %2, '%3', '%4', '%5')")
                      .arg(range.id())
                      .arg(range.rate() ->id())
                      .arg(range.fromNumber())
                      .arg(range.toNumber())
                      .arg(range.price());

    return agent -> insert(sql);
}

bool Model::Management::RangeManager::modify(const Model::Domain::Range &range)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("UPDATE range SET rate=%2, fromNumber='%3', toNumber='%4', price='%5'"
                          " WHERE id=%1")
                      .arg(range.id())
                      .arg(range.rate()->id())
                      .arg(range.fromNumber())
                      .arg(range.toNumber())
                      .arg(range.price());

   return agent->update(sql);
}

bool Model::Management::RangeManager::remove(int id)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("DELETE FROM range WHERE id=%1").arg(id);

    return agent -> _delete(sql);

}

Model::Domain::Range *Model::Management::RangeManager::get(int id)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM range WHERE id=%1")
                            .arg(id);
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    Model::Domain::Range *range = 0;

    if(!(result -> isEmpty())) {
        Model::Domain::Rate *rate  = RateManager::get((result -> at(0)).at(1).toInt());
        int fromNumber             = (result -> at(0)).at(2).toInt();
        int toNumber               = (result -> at(0)).at(3).toInt();
        double price               = (result -> at(0)).at(4).toDouble();

        range = new Model::Domain::Range(id);
        range->setRate(rate);
        range->setFromNumber(fromNumber);
        range->setToNumber(toNumber);
        range->setPrice(price);


    }

    delete result;

    return range;
}

QList<Model::Domain::Range *> *Model::Management::RangeManager::getAll()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM range");
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QList<Model::Domain::Range *> *ranges = new QList<Model::Domain::Range *>;

    foreach(QVector<QVariant> row, *result) {
        int id                                = row.at(0).toInt();
        Model::Domain::Rate *rate             = RateManager::get(row.at(1).toInt());
        int fromNumber                        = row.at(2).toInt();
        int toNumber                          = row.at(3).toInt();
        double price                          = row.at(4).toDouble();

        Model::Domain::Range *range = new Model::Domain::Range(id);
        range->setRate(rate);
        range->setFromNumber(fromNumber);
        range->setToNumber(toNumber);
        range->setPrice(price);
        ranges -> push_back(range);

    }

    delete result;

    return ranges;
}
QList<Model::Domain::Range *> *Model::Management::RangeManager::getByRate(int rateId)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM range WHERE rate=%1")
                           .arg(rateId);
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QList<Model::Domain::Range *> *ranges = new QList<Model::Domain::Range *>;

    foreach(QVector<QVariant> row, *result) {
        int id                                = row.at(0).toInt();
        Model::Domain::Rate *rate             = RateManager::get(row.at(1).toInt());
        int fromNumber                        = row.at(2).toInt();
        int toNumber                          = row.at(3).toInt();
        double price                          = row.at(4).toDouble();

        Model::Domain::Range *range = new Model::Domain::Range(id);
        range->setRate(rate);
        range->setFromNumber(fromNumber);
        range->setToNumber(toNumber);
        range->setPrice(price);
        ranges -> push_back(range);

    }

    delete result;

    return ranges;
}

int Model::Management::RangeManager::getId()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT count(*) FROM range");
    QVector<QVector<QVariant> > *result = agent -> select(sql);

    if(!(result -> isEmpty())) {
        int count = (result -> at(0)).at(0).toInt();
        delete result;
        if(count == 0)
            return 1;
        else {
            sql = QString("SELECT max(id) FROM range");
            result = agent -> select(sql);
            int id = (result -> at(0)).at(0).toInt();
            delete result;
            return id + 1;
        }
    }

    delete result;

    return NO_ID;
}


