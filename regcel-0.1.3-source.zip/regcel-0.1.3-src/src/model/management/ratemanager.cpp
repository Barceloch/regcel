/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "ratemanager.h"
#include "rangemanager.h"
#include "sqlagent.h"
#include "types.h"

bool Model::Management::RateManager::create(const Model::Domain::Rate &rate)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("INSERT INTO rate VALUES(%1, '%2', '%3', %4, %5)")
                      .arg(rate.id())
                      .arg(rate.name())
                      .arg(rate.description())
                      .arg(rate.moreofNumber())
                      .arg(rate.moreofPrice());

    return agent -> insert(sql);
}

bool Model::Management::RateManager::modify(const Model::Domain::Rate &rate)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("UPDATE rate SET name='%2', description='%3', moreofNumber=%4, "
                          "moreofPrice=%5 WHERE id=%1")
                      .arg(rate.id())
                      .arg(rate.name())
                      .arg(rate.description())
                      .arg(rate.moreofNumber())
                      .arg(rate.moreofPrice());


   return agent -> update(sql);
}

bool Model::Management::RateManager::remove(int id)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("DELETE FROM rate WHERE id=%1").arg(id);

    return agent -> _delete(sql);

}

Model::Domain::Rate *Model::Management::RateManager::get(int id)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM rate WHERE id=%1")
                            .arg(id);
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    Model::Domain::Rate *rate = 0;

    if(!(result -> isEmpty())) {
        QString name                   = (result -> at(0)).at(1).toString();
        QString description            = (result -> at(0)).at(2).toString();
        int moreofNumber               = (result -> at(0)).at(3).toInt();
        double moreofPrice             = (result -> at(0)).at(4).toDouble();

        rate = new Model::Domain::Rate(id);
        rate->setName(name);
        rate->setDescription(description);
        //rate->setRanges(RangeManager::getAllByRate(id));
        rate->setMoreOfNumber(moreofNumber);
        rate->setMoreOfPrice(moreofPrice);

    }

    delete result;

    return rate;
}

QMap<QString, int> Model::Management::RateManager::getAllNames()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT name, id FROM rate");
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QMap<QString, int> names;

    foreach(QVector<QVariant> row, *result)
        names.insert(row.at(0).toString(), row.at(1).toInt());

    delete result;

    return names;
}

QList<Model::Domain::Rate *> *Model::Management::RateManager::getAll()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM rate");
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QList<Model::Domain::Rate *> *rates = new QList<Model::Domain::Rate *>;

    foreach(QVector<QVariant> row, *result) {
        int id              = row.at(0).toInt();
        QString name        = row.at(1).toString();
        QString description = row.at(2).toString();
        int moreofNumber                        = row.at(3).toInt();
        double moreofPrice                    = row.at(4).toDouble();

        Model::Domain::Rate *rate = new Model::Domain::Rate(id);
        rate->setName(name);
        rate->setDescription(description);
        rate->setMoreOfNumber(moreofNumber);
        rate->setMoreOfPrice(moreofPrice);

        rates -> push_back(rate);

    }

    delete result;

    return rates;
}

int Model::Management::RateManager::getId()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT count(*) FROM rate");
    QVector<QVector<QVariant> > *result = agent -> select(sql);

    if(!(result -> isEmpty())) {
        int count = (result -> at(0)).at(0).toInt();
        delete result;
        if(count == 0)
            return 1;
        else {
            sql = QString("SELECT max(id) FROM rate");
            result = agent -> select(sql);
            int id = (result -> at(0)).at(0).toInt();
            delete result;
            return id + 1;
        }
    }

    delete result;

    return NO_ID;
}

