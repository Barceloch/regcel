/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "entitydialog.h"
#include "entitymanager.h"
#include "entity.h"
#include "types.h"
#include <QtGui>

View::Management::EntityDialog::EntityDialog(Model::Domain::Entity *entity, QWidget *parent)
    : QDialog(parent), _entity(entity)
{
    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Entidad")+"[*]");
    setWindowIcon(QIcon(":/images/entity.png"));
    setMinimumWidth(ENTITY_DIALOG_MINIMUM_SIZE);
    loadEntity();
}

void View::Management::EntityDialog::done(int result)
{
    if(result)
        saveEntity();

    QDialog::done(result);
}

/*void View::Management::EntityDialog::stateChangedOnAutoIdCheckBox()
{
    _idLineEdit -> setEnabled(!_autoIdCheckBox -> isChecked());
}

void View::Management::EntityDialog::updateId()
{
    int id = (_autoIdCheckBox -> isChecked() ?
                  Model::Management::EntityManager::getId() : _entity -> id());

    _idLineEdit -> setText((!IS_NEW(id) ? QString::number(id) : ""));
}*/



void View::Management::EntityDialog::entityModified(bool modified)
{
    setWindowModified(modified);
    _saveButton -> setEnabled(isSaveable() && modified);
}

void View::Management::EntityDialog::createWidgets()
{
    createIdWidgets();

    QGridLayout *idLayout = new QGridLayout;
    idLayout -> addWidget(_idLabel, 0, 0, 1, 1);
    idLayout -> addWidget(_idLineEdit, 0, 1, 1, 1);
    //idLayout -> addWidget(_autoIdCheckBox, 0, 2, 1, 1);
    idLayout -> addWidget(_folioLabel, 0, 3, 1, 1);
    idLayout -> addWidget(_folioLineEdit, 0, 4, 1, 1);
    idLayout -> addWidget(_nameLabel, 1, 0, 1, 1);
    idLayout -> addWidget(_nameLineEdit, 1, 1, 1, 4);

    QGroupBox *idGroupBox = new QGroupBox(trUtf8("&Identificación"));
    idGroupBox -> setLayout(idLayout);

    createUbicationWidgets();

    QGridLayout *ubicationLayout = new QGridLayout;
    ubicationLayout -> addWidget(_countryLabel, 0, 0, 1, 1);
    ubicationLayout -> addWidget(_countryLineEdit, 0, 1, 1, 1);
    ubicationLayout -> addWidget(_provinceLabel, 0, 2, 1, 1);
    ubicationLayout -> addWidget(_provinceLineEdit, 0, 3, 1, 1);
    ubicationLayout -> addWidget(_cityLabel, 1, 0, 1, 1);
    ubicationLayout -> addWidget(_cityLineEdit, 1, 1, 1, 1);
    ubicationLayout -> addWidget(_addressLabel, 1, 2, 1, 1);
    ubicationLayout -> addWidget(_addressLineEdit, 1, 3, 1, 1);
    ubicationLayout -> addWidget(_pcLabel, 2, 0, 1, 1);
    ubicationLayout -> addWidget(_pcLineEdit, 2, 1, 1, 1);

    QGroupBox *ubicationGroupBox = new QGroupBox(trUtf8("&Ubicación"));
    ubicationGroupBox -> setLayout(ubicationLayout);

    createContactWidgets();

    QGridLayout *contactLayout = new QGridLayout;
    contactLayout -> addWidget(_telephoneLabel, 0, 0, 1, 1);
    contactLayout -> addWidget(_telephoneLineEdit, 0, 1, 1, 1);
    contactLayout -> addWidget(_mobileLabel, 0, 2, 1, 1);
    contactLayout -> addWidget(_mobileLineEdit, 0, 3, 1, 1);
    contactLayout -> addWidget(_faxLabel, 1, 0, 1, 1);
    contactLayout -> addWidget(_faxLineEdit, 1, 1, 1, 1);
    contactLayout -> addWidget(_emailLabel, 1, 2, 1, 1);
    contactLayout -> addWidget(_emailLineEdit, 1, 3, 1, 1);
    contactLayout -> addWidget(_webLabel, 2, 0, 1, 1);
    contactLayout -> addWidget(_webLineEdit, 2, 1, 1, 1);

    QGroupBox *contactGroupBox = new QGroupBox(trUtf8("&Contacto"));
    contactGroupBox -> setLayout(contactLayout);


    _saveButton = new QPushButton(trUtf8("&Guardar"));
    _saveButton -> setIcon(QIcon(":/images/save.png"));
    _saveButton -> setDefault(true);
    _saveButton -> setEnabled(false);
    _closeButton = new QPushButton(trUtf8("&Cerrar"));
    _closeButton -> setIcon(QIcon(":/images/cancel.png"));

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_saveButton);
    bottomLayout -> addWidget(_closeButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addWidget(idGroupBox);
    mainLayout -> addWidget(ubicationGroupBox);
    mainLayout -> addWidget(contactGroupBox);
    mainLayout -> addLayout(bottomLayout);
    mainLayout -> setSizeConstraint(QLayout::SetFixedSize);

    setLayout(mainLayout);
}

void View::Management::EntityDialog::createIdWidgets()
{
    _idLabel = new QLabel(trUtf8("&Id:"));
    _idLineEdit = new QLineEdit;
    _idLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _idLineEdit ->setReadOnly(true);
    _idLabel -> setBuddy(_idLineEdit);
    //_autoIdCheckBox = new QCheckBox(trUtf8("&Auto"));

    _folioLabel = new QLabel(trUtf8("&Folio:"));
    _folioLineEdit = new QLineEdit;
    _folioLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _folioLabel -> setBuddy(_folioLineEdit);

    _nameLabel = new QLabel(trUtf8("&Nombre:"));
    _nameLineEdit = new QLineEdit;
    _nameLabel -> setBuddy(_nameLineEdit);
}

void View::Management::EntityDialog::createUbicationWidgets()
{
    _countryLabel = new QLabel(trUtf8("&País:"));
    _countryLineEdit = new QLineEdit;
    _countryLabel -> setBuddy(_countryLineEdit);

    _provinceLabel = new QLabel(trUtf8("&Provincia:"));
    _provinceLineEdit = new QLineEdit;
    _provinceLabel -> setBuddy(_provinceLineEdit);

    _cityLabel = new QLabel(trUtf8("&Municipio:"));
    _cityLineEdit = new QLineEdit;
    _cityLabel -> setBuddy(_cityLineEdit);

    _addressLabel = new QLabel(trUtf8("&Dirección:"));
    _addressLineEdit = new QLineEdit;
    _addressLabel -> setBuddy(_addressLineEdit);

    _pcLabel = new QLabel(trUtf8("C&odigo Postal:"));
    _pcLineEdit = new QLineEdit;
    _pcLabel -> setBuddy(_pcLineEdit);
}

void View::Management::EntityDialog::createContactWidgets()
{
    _telephoneLabel = new QLabel(trUtf8("&Teléfono:"));
    _telephoneLineEdit = new QLineEdit;
    _telephoneLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _telephoneLabel -> setBuddy(_telephoneLineEdit);

    _mobileLabel = new QLabel(trUtf8("&Movil:"));
    _mobileLineEdit = new QLineEdit;
    _mobileLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _mobileLabel -> setBuddy(_mobileLineEdit);

    _faxLabel = new QLabel(trUtf8("&Fax:"));
    _faxLineEdit = new QLineEdit;
    _faxLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _faxLabel -> setBuddy(_faxLineEdit);

    _emailLabel = new QLabel(trUtf8("&Email:"));
    _emailLineEdit = new QLineEdit;
    _emailLabel -> setBuddy(_emailLineEdit);

    _webLabel = new QLabel(trUtf8("&Web:"));
    _webLineEdit = new QLineEdit;
    _webLabel -> setBuddy(_webLineEdit);
}

void View::Management::EntityDialog::createConnections()
{
    /*connect(_idLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_autoIdCheckBox, SIGNAL(stateChanged(int)),
            this, SLOT(stateChangedOnAutoIdCheckBox()));
    connect(_autoIdCheckBox, SIGNAL(stateChanged(int)),
            this, SLOT(updateId()));*/
    connect(_folioLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_nameLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_countryLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_provinceLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_cityLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_addressLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_pcLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_telephoneLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_mobileLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_faxLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_emailLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_webLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(entityModified()));
    connect(_saveButton, SIGNAL(clicked()),
            this, SLOT(accept()));
    connect(_closeButton, SIGNAL(clicked()),
            this, SLOT(reject()));
}


void View::Management::EntityDialog::loadEntity()
{
    _idLineEdit -> setText(IS_NEW(_entity -> id()) ? QString::number(Model::Management::EntityManager::getId()) :
                                                      QString::number(_entity -> id()));
    _folioLineEdit -> setText(_entity -> folio() ? QString::number(_entity -> folio()) : "");
    _nameLineEdit -> setText(_entity -> name());
    _countryLineEdit -> setText(_entity -> country());
    _provinceLineEdit -> setText(_entity -> province());
    _cityLineEdit -> setText(_entity -> city());
    _addressLineEdit -> setText(_entity -> address());
    _pcLineEdit -> setText(_entity -> pc());
    _telephoneLineEdit -> setText(_entity -> telephone() ? QString::number(_entity -> telephone()) : "");
    _mobileLineEdit -> setText(_entity -> mobile() ? QString::number(_entity -> mobile()) : "");
    _faxLineEdit -> setText(_entity -> fax() ? QString::number(_entity -> fax()) : "");
    _emailLineEdit -> setText(_entity->email());
    _webLineEdit -> setText(_entity->web());

    entityModified(false);
}

void View::Management::EntityDialog::saveEntity()
{
    _entity -> setId(_idLineEdit -> text().toInt());
    _entity -> setFolio(!_folioLineEdit -> text().isEmpty() ? _folioLineEdit -> text().toInt() : 0);
    _entity -> setName(_nameLineEdit -> text());
    _entity -> setCountry(_countryLineEdit -> text());
    _entity -> setProvince(_provinceLineEdit -> text());
    _entity -> setCity(_cityLineEdit -> text());
    _entity -> setAddress(_addressLineEdit -> text());
    _entity -> setPc(_pcLineEdit -> text());
    _entity -> setTelephone(!_telephoneLineEdit -> text().isEmpty() ? _telephoneLineEdit -> text().toInt() : 0);
    _entity -> setMobile(!_mobileLineEdit -> text().isEmpty() ? _mobileLineEdit -> text().toInt() : 0);
    _entity -> setFax(!_faxLineEdit -> text().isEmpty() ? _faxLineEdit -> text().toInt() : 0);
    _entity -> setEmail(_emailLineEdit -> text());
    _entity -> setWeb(_webLineEdit -> text());
}

bool View::Management::EntityDialog::isSaveable()
{
    return !(_idLineEdit -> text().isEmpty()) &&
           !(_nameLineEdit -> text().isEmpty());
}
