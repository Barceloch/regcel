/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "mainwindow.h"
#include "entityeditor.h"
#include "entitydialog.h"
#include "entitymodel.h"
#include "registmodel.h"
#include "entitymanager.h"
#include "registmanager.h"
#include "entity.h"
#include "regist.h"
#include <QtGui>

View::Management::EntityEditor::EntityEditor(QWidget *parent)
    : QWidget(parent)
{
    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Editor de entidades"));
    setWindowIcon(QIcon(":/images/entity.png"));
    setMinimumWidth(ENTITY_EDITOR_MINIMUM_WIDTH);
    setAttribute(Qt::WA_DeleteOnClose);
}

View::Management::EntityEditor::~EntityEditor()
{
    delete _entityModel;
}

void View::Management::EntityEditor::closeEvent(QCloseEvent *event)
{
    emit finished();
    event->accept();

}

void View::Management::EntityEditor::addEntityFromRegist(const Model::Domain::Entity &entity)
{
    int rows = _entityModel -> rowCount(QModelIndex());
    _entityModel -> insertEntity(rows, new Model::Domain::Entity(entity));
}

void View::Management::EntityEditor::rowSelectionChanged()
{
    int row = _entitiesTableView -> currentIndex().row();
    _modEntityButton -> setEnabled(row != -1);
    _delEntityButton -> setEnabled(row != -1);
}

void View::Management::EntityEditor::addEntity()
{
    Model::Domain::Entity *entity = new Model::Domain::Entity;
    EntityDialog dialog(entity, this);

    if(dialog.exec()) {
        if(Model::Management::EntityManager::create(*entity)) {
            int row = _entityModel -> rowCount(QModelIndex());
            _entityModel -> insertEntity(row, entity);
        } else {
            QMessageBox::critical(this, trUtf8("Error"),
                                  trUtf8("Error añadiendo la entidad"),
                                  QMessageBox::Ok);
            delete entity;
        }

        rowSelectionChanged();

    } else
        delete entity;
}

void View::Management::EntityEditor::modEntity()
{
    int row = _entitiesTableView -> currentIndex().row();
    Model::Domain::Entity *entity = _entityModel -> entities() -> at(row);
    EntityDialog dialog(entity, this);

    if(dialog.exec()) {
        if(Model::Management::EntityManager::modify(*entity))
            _entityModel -> modifyEntity(row);
        else
            QMessageBox::critical(this, trUtf8("Error"),
                                  trUtf8("Error modificando la entidad"),
                                  QMessageBox::Ok);

        rowSelectionChanged();

    }

}

void View::Management::EntityEditor::delEntity()
{
    if(!verifyDeleteEntity())
        return;

    int row = _entitiesTableView -> currentIndex().row();
    QList<Model::Domain::Regist *> *oldRegist = Model::Management::RegistManager::getByEntity(_entityModel->entities()->at(row)->id());
    delete oldRegist;

    Model::Management::EntityManager::remove(_entityModel -> entities() -> at(row) -> id());
    _entityModel -> removeEntity(row);
    rowSelectionChanged();


}

void View::Management::EntityEditor::createWidgets()
{
    _entitiesTableView = new QTableView;
    _entityModel = new EntityModel(Model::Management::EntityManager::getAll());
    _entitiesTableView -> setModel(_entityModel);
    //_entitiesTableView -> setAlternatingRowColors(true);
    _entitiesTableView -> setShowGrid(false);
    _entitiesTableView -> setColumnWidth(ColumnEntityId, COLUMN_ENTITY_ID_WIDTH);
    _entitiesTableView -> setColumnWidth(ColumnEntityName, COLUMN_ENTITY_NAME_WIDTH);
    _entitiesTableView -> setColumnWidth(ColumnEntityFolio, COLUMN_ENTITY_FOLIO_WIDTH);
    _entitiesTableView -> setSelectionMode(QAbstractItemView::SingleSelection);
    _entitiesTableView -> setSelectionBehavior(QAbstractItemView::SelectRows);
    _entitiesTableView -> setEditTriggers(QAbstractItemView::NoEditTriggers);
    _entitiesTableView -> setFocusPolicy(Qt::NoFocus);

    _addEntityButton = new QPushButton(trUtf8("&Añadir"));
    _addEntityButton -> setIcon(QIcon(":/images/add.png"));
    _modEntityButton = new QPushButton(trUtf8("&Editar"));
    _modEntityButton -> setIcon(QIcon(":/images/modify.png"));
    _modEntityButton -> setEnabled(false);
    _delEntityButton = new QPushButton(trUtf8("&Eliminar"));
    _delEntityButton -> setIcon(QIcon(":/images/delete.png"));
    _delEntityButton -> setEnabled(false);

    QGridLayout *topLayout = new QGridLayout;
    topLayout -> addWidget(_entitiesTableView, 0, 0, 1, 6);
    topLayout -> addWidget(_addEntityButton, 1, 3, 1, 1);
    topLayout -> addWidget(_modEntityButton, 1, 4, 1, 1);
    topLayout -> addWidget(_delEntityButton, 1, 5, 1, 1);

    QGroupBox *entitiesGroupBox = new QGroupBox(trUtf8("Lista"));
    entitiesGroupBox -> setLayout(topLayout);

    _closeButton = new QPushButton(trUtf8("&Cerrar"));
    _closeButton -> setIcon(QIcon(":/images/ok.png"));
    _closeButton -> setFixedSize(_closeButton -> sizeHint());

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_closeButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addWidget(entitiesGroupBox);
    mainLayout -> addLayout(bottomLayout);

    setLayout(mainLayout);
}


void View::Management::EntityEditor::createConnections()
{
    connect(_entitiesTableView -> selectionModel(), SIGNAL(selectionChanged(QItemSelection,QItemSelection)),
            this, SLOT(rowSelectionChanged()));
    connect(_entitiesTableView, SIGNAL(doubleClicked(QModelIndex)),
            this, SLOT(modEntity()));
    connect(_addEntityButton, SIGNAL(clicked()),
            this, SLOT(addEntity()));
    connect(_modEntityButton, SIGNAL(clicked()),
            this, SLOT(modEntity()));
    connect(_delEntityButton, SIGNAL(clicked()),
            this, SLOT(delEntity()));
    connect(_closeButton, SIGNAL(clicked()),
            this, SLOT(close()));
}
bool View::Management::EntityEditor::verifyDeleteEntity()
{
    return QMessageBox::question(this, trUtf8("Confirmar eleminación"),
                                       trUtf8("Todos los registros de esta entidad serán eliminados.\n"
                                          "¿desea continuar?"),
                                       QMessageBox::Yes | QMessageBox::Default |
                                       QMessageBox::No) == QMessageBox::Yes;
}
