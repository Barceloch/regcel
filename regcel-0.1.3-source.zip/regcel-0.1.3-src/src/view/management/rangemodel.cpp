/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "rangemodel.h" 
#include "rangemanager.h"
#include "range.h"
#include "types.h"

View::Management::RangeModel::~RangeModel()
{
    if(_ranges) {
        foreach(Model::Domain::Range *range, *_ranges)
            delete range;

        delete _ranges;
    }
}

QList<Model::Domain::Range *> *View::Management::RangeModel::ranges()
{
    return _ranges;
}

void View::Management::RangeModel::setRanges(QList<Model::Domain::Range *> *ranges)
{
    _ranges = ranges;
    reset();
}

bool View::Management::RangeModel::insertRange(int k, Model::Domain::Range *range)
{
    if(k < 0  || k > _ranges -> size())
        return false;

    _ranges -> insert(k, range);
    reset();

    return true;
}

bool View::Management::RangeModel::modifyRange(int k)
{
    if(k < 0  || k > _ranges -> size())
        return false;

    reset();

    return true;
}

bool View::Management::RangeModel::removeRange(int k)
{
    if(k < 0  || k > _ranges -> size())
        return false;

    delete _ranges -> at(k);
    _ranges -> removeAt(k);
    reset();

    return true;
}

int View::Management::RangeModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);

    return _ranges -> size();
}


int View::Management::RangeModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);

    return ColumnRangeCount;
}

QVariant View::Management::RangeModel::data(const QModelIndex &index, int role) const
{
    if(index.isValid() && _ranges) {
        if(role == Qt::TextAlignmentRole) {
            switch(index.column()) {
            case ColumnRangeId:
                return int(Qt::AlignCenter);
            case ColumnRangeFromNumber:
                return int(Qt::AlignCenter);
            case ColumnRangeToNumber:
                return int(Qt::AlignCenter);
            default:
                return int(Qt::AlignRight | Qt::AlignVCenter);
            }
        } else if(role == Qt::DisplayRole) {
            Model::Domain::Range *range = _ranges -> at(index.row());
            switch(index.column()) {
            case ColumnRangeId:
                return QString::number(range->id());
            case ColumnRangeFromNumber:
                return QString::number(range->fromNumber());
            case ColumnRangeToNumber:
                return QString::number(range->toNumber());
            case ColumnRangePrice:
                return QString("%1 $").arg(QString::number(range ->price(), 'f', MAX_MONEY_PRECISION));
            }
        }
    }

    return QVariant();
}


QVariant View::Management::RangeModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if(role == Qt::DisplayRole) {
        if(orientation == Qt::Vertical)
            return QString::number(section + 1);
        else {
            switch(section) {
            case ColumnRangeId:
                return QObject::trUtf8("ID");
            case ColumnRangeFromNumber:
                return QObject::trUtf8("De");
            case ColumnRangeToNumber:
                return QObject::trUtf8("Hasta");
            case ColumnRangePrice:
                return QObject::trUtf8("Valen");

            }
        }
    }

    return QVariant();
}

