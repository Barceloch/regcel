/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "ratemodel.h"
#include "rate.h"

View::Management::RateModel::~RateModel()
{
    if(_rates) {
        foreach(Model::Domain::Rate *rate, *_rates)
            delete rate;

        delete _rates;
    }
}

QList<Model::Domain::Rate *> *View::Management::RateModel::rates()
{
    return _rates;
}

void View::Management::RateModel::setRates(QList<Model::Domain::Rate *> *rates)
{
    _rates = rates;
    reset();
}

bool View::Management::RateModel::insertRate(int k, Model::Domain::Rate *rate)
{
    if(k < 0  || k > _rates -> size())
        return false;

    _rates -> insert(k, rate);
    reset();

    return true;
}

bool View::Management::RateModel::modifyRate(int k)
{
    if(k < 0  || k > _rates -> size())
        return false;

    reset();

    return true;
}

bool View::Management::RateModel::removeRate(int k)
{
    if(k < 0  || k > _rates -> size())
        return false;

    delete _rates -> at(k);
    _rates -> removeAt(k);
    reset();

    return true;
}

int View::Management::RateModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);

    return _rates -> size();
}

int View::Management::RateModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);

    return ColumnRateCount;
}

QVariant View::Management::RateModel::data(const QModelIndex &index, int role) const
{
    if(index.isValid()) {
        if(role == Qt::TextAlignmentRole) {
            switch(index.column()) {
            case ColumnRateId:
                return int(Qt::AlignCenter);
            case ColumnRateName:
                return int(Qt::AlignLeft | Qt::AlignVCenter);
            }
        } else if(role == Qt::DisplayRole) {
            Model::Domain::Rate *rate = _rates -> at(index.row());
            switch(index.column()) {
            case ColumnRateId:
                return QString::number(rate -> id());
            case ColumnRateName:
                return rate->name();
            }
        }
    }

    return QVariant();
}

QVariant View::Management::RateModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if(role == Qt::DisplayRole) {
        if(orientation == Qt::Vertical)
            return QString::number(section + 1);
        else {
            switch(section) {
            case ColumnRateId:
                return QObject::trUtf8("ID");
            case ColumnRateName:
                return QObject::trUtf8("Nombre");
            }
        }
    }

    return QVariant();
}

