/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "entityselector.h"
#include "entityviewer.h"
#include "entitymodel.h"
#include "entitymanager.h"
#include "entitydialog.h"
#include "registdialog.h"
#include "regist.h"
#include "registmanager.h"
#include "ratemanager.h"
#include "ratemodel.h"
#include "rateviewer.h"
#include "rangemanager.h"
#include "rangemodel.h"
#include "persistencemanager.h"
#include "types.h"
#include <QtGui>

View::Management::RegistDialog::RegistDialog(Model::Domain::Regist *regist, QWidget *parent)
    : QDialog(parent), _regist(regist)
{
    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Registro")+"[*]");
    loadRegist();

}

void View::Management::RegistDialog::done(int result)
{
   if(result)
        saveRegist();

    QDialog::done(result);
}

void View::Management::RegistDialog::registModified(bool modified)
{
    setWindowModified(modified);
    _saveButton -> setEnabled(isSaveable() && modified);
}

void View::Management::RegistDialog::selectRate()
{

    _rateComboBox->setEnabled(_calImportCheckBox -> isChecked());
    _importLineEdit->setEnabled(_calImportCheckBox -> isChecked());
    if (!_calImportCheckBox->isChecked())
        _importLineEdit->setText("0.00 $");

    int index = _rateComboBox->currentIndex();
    _detailRatePushButton->setEnabled(_calImportCheckBox -> isChecked() && index > 0);
    if (index > 0 && _lectiLineEdit->text().toDouble() < _lectfLineEdit->text().toDouble())
        calculateKwh();


}

void View::Management::RegistDialog::selectedRate()
{
    int index = _rateComboBox->currentIndex();
    _detailRatePushButton->setEnabled(index > 0);

    if (index > 0 && _lectiLineEdit->text().toDouble() < _lectfLineEdit->text().toDouble())
        calculateKwh();
}
void View::Management::RegistDialog::detailRate()
{
    Model::Domain::Rate *rate = Model::Management::RateManager::get(Model::Management::RateManager::getAllNames().value(_rateComboBox -> currentText()));
    RateViewer *viewer = new RateViewer(rate);
    viewer->exec();

}


void View::Management::RegistDialog::selectEntity()
{
    View::Management::EntitySelector selector(View::Management::CreateAndSelect, this);

    if(selector.exec()) {
        Model::Domain::Entity *entity = selector.entity();
        _regist -> setEntity(entity);
        _entityIdLineEdit -> setText(QString::number(entity -> id()));
        _entityNameLineEdit -> setText(entity -> name());
        _entityFolioLineEdit -> setText(QString::number(entity ->folio()));
        _detailEntityPushButton -> setEnabled(true);

        QList<Model::Domain::Regist *> *regists = Model::Management::RegistManager::getByEntity(entity -> id());
        if (!regists->isEmpty())
            _lectiLineEdit->setText(QString::number(regists->takeLast()->lectf(),'f', MAX_MONEY_PRECISION));

    }
}

void View::Management::RegistDialog::detailEntity()
{
    View::Management::EntityViewer viewer(_regist -> entity());
    viewer.exec();
}

void View::Management::RegistDialog::createWidgets()
{
    createIdWidgets();

    QGridLayout *idLayout = new QGridLayout;
    idLayout -> addWidget(_idLabel, 0, 0, 1, 1);
    idLayout -> addWidget(_idLineEdit, 0, 1, 1, 1);
    //idLayout -> addWidget(_autoIdCheckBox, 2, 1, 1, 1);

    idLayout -> addWidget(_dateLabel, 3, 0, 1, 1);
    idLayout -> addWidget(_dateEdit, 3, 1, 1, 1);

    idLayout -> addWidget(_timeLabel, 4, 0, 1, 1);
    idLayout -> addWidget(_timeEdit, 4, 1, 1, 1);

    idLayout -> addWidget(_calImportCheckBox, 5, 1, 1, 1);
    idLayout -> addWidget(_rateLabel, 5, 0, 1, 1);
    idLayout -> addWidget(_rateComboBox, 6, 1, 1, 1);
    idLayout -> addWidget(_detailRatePushButton, 6, 0, 1, 1);
    QGroupBox *idGroupBox = new QGroupBox(trUtf8("&Detalles"));
    idGroupBox -> setLayout(idLayout);


    createEntityWidgets();

    QGridLayout *entityLayout = new QGridLayout;
    entityLayout -> addWidget(_detailEntityPushButton, 0, 0);
    entityLayout -> addWidget(_selectEntityPushButton, 0, 1);
    entityLayout -> addWidget(_entityIdLabel, 1, 0);
    entityLayout -> addWidget(_entityIdLineEdit, 1, 1);
    entityLayout -> addWidget(_entityNameLabel, 2, 0, 1, 1);
    entityLayout -> addWidget(_entityNameLineEdit, 2, 1, 1, 1);
    entityLayout -> addWidget(_entityFolioLabel, 3, 0, 1, 1);
    entityLayout -> addWidget(_entityFolioLineEdit, 3, 1, 1, 1);

    QGroupBox *entityGroupBox = new QGroupBox(trUtf8("&Empresa"));
    entityGroupBox -> setLayout(entityLayout);

    QHBoxLayout *topLayout = new QHBoxLayout;
    topLayout -> addWidget(idGroupBox);
    topLayout -> addWidget(entityGroupBox);

    createRegistWidgets();

    QGridLayout *registLayout = new QGridLayout;
    registLayout -> addWidget(_lectiLabel, 0, 0, 1, 1);
    registLayout -> addWidget(_lectiLineEdit, 1, 0, 1, 1);

    registLayout -> addWidget(_lectfLabel, 2, 0, 1, 1);
    registLayout -> addWidget(_lectfLineEdit, 3, 0, 1, 1);

    QGroupBox *registGroupBox = new QGroupBox(trUtf8("&Lecturas"));
    registGroupBox -> setLayout(registLayout);


    QGridLayout *consLayout = new QGridLayout;
    consLayout -> addWidget(_kwhLabel, 0, 0, 1, 1);
    consLayout -> addWidget(_kwhLineEdit, 1, 0, 1, 1);

    consLayout -> addWidget(_importLabel, 2, 0, 1, 1);
    consLayout -> addWidget(_importLineEdit, 3, 0, 1, 1);

    QGroupBox *consGroupBox = new QGroupBox(trUtf8("&Consumo"));
    consGroupBox -> setLayout(consLayout);

    QHBoxLayout *centerLayout = new QHBoxLayout;
    centerLayout -> addWidget(registGroupBox);
    centerLayout -> addWidget(consGroupBox);


    QHBoxLayout *bottomLayout = new QHBoxLayout;

    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_saveButton);
    bottomLayout -> addWidget(_cancelButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addLayout(topLayout);
    mainLayout -> addLayout(centerLayout);
    mainLayout -> addLayout(bottomLayout);
    setLayout(mainLayout);


}

void View::Management::RegistDialog::createIdWidgets()
{
    _idLabel = new QLabel(trUtf8("&Id:"));
    _idLineEdit = new QLineEdit;
    _idLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _idLineEdit ->setReadOnly(true);
    _idLabel -> setBuddy(_idLineEdit);

    _dateLabel = new QLabel(trUtf8("&Fecha:"));
    _dateEdit = new QDateEdit;
    _dateEdit->setDisplayFormat(DATE_FORMAT);
    _dateEdit->setDate(QDate::currentDate());
    _dateEdit->setAlignment(Qt::AlignCenter);
    _dateEdit->setCalendarPopup(true);
    _dateLabel -> setBuddy(_dateEdit);

    _timeLabel = new QLabel(trUtf8("&Hora:"));
    _timeEdit = new QTimeEdit;
    _timeEdit->setDisplayFormat(TIME_FORMAT);
    _timeEdit->setTime(QTime::currentTime());
    _timeEdit->setAlignment(Qt::AlignCenter);
    _timeLabel -> setBuddy(_timeEdit);


    _calImportCheckBox = new QCheckBox(trUtf8("&Calcular Importe"));
    _rateLabel = new QLabel(trUtf8("&Tarifa:"));
    _rateComboBox = new QComboBox;
    _rateComboBox -> setEnabled(false);
    _rateComboBox -> addItem("Seleccionar...");
    _rateComboBox -> addItems(Model::Management::RateManager::getAllNames().keys());
    _rateLabel -> setBuddy(_idLineEdit);

    _detailRatePushButton = new QPushButton;
    _detailRatePushButton -> setIcon(QIcon(":/images/about.png"));
    _detailRatePushButton -> setFixedSize(_detailRatePushButton -> sizeHint());
    _detailRatePushButton -> setEnabled(_calImportCheckBox -> isChecked());


}

void View::Management::RegistDialog::createEntityWidgets()
{
    _entityIdLabel = new QLabel(trUtf8("I&d:"));
    _entityIdLineEdit = new QLineEdit;
    _entityIdLineEdit -> setEnabled(false);
    _entityIdLabel -> setBuddy(_entityIdLineEdit);

    _entityNameLabel = new QLabel(trUtf8("&Nombre:"));
    _entityNameLineEdit = new QLineEdit;
    _entityNameLineEdit -> setEnabled(false);
    _entityNameLabel -> setBuddy(_entityNameLineEdit);

    _entityFolioLabel = new QLabel(trUtf8("&Folio:"));
    _entityFolioLineEdit = new QLineEdit;
    _entityFolioLineEdit -> setEnabled(false);
    _entityFolioLabel -> setBuddy(_entityFolioLineEdit);

    _selectEntityPushButton = new QPushButton(trUtf8("&Seleccionar"));
    _selectEntityPushButton -> setIcon(QIcon(":/images/entity.png"));

    _detailEntityPushButton = new QPushButton;
    _detailEntityPushButton -> setIcon(QIcon(":/images/about.png"));
    _detailEntityPushButton -> setFixedSize(_detailEntityPushButton -> sizeHint());
    _detailEntityPushButton -> setEnabled(_regist ->entity());
}

void View::Management::RegistDialog::createRegistWidgets()
{

    _lectiLabel = new QLabel(trUtf8("&Lectura inicial: <em>ej, 241 ó 8.30</em>"));
    _lectiLineEdit = new QLineEdit;
    _lectiLineEdit -> setValidator(new QRegExpValidator(QRegExp("[0-9]+(.[0-9]+)?"), this));
    _lectiLineEdit->setAlignment(Qt::AlignCenter);
    _lectiLabel -> setBuddy(_lectiLineEdit);

    _lectfLabel = new QLabel(trUtf8("&Lectura final: <em>ej, 295 ó 9.25</em>"));
    _lectfLineEdit = new QLineEdit;
    _lectfLineEdit -> setValidator(new QRegExpValidator(QRegExp("[0-9]+(.[0-9]+)?"), this));
    _lectfLineEdit -> setAlignment(Qt::AlignCenter);
    _lectfLabel -> setBuddy(_lectfLineEdit);


    _kwhLabel = new QLabel(trUtf8("Kw/h Consumidos:"));
    _kwhLineEdit = new QLineEdit;
    _kwhLineEdit->setReadOnly(true);
    _kwhLineEdit -> setAlignment(Qt::AlignCenter);
    _kwhLabel->setBuddy(_kwhLineEdit);

    _importLabel = new QLabel(trUtf8("Importe a pagar: $ "));
    _importLineEdit = new QLineEdit;
    _importLineEdit->setEnabled(false);
    _importLineEdit->setReadOnly(true);
    _importLineEdit -> setAlignment(Qt::AlignCenter);
    _importLabel->setBuddy(_importLineEdit);


    _saveButton = new QPushButton(trUtf8("&Guardar"));
    _saveButton -> setIcon(QIcon(":/images/save.png"));
    _saveButton -> setDefault(true);
    _saveButton -> setEnabled(false);
    _cancelButton = new QPushButton(trUtf8("&Cancelar"));
    _cancelButton -> setIcon(QIcon(":/images/cancel.png"));


}

void View::Management::RegistDialog::createConnections()
{
    connect(_dateEdit, SIGNAL(dateChanged(QDate)),
            this, SLOT(registModified()));
    connect(_timeEdit, SIGNAL(timeChanged(QTime)),
            this, SLOT(registModified()));
    connect(_calImportCheckBox, SIGNAL(stateChanged(int)),
            this, SLOT(selectRate()));
    connect(_rateComboBox, SIGNAL(currentIndexChanged(int)),
            this, SLOT(selectedRate()));
    connect(_detailRatePushButton, SIGNAL(clicked()),
            this, SLOT(detailRate()));
    connect(_kwhLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(registModified()));
    connect(_importLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(registModified()));
    connect(_entityNameLineEdit, SIGNAL(textChanged(QString)),
                this, SLOT(registModified()));
    connect(_entityFolioLineEdit, SIGNAL(textChanged(QString)),
                this, SLOT(registModified()));
    connect(_lectiLineEdit, SIGNAL(textChanged(QString)),
                this, SLOT(registModified()));
    connect(_lectfLineEdit, SIGNAL(textChanged(QString)),
                this, SLOT(registModified()));
    connect(_selectEntityPushButton, SIGNAL(clicked()),
            this, SLOT(selectEntity()));
    connect(_detailEntityPushButton, SIGNAL(clicked()),
            this, SLOT(detailEntity()));
    connect(_lectiLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(on_lectiLabel_textChanged()));
    connect(_lectfLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(on_lectfLabel_textChanged()));
    connect(_saveButton, SIGNAL(clicked()),
            this, SLOT(accept()));
    connect(_cancelButton, SIGNAL(clicked()),
            this, SLOT(reject()));
}

void View::Management::RegistDialog::loadRegist()
{
    int precisionMoney = MAX_MONEY_PRECISION;

    _idLineEdit -> setText(IS_NEW(_regist -> id()) ? QString::number(Model::Management::RegistManager::getId()) :
                                                      QString::number(_regist -> id()));

    _entityIdLineEdit -> setText((_regist -> entity() ? QString::number(_regist -> entity() -> id()) : ""));
    _entityNameLineEdit-> setText((_regist -> entity() ? _regist -> entity() -> name() : ""));
    _entityFolioLineEdit -> setText((_regist -> entity() ? QString::number(_regist -> entity() -> folio()) : ""));

    _dateEdit->setDate(_regist->date());
    _timeEdit->setTime(_regist->time());
    _lectfLineEdit->setText(_regist->lectf() ? QString::number(_regist->lectf(),'f', precisionMoney) : "");
    _lectiLineEdit->setText(_regist->lecti() ? QString::number(_regist->lecti(),'f', precisionMoney) : "");
    _kwhLineEdit->setText(QString("%1 Kw/h").arg(QString::number(_regist->kwh(),'f', precisionMoney)));
    _importLineEdit->setText(QString("%1 $").arg(QString::number(_regist->import(),'f', precisionMoney)));
    registModified(false);

    }

void View::Management::RegistDialog::saveRegist()
{
    _regist -> setId(_idLineEdit -> text().toInt());
    _regist ->setEntity(Model::Management::EntityManager::get(_entityIdLineEdit ->text().toInt()));
    _regist ->setEntityFolio(_entityFolioLineEdit ->text().toInt());
    _regist ->setEntityName(_entityNameLineEdit ->text());
    _regist ->setDate(_dateEdit->date());
    _regist ->setTime(_timeEdit->time());
    _regist ->setLectI(_lectiLineEdit->text().toDouble());
    _regist ->setLectF(_lectfLineEdit->text().toDouble());
    _regist ->setKwh(_kwhLineEdit->text().split(' ').takeFirst().toDouble());
    _regist ->setImport(_importLineEdit -> text().split(' ').takeFirst().toDouble());
}

void View::Management::RegistDialog::on_lectiLabel_textChanged()
{
    calculateKwh();
}

void View::Management::RegistDialog::on_lectfLabel_textChanged()
{
     calculateKwh();
}

void View::Management::RegistDialog::calculateKwh()
{
    if ( _lectfLineEdit->text().toDouble() > _lectiLineEdit->text().toDouble()) {
       int precisionMoney = MAX_MONEY_PRECISION;
       double kw_h = 0.0;
       double kw_hDisplay = 0.0;

       kw_h =  _lectfLineEdit->text().toDouble() - _lectiLineEdit->text().toDouble();
       kw_hDisplay = kw_h;
       _kwhLineEdit->setText(QString("%1 Kw/h").arg(QString::number(kw_hDisplay, 'f', precisionMoney)));

       if (_calImportCheckBox->isChecked() && _rateComboBox->currentIndex() > 0){
           Model::Domain::Rate *rate = Model::Management::RateManager::get(Model::Management::RateManager::getAllNames().value(_rateComboBox -> currentText()));     
           calculateImport(kw_h, rate);

           }
       }
}

void View::Management::RegistDialog::calculateImport(double kwh, Model::Domain::Rate *rate)
{
    int precisionMoney = MAX_MONEY_PRECISION;

    QList<Model::Domain::Range *> *ranges = Model::Management::RangeManager::getByRate(rate->id());
    int rangesNumber = ranges->count();
    double import = 0.0;

    for (int range = 0; range <  rangesNumber && kwh > 0; ++range)
    {
        //int maxKwh = ranges->at(range)->toNumber() - ranges->at(range == 0 ? range : range - 1)->toNumber();
        int maxKwh = ranges->at(range)->toNumber() - ranges->at(range)->fromNumber();
        double price = ranges->at(range)->price();
        if (kwh > maxKwh)
        {
            import += maxKwh * price;
            kwh -= maxKwh;
        }
        else
        {
            import += kwh * price;
            kwh = 0;
        }
    }
    if (kwh > 0)
    {
        import += kwh * rate->moreofPrice();
    }

    _importLineEdit->setText(QString("%1 $").arg(QString::number(import,'f', precisionMoney)));

}

bool View::Management::RegistDialog::isSaveable()
{
    return !(_entityIdLineEdit -> text().isEmpty()) &&
           !(_entityNameLineEdit -> text().isEmpty()) &&
           !(_entityFolioLineEdit -> text().isEmpty()) &&
           !(_lectiLineEdit -> text().isEmpty()) &&
           !(_lectfLineEdit -> text().isEmpty()) &&
           !(_kwhLineEdit -> text().isEmpty()) &&
           !(_importLineEdit -> text().isEmpty());
}

