/**
*   Copyright 2021 Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "mainwindow.h"
#include "entityeditor.h"
#include "registeditor.h"
#include "entitymodel.h"
#include "registmodel.h"
#include "registmanager.h"
#include "entitymanager.h"
#include "registdialog.h"
#include "getregist.h"
#include "regist.h"
#include <QtGui>

View::Management::RegistEditor::RegistEditor(QWidget *parent)
    : QWidget(parent)
{

    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Editor de registros"));
    setWindowIcon(QIcon(":/images/loadinvoice.png"));
    setMinimumWidth(REGIST_EDITOR_MINIMUM_WIDTH);
    setAttribute(Qt::WA_DeleteOnClose);
}

void View::Management::RegistEditor::closeEvent(QCloseEvent *event)
{
    emit finished();
    event->accept();
}

void View::Management::RegistEditor::rowSelectionChanged()
{
    int row = _registsTableView ->currentIndex().row();

    _modRegistButton -> setEnabled(row != -1);
    _delRegistButton -> setEnabled(row != -1);
}



void View::Management::RegistEditor::addRegist()
{

    Model::Domain::Regist *regist = new Model::Domain::Regist;
    RegistDialog dialog(regist, this);

    if(dialog.exec()) {
        if(Model::Management::RegistManager::create(*regist)) {
           int row = _registModel -> rowCount(QModelIndex());
            _registModel -> insertRegist(row, regist);

        } else {
            QMessageBox::critical(this, trUtf8("Error"),
                                  trUtf8("Error añadiendo el registro"),
                                  QMessageBox::Ok);
            delete regist;
        }
        rowSelectionChanged();
    } else
        delete regist;


}

void View::Management::RegistEditor::modRegist()
{
    int row = _registsTableView -> currentIndex().row();
    Model::Domain::Regist *regist = _registModel -> regists() -> at(row);

    RegistDialog dialog(regist, this);

    if(dialog.exec()) {
        if(Model::Management::RegistManager::modify(*regist))
            _registModel -> modifyRegist(row);
        else
            QMessageBox::critical(this, trUtf8("Error"),
                                  trUtf8("Error midificando el registro"),
                                  QMessageBox::Ok);
        rowSelectionChanged();
    }

}

void View::Management::RegistEditor::delRegist()
{
    if(!verifyDeleteRegist())
        return;

    int row = _registsTableView -> currentIndex().row();
    Model::Management::RegistManager::remove(_registModel -> regists() -> at(row) -> id());
    _registModel -> removeRegist(row);
    rowSelectionChanged();

}
void View::Management::RegistEditor::getRegists()
{
    int _model = 0;
    int &model = _model;

    int _entityId = 0;
    int  &entityId = _entityId;

    QDate _beginDate =  QDate::currentDate();
    QDate &beginDate = _beginDate;

    QDate _endDate = QDate::currentDate();
    QDate &endDate = _endDate;

    GetRegist dialog(model, entityId, beginDate, endDate, this);

    if(dialog.exec()) {
        switch(_model) {
                case 0:{
                    _registModel = new RegistModel(Model::Management::RegistManager::getAll());
                    break;
                    }
                case 1:{
                    _registModel = new RegistModel(Model::Management::RegistManager::getByEntity(_entityId));
                    break;
                    }
                case 2:{
                    _registModel = new RegistModel(Model::Management::RegistManager::getByDateRange(_beginDate, _endDate));
                    break;
                    }
                case 3:{
                    _registModel = new RegistModel(Model::Management::RegistManager::getByEntityANDateRange(_entityId, _beginDate, _endDate));
                    break;
                    }
                }

                _registsTableView->setModel(_registModel);

                connect(_registsTableView -> selectionModel(), SIGNAL(selectionChanged(QItemSelection, QItemSelection)),
                        this, SLOT(rowSelectionChanged()));

                rowSelectionChanged();
    } else {
        QMessageBox::critical(this, trUtf8("Búsqueda"),
                                    trUtf8("Operación cancelada."),
                                    QMessageBox::Ok);

    }



}

void View::Management::RegistEditor::createWidgets()
{

    createRegistWidgets();

    QGridLayout *registsLayout = new QGridLayout;
    registsLayout -> addWidget(_registsTableView, 0, 0, 1, 6);
    registsLayout -> addWidget(_getRegistButton, 1, 0, 1, 1);
    registsLayout -> addWidget(_addRegistButton, 1, 3, 1, 1);
    registsLayout -> addWidget(_modRegistButton, 1, 4, 1, 1);
    registsLayout -> addWidget(_delRegistButton, 1, 5, 1, 1);

    QGroupBox *registsGroupBox = new QGroupBox(trUtf8("&Lista de registros"));
    registsGroupBox -> setLayout(registsLayout);


    _closeButton = new QPushButton(trUtf8("&Cerrar"));
    _closeButton -> setIcon(QIcon(":/images/ok.png"));
    _closeButton -> setFixedSize(_closeButton -> sizeHint());

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_closeButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addWidget(registsGroupBox);
    mainLayout -> addLayout(bottomLayout);

    setLayout(mainLayout);

}

void View::Management::RegistEditor::createRegistWidgets()
{
    _registsTableView = new QTableView;
    _registModel = new RegistModel(Model::Management::RegistManager::getByDateRange(QDate::currentDate(), QDate::currentDate()));
    _registsTableView -> setModel(_registModel);
    _registsTableView -> setShowGrid(false);
    _registsTableView -> setColumnWidth(ColumnRegistId,             COLUMN_REGIST_ID_WIDTH);
    _registsTableView -> setColumnWidth(ColumnRegistEntityFolio,    COLUMN_REGIST_ENTITYFOLIO_WIDTH);
    _registsTableView -> setColumnWidth(ColumnRegistEntityName,     COLUMN_REGIST_ENTITYNAME_WIDTH);
    _registsTableView -> setColumnWidth(ColumnRegistDate,           COLUMN_REGIST_DATE_WIDTH);
    _registsTableView -> setColumnWidth(ColumnRegistTime,           COLUMN_REGIST_TIME_WIDTH);
    _registsTableView -> setColumnWidth(ColumnRegistLectI,          COLUMN_REGIST_LECTI_WIDTH);
    _registsTableView -> setColumnWidth(ColumnRegistLectF,          COLUMN_REGIST_LECTF_WIDTH);
    _registsTableView -> setColumnWidth(ColumnRegistKwh,            COLUMN_REGIST_KWH_WIDTH);
    _registsTableView -> setColumnWidth(ColumnRegistImport,         COLUMN_REGIST_IMPORT_WIDTH);

    _registsTableView->setColumnHidden(ColumnRegistId, true);

    _registsTableView -> setSelectionMode(QAbstractItemView::SingleSelection);
    _registsTableView -> setSelectionBehavior(QAbstractItemView::SelectRows);
    _registsTableView -> setEditTriggers(QAbstractItemView::NoEditTriggers);
    _registsTableView -> setFocusPolicy(Qt::NoFocus);


    _getRegistButton = new QPushButton(trUtf8("&Buscar"));
    _getRegistButton -> setIcon(QIcon(":/images/search.png"));
    _addRegistButton = new QPushButton(trUtf8("&Añadir"));
    _addRegistButton -> setIcon(QIcon(":/images/add.png"));
    _modRegistButton = new QPushButton(trUtf8("E&ditar"));
    _modRegistButton -> setIcon(QIcon(":/images/modify.png"));
    _modRegistButton -> setEnabled(false);
    _delRegistButton = new QPushButton(trUtf8("&Eliminar"));
    _delRegistButton -> setIcon(QIcon(":/images/delete.png"));
    _delRegistButton -> setEnabled(false);
}


void View::Management::RegistEditor::createConnections()
{
    connect(_registsTableView -> selectionModel(), SIGNAL(selectionChanged(QItemSelection, QItemSelection)),
            this, SLOT(rowSelectionChanged()));
    connect(_registsTableView, SIGNAL(doubleClicked(QModelIndex)),
            this, SLOT(modRegist()));
    connect(_getRegistButton, SIGNAL(clicked()),
            this, SLOT(getRegists()));
    connect(_addRegistButton, SIGNAL(clicked()),
            this, SLOT(addRegist()));
    connect(_modRegistButton, SIGNAL(clicked()),
            this, SLOT(modRegist()));
    connect(_delRegistButton, SIGNAL(clicked()),
            this, SLOT(delRegist()));
    connect(_closeButton, SIGNAL(clicked()),
            this, SLOT(close()));
}


bool View::Management::RegistEditor::verifyDeleteRegist()
{
    return QMessageBox::question(this, trUtf8("Confirmar eliminación"),
                                       trUtf8("Todos los datos de este registro serán aliminados.\n"
                                          "¿desea continuar?"),
                                       QMessageBox::Yes | QMessageBox::Default |
                                       QMessageBox::No) == QMessageBox::Yes;
}


