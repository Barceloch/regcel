/**
*   Copyright 2021 Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "registmodel.h"
#include "regist.h"
#include "persistencemanager.h"
#include "types.h"

View::Management::RegistModel::~RegistModel()
{
    if(_regists) {
        foreach(Model::Domain::Regist *regist, *_regists)
            delete regist;

        delete _regists;
    }
}

QList<Model::Domain::Regist *> *View::Management::RegistModel::regists()
{
    return _regists;
}

void View::Management::RegistModel::setRegists(QList<Model::Domain::Regist *> *regists)
{
    _regists = regists;
    reset();
}

bool View::Management::RegistModel::insertRegist(int k, Model::Domain::Regist *regist)
{
    if(k < 0  || k > _regists -> size())
        return false;

    _regists -> insert(k, regist);
    reset();

    return true;
}

bool View::Management::RegistModel::modifyRegist(int k)
{
    if(k < 0  || k > _regists -> size())
        return false;

    reset();

    return true;
}

bool View::Management::RegistModel::removeRegist(int k)
{
    if(k < 0  || k > _regists -> size())
        return false;

    delete _regists -> at(k);
    _regists -> removeAt(k);
    reset();

    return true;
}

int View::Management::RegistModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);

    return _regists -> size();
}

int View::Management::RegistModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);

    return ColumnRegistCount;
}

QVariant View::Management::RegistModel::data(const QModelIndex &index, int role) const
{
    if(index.isValid()) {
        if(role == Qt::TextAlignmentRole) {
            switch(index.column()) {
            case ColumnRegistId:
                return int(Qt::AlignCenter);
            case ColumnRegistEntityFolio:
                return int(Qt::AlignCenter);
            case ColumnRegistEntityName:
                return int(Qt::AlignLeft | Qt::AlignVCenter);
            case ColumnRegistDate:
                return int(Qt::AlignCenter);
            case ColumnRegistTime:
                return int(Qt::AlignVCenter);
            case ColumnRegistLectI:
                return int(Qt::AlignVCenter);
            case ColumnRegistLectF:
                return int(Qt::AlignVCenter);
            case ColumnRegistKwh:
               return int(Qt::AlignVCenter);
            default:
                return int(Qt::AlignRight | Qt::AlignVCenter);

            }

        } else if(role == Qt::DisplayRole) {
            Model::Domain::Regist *regist = _regists -> at(index.row());
            switch(index.column()) {
            case ColumnRegistId:
                return QString::number(regist -> id());
            case ColumnRegistEntityFolio:
                return regist ->entityFolio();
            case ColumnRegistEntityName:
                return regist ->entityName();
            case ColumnRegistDate:
                return QDate(regist -> date()).toString(DATE_FORMAT);
            case ColumnRegistTime:
                return QTime(regist -> time()).toString(TIME_FORMAT);
            case ColumnRegistLectI:
                return QString::number(regist ->lecti(), 'f', MAX_MONEY_PRECISION);
            case ColumnRegistLectF:
                return QString::number(regist ->lectf(), 'f', MAX_MONEY_PRECISION);
            case ColumnRegistKwh:
                return QString("%1 kw/h").arg(QString::number(regist ->kwh(), 'f', MAX_MONEY_PRECISION));
            case ColumnRegistImport:
                return QString("%1 $").arg(QString::number(regist -> import(), 'f', MAX_MONEY_PRECISION));
            }
        }
    }

    return QVariant();
}

QVariant View::Management::RegistModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if(role == Qt::DisplayRole) {
        if(orientation == Qt::Vertical)
            return QString::number(section + 1);
        else {
            switch(section) {
            case ColumnRegistId:
                return QObject::trUtf8("ID");
            case ColumnRegistEntityFolio:
                return QObject::trUtf8("Folio");
            case ColumnRegistEntityName:
                return QObject::trUtf8("Entidad");
            case ColumnRegistDate:
                return QObject::trUtf8("Fecha");
            case ColumnRegistTime:
                return QObject::trUtf8("Hora");
            case ColumnRegistLectI:
                return QObject::trUtf8("L. inicial");
            case ColumnRegistLectF:
                return QObject::trUtf8("L. final");
            case ColumnRegistKwh:
                return QObject::trUtf8("Consumo");
            case ColumnRegistImport:
                return QObject::trUtf8("Importe");
            }
        }
    }

    return QVariant();
}

