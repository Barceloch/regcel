/**
*   Copyright 2021 Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "registerdialog.h"
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>

View::RegisterDialog::RegisterDialog(QWidget *parent)
    : QDialog(parent)
{
    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Registrar contraseña"));
    setWindowIcon(QIcon(":/images/password.png"));
    setFixedSize(sizeHint());
}

void View::RegisterDialog::done(int result)
{
    if(result)
        _password = _passLineEdit -> text();

    QDialog::done(result);
}

const QString View::RegisterDialog::password() const
{
    return _password;
}

void View::RegisterDialog::textChangedOnLineEdit()
{
    QString pass = _passLineEdit -> text();
    QString rePass = _rePassLineEdit -> text();
    _okPushButton -> setEnabled(!pass.isEmpty() && !rePass.isEmpty() && pass == rePass);
}

void View::RegisterDialog::createWidgets()
{
    _passLabel = new QLabel(trUtf8("&Contraseña:"));
    _passLineEdit = new QLineEdit;
    _passLineEdit -> setEchoMode(QLineEdit::Password);
    _passLabel -> setBuddy(_passLineEdit);

    _rePassLabel = new QLabel(trUtf8("&Re-Contraseña:"));
    _rePassLineEdit = new QLineEdit;
    _rePassLineEdit -> setEchoMode(QLineEdit::Password);
    _rePassLabel -> setBuddy(_rePassLineEdit);

    QGridLayout *topLayout = new QGridLayout;
    topLayout -> addWidget(_passLabel, 0, 0);
    topLayout -> addWidget(_passLineEdit, 0, 1);
    topLayout -> addWidget(_rePassLabel, 1, 0);
    topLayout -> addWidget(_rePassLineEdit, 1, 1);

    _okPushButton = new QPushButton(trUtf8("&Ok"));
    _okPushButton -> setIcon(QIcon(":/images/ok.png"));
    _okPushButton -> setDefault(true);
    _okPushButton -> setEnabled(false);

    _cancelPushButton = new QPushButton(trUtf8("&Cancelar"));
    _cancelPushButton -> setIcon(QIcon(":/images/cancel.png"));

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_okPushButton);
    bottomLayout -> addWidget(_cancelPushButton);
    bottomLayout -> addStretch();

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addLayout(topLayout);
    mainLayout -> addLayout(bottomLayout);

    setLayout(mainLayout);
}

void View::RegisterDialog::createConnections()
{
    connect(_passLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(textChangedOnLineEdit()));
    connect(_rePassLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(textChangedOnLineEdit()));
    connect(_okPushButton, SIGNAL(clicked()),
            this, SLOT(accept()));
    connect(_cancelPushButton, SIGNAL(clicked()),
            this, SLOT(reject()));
}
