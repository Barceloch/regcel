/**
*   Copyright � (2021) - Yunior Barcel� Ch�vez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef GLOBAL_H
#define GLOBAL_H

#include "types.h"
#include <QDesktopServices>

// Application Properties
#define ORGANIZATION_NAME     "BarSoft"
#define ORGANIZATION_DOMAIN   "https://barsoft.cubava.cu/"
#define AUTHOR_NAME           "Yunior Barcel� Ch�vez"
#define AUTHOR_EMAIL          "barceloch@gmail.com"
#define APPLICATION_NAME      "RegCEl"
#define APPLICATION_NAME_LONG "Registro para el Consumo El�ctrico"
#define APPLICATION_VERSION   "v0.1.3"
#define APPLICATION_YEARS     "2021"
#define APPLICATION_WEB       "https://barsoft.cubava.cu/regcel/"

// Configuration Default Values
#define DEFAULT_APPLICATION_CURRENCY                    "MN"
#define DEFAULT_APPLICATION_MONEY_PRECISION             MAX_MONEY_PRECISION
#define DEFAULT_STORAGE_TYPE                            Persistence::SQLITE
#define DEFAULT_STORAGE_PATH                            QDesktopServices::storageLocation(QDesktopServices::DataLocation)
#define DEFAULT_STORAGE_DBMS_DRIVER                     "QSQLITE"
#define DEFAULT_STORAGE_DBMS_NAME                       DEFAULT_STORAGE_PATH.append("/regcel.db")
#define DEFAULT_STORAGE_DBMS_HOST                       "localhost"
#define DEFAULT_STORAGE_DBMS_PORT                       0
#define DEFAULT_STORAGE_DBMS_USER                       ""
#define DEFAULT_STORAGE_DBMS_PASS                       ""


#endif // GLOBAL_H
