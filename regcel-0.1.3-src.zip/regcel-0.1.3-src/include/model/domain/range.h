/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef RANGE_H
#define RANGE_H

#include <iostream>
#include "types.h"

namespace Model
{
    namespace Domain
    {

        class Rate;

        class Range
        {
            friend std::ostream &operator<<(std::ostream &os, const Range &range);
        public:
            Range(int id = NO_ID);

            Range(const Range &range);
            ~Range();
            Range &operator=(const Range &range);
            bool operator==(const Range &range) const;
            bool operator!=(const Range &range) const;


            void setId(int id);
            int id() const;

            void setRate(Rate *rate);
            Rate *rate() const;

            void setFromNumber(int fromNumber);
            int fromNumber() const;

            void setToNumber(int toNumber);
            int toNumber() const;

            void setPrice(double price);
            double price() const;


        private:
            int _id;
            Rate *_rate;
            int _fromNumber;
            int _toNumber;
            double _price;
        };
    }
}

#endif // RANGE_H
