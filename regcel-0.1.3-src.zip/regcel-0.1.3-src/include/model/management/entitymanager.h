/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef ENTITYMANAGER_H
#define ENTITYMANAGER_H

#include <QList>
#include <QMap>
#include "entity.h"

namespace Model
{
    namespace Management
    {
        class EntityManager
        {
        public:
            static bool create(const Model::Domain::Entity &entity);
            static bool modify(const Model::Domain::Entity &entity);
            static bool remove(int id);
            static Model::Domain::Entity *get(int id);
            static QMap<QString, int> getAllNames();
            static QList<Model::Domain::Entity *> *getAll();
            static int getId();

        };
    }
}

#endif // ENTITYMANAGER_H
