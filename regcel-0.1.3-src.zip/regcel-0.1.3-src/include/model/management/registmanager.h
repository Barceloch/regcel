/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef REGISTMANAGER_H
#define REGISTMANAGER_H
#include <QList>
#include "regist.h"

namespace Model
{
    namespace Management
    {
        class RegistManager
        {
        public:
            static bool create(const Model::Domain::Regist &regist);
            static bool modify(const Model::Domain::Regist &regist);
            static bool remove(int id);
            static Model::Domain::Regist *get(int id);
            static QList<Model::Domain::Regist *> *getAll();
            static QList<Model::Domain::Regist *> *getByEntity(int entityId);
            static QList<Model::Domain::Regist *> *getByDateRange(const QDate &beginDate = QDate::currentDate(), const QDate &endDate = QDate::currentDate());
            static QList<Model::Domain::Regist *> *getByEntityANDateRange(int entityId, const QDate &beginDate = QDate::currentDate(), const QDate &endDate = QDate::currentDate());
            static int getId();
        };
    }
}

#endif // REGISTMANAGER_H
