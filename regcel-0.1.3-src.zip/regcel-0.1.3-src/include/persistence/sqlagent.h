/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef SQLAGENT_H
#define SQLAGENT_H

#include <QString>
#include <QVector>
#include <QVariant>

QT_BEGIN_NAMESPACE
class QSqlDatabase;
QT_END_NAMESPACE

namespace Persistence
{

    class SQLAgentException
    {
    public:
        SQLAgentException(const QString &message = QString()) : _message(message) {}
        const QString &message() const
        {
            return _message;
        }
    protected:
        QString _message;
    };

    class SQLAgent
    {
    public:
        static SQLAgent *instance();
        ~SQLAgent();
        bool connect();
        void disconnect();
        bool isConnected();
        bool create(const QString &sql);
        bool insert(const QString &sql);
        bool update(const QString &sql);
        QVector<QVector<QVariant> > *select(const QString &sql);
        bool _delete(const QString &sql);
    private:
        SQLAgent();
        bool manipulation(const QString &sql);
        QVector<QVector<QVariant> > *query(const QString &sql);
    protected:        
        static SQLAgent *_instance;
        QSqlDatabase *_database;
    };
}

#endif // SQLAGENT_H
