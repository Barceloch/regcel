/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef AUTHDIALOG_H
#define AUTHDIALOG_H

#include <QDialog>

QT_BEGIN_NAMESPACE
class QLabel;
class QLineEdit;
class QPushButton;
QT_END_NAMESPACE

namespace View
{
    class AuthDialog : public QDialog
    {
        Q_OBJECT
    public:
        AuthDialog(QWidget *parent = 0);
        void done(int result);
        const QString password() const;
    private slots:
        void textChangedOnLineEdit();
    private:
        void createWidgets();
        void createConnections();

        QLabel *_authLabel;
        QLineEdit *_authLineEdit;
        QPushButton *_okPushButton;
        QPushButton *_cancelPushButton;
        QString _password;
    };
}

#endif // AUTHDIALOG_H
