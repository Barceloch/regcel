/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include <QDate>
#include "types.h"

QT_BEGIN_NAMESPACE
class QMdiArea;
class QMdiSubWindow;
class QAction;
class QMenu;
class QToolBar;
class QLabel;
class QTextEdit;
class QDateEdit;
class QPrinter;
QT_END_NAMESPACE

namespace Model
{
    namespace Domain
    {
        class Entity;
    }
}

namespace View
{
    namespace Invoicing
    {
        class InvoiceEditor;
    }
    namespace Management
    {
        class EntityEditor;
        class RegistEditor;
        class RatesEditor;
        class RangesEditor;
        class RegistModel;
    }

    class MainWindow : public QMainWindow
    {
        Q_OBJECT
    public:
        MainWindow();
        ~MainWindow();
    protected:
        void closeEvent(QCloseEvent *event);
    public slots:
        bool firstExecution();
        bool login();
    private slots:
        void connectStorage();
        void disconnectStorage();
        void importStorage();
        void exportStorage();
        void manageRegist();
        void manageEntity();
        void manageRate();

        void createInvoice();
        void printEnabled();
        void printDisabled();

        void printInvoicePreview();
        void printInvoice();
        void exportInvoiceToPdf();

        void deleteEntityEditor();
        void deleteRatesEditor();
        void deleteRegistEditor();
        void deleteInvoiceEditor();
        void deleteAllEditors();

        void changuePassw();

        void about();
        void updateWindowMenu();
        void updateOtherWindows(QObject *object);
    private:
        void createWidgets();
        void createCentralWidget();
        void createActions();
        void createMenus();
        void createToolBar();
        void createStatusBar();
        void createConnections();

        void closeOtherWindows();
        void setStorageConnected(bool connected = true);      
        bool verifyImportStorage();
        bool verifyExit();

        QMdiArea *_mdiArea;

        QAction *_connectStorageAction;
        QAction *_disconnectStorageAction;
        QAction *_importStorageAction;
        QAction *_exportStorageAction;

        QAction *_exitAction;

        QAction *_manageRegistAction;
        QAction *_manageEntityAction;
        QAction *_manageRateAction;

        QAction *_createInvoiceAction;
        QAction *_printInvoiceAction;
        QAction *_previewInvoiceAction;
        QAction *_exportInvoiceAction;

        QAction *_changuePasswAction;
        QAction *_closeAction;
        QAction *_closeAllAction;
        QAction *_tileAction;
        QAction *_cascadeAction;
        QAction *_nextAction;
        QAction *_previousAction;
        QAction *_aboutAction;
        QAction *_aboutQtAction;
        QMenu *_applicationMenu;
        QMenu *_managementMenu;
        QMenu *_reportMenu;
        QMenu *_windowMenu;
        QMenu *_helpMenu;

        QToolBar *_invoiceToolBar;
        QToolBar *_appToolBar;
        QToolBar *_managementToolBar;
        QToolBar *_helpToolBar;

        QLabel *_storageIconLabel;
        QLabel *_storageStateLabel;

        bool _authorized;
        bool _connected;


        View::Management::EntityEditor *_entityEditor;
        View::Management::RatesEditor *_ratesEditor;
        View::Management::RegistEditor *_registEditor;
        View::Management::RangesEditor *_rangesEditor;
        View::Invoicing::InvoiceEditor *_invoiceEditor;

        QMdiSubWindow *_entitySubWindow;
        QMdiSubWindow *_ratesSubWindow;
        QMdiSubWindow *_registSubWindow;
        QMdiSubWindow *_invoiceSubWindow;
        QList<QWidget *> _otherWindows;
    };
}

#endif // MAINWINDOW_H
