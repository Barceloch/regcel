/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef ENTITYDIALOG_H
#define ENTITYDIALOG_H

#include <QDialog>

#define ENTITY_DIALOG_MINIMUM_SIZE 500

QT_BEGIN_NAMESPACE
class QTabWidget;
class QPushButton;
class QLabel;
class QLineEdit;
class QCheckBox;
QT_END_NAMESPACE

namespace Model
{
    namespace Domain
    {
        class Entity;
    }
}

namespace View
{
    namespace Management
    {
        class EntityDialog : public QDialog
        {
            Q_OBJECT
        public:
            EntityDialog(Model::Domain::Entity *entity, QWidget *parent = 0);
            void done(int result);
        private slots:
            void entityModified(bool modified = true);
        private:
            void createWidgets();
            void createIdWidgets();
            void createUbicationWidgets();
            void createContactWidgets();

            void createConnections();
            void loadEntity();
            void saveEntity();
            bool isSaveable();

            QLabel *_idLabel;
            QLineEdit *_idLineEdit;
            QLabel *_folioLabel;
            QLineEdit *_folioLineEdit;
            QLabel *_nameLabel;
            QLineEdit *_nameLineEdit;
            QLabel *_countryLabel;
            QLineEdit *_countryLineEdit;
            QLabel *_provinceLabel;
            QLineEdit *_provinceLineEdit;
            QLabel *_cityLabel;
            QLineEdit *_cityLineEdit;
            QLabel *_addressLabel;
            QLineEdit *_addressLineEdit;
            QLabel *_pcLabel;
            QLineEdit *_pcLineEdit;
            QLabel *_telephoneLabel;
            QLineEdit *_telephoneLineEdit;
            QLabel *_mobileLabel;
            QLineEdit *_mobileLineEdit;
            QLabel *_faxLabel;
            QLineEdit *_faxLineEdit;
            QLabel *_emailLabel;
            QLineEdit *_emailLineEdit;
            QLabel *_webLabel;
            QLineEdit *_webLineEdit;

            QPushButton *_saveButton;
            QPushButton *_closeButton;
            Model::Domain::Entity *_entity;
        };
    }
}

#endif // ENTITYDIALOG_H
