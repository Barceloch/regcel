/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef ENTITYSELECTOR_H
#define ENTITYSELECTOR_H
#include <QDialog>
#include "types.h"

#define ENTITY_SELECTOR_MINIMUM_WIDTH 375
#define COLUMN_ENTITY_ID_WIDTH 50
#define COLUMN_ENTITY_NAME_WIDTH 250
#define COLUMN_ENTITY_FOLIO_WIDTH 50

QT_BEGIN_NAMESPACE
class QTableView;
class QPushButton;
QT_END_NAMESPACE

namespace Model
{
    namespace Domain
    {
        class Entity;
    }
}

namespace View
{
    namespace Management
    {

        class EntityModel;

        class EntitySelector : public QDialog
        {
            Q_OBJECT
        public:
            EntitySelector(SelectorBehavior behavior = SelectOnly,
                           QWidget *parent = 0);
            ~EntitySelector();
            void done(int result);
            Model::Domain::Entity *entity() const;
            bool created() const;
        private slots:
            void rowSelectionChanged();
            void createEntity();
        private:
            void createWidgets();
            void createConnections();

            QTableView *_entitiesTableView;
            EntityModel *_entityModel;
            QPushButton *_createButton;
            QPushButton *_selectButton;
            QPushButton *_cancelButton;

            Model::Domain::Entity *_entity;
            //Model::Domain::EntityType _type;
            SelectorBehavior _behavior;
            bool _created;
        };
    }
}
#endif // ENTITYSELECTOR_H

