/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef GETREGIST_H
#define GETREGIST_H
#include <QDialog>
#include <QWidget>
#include "ratedialog.h"
#include "types.h"

QT_BEGIN_NAMESPACE
class QDate;
class QLabel;
class QSpinBox;
class QDateEdit;
class QPushButton;
class QComboBox;
class QGroupBox;
QT_END_NAMESPACE

namespace View
{
    namespace Management
    {
        class RegistEditor;
        class RegistModel;
        class GetRegist : public QDialog
        {
            Q_OBJECT
        public:
            GetRegist(int &model, int &entityId, QDate &beginDate, QDate &endDate, QWidget *parent = 0);
            void done(int result);
        private slots:
            void getModeSelected();
            void getModel(int giveModel);
            void getEntityId();
            void getBeginDate();
            void getEndDate();
        private:
            void createWidgets();
            void createConnections();

            QLabel *_getByLabel;
            QComboBox *_getByComboBox;

            QLabel *_entityLabel;
            QComboBox *_entityComboBox;

            QLabel *_folioLabel;
            QSpinBox *_folioSpinBox;

            QLabel *_beginDateLabel;
            QDateEdit *_beginDateDateEdit;

            QLabel *_endDateLabel;
            QDateEdit *_endDateDateEdit;

            QGroupBox *_dateGroupBox;

            QPushButton *_getButton;
            QPushButton *_cancelButton;
            RegistModel *_registModel;
            //RegistEditor *_registEditor;
            QTableView *_registTable;
            int giveModel;
            int &_model;
            int &_entityId;
            QDate &_beginDate;
            QDate &_endDate;
        };
    }
}
#endif // GETREGIST_H
