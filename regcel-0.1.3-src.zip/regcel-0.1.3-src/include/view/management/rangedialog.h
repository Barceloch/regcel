/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef RANGEDIALOG_H
#define RANGEDIALOG_H
#include <QDialog>
#include <QWidget>
#include "ratedialog.h"
#include "types.h"

QT_BEGIN_NAMESPACE
class QLabel;
class QLineEdit;
class QCheckBox;
class QTextEdit;
class QDialogButtonBox;
class QPushButton;
class QTableView;
class QComboBox;
QT_END_NAMESPACE

namespace Model
{
    namespace Domain
    {
        class Range;
    }
}


namespace View
{
    namespace Management
    {

        class RangeDialog : public QDialog
        {
            Q_OBJECT
        //friend class RateDialog;
        public:
            RangeDialog(Model::Domain::Range *range, int rateId, QWidget *parent = 0);
            void done(int result);
        private slots:
            void rangeModified(bool modified = true);
        private:
            void createWidgets();
            void createRangesWidgets();
            void createConnections();
            void loadRange();
            void saveRange();
            bool isSaveable();

            QLabel *_idLabel;
            QLineEdit *_idLineEdit;

            QLabel *_rateLabel;
            QComboBox *_rateComboBox;
            QCheckBox *_autoRateCheckBox;
            QLineEdit *_rateLineEdit;

            QLabel *_fromLabel;
            QLineEdit *_fromLineEdit;

            QLabel *_toLabel;
            QLineEdit *_toLineEdit;

            QLabel *_priceLabel;
            QLineEdit *_priceLineEdit;

            QPushButton *_saveButton;
            QPushButton *_cancelButton;

            RateDialog *_ratesDialog;

            Model::Domain::Range *_range;
            int _precisionMoney;
            int _rateId;
        };
    }
}
#endif // RANGEDIALOG_H
