/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef RANGEMODEL_H
#define RANGEMODEL_H
#include <QAbstractTableModel>
#include <QList>

namespace Model
{
    namespace Domain
    {
        class Range;
    }
}

namespace View
{
    namespace Management
    {
        class RangeModel : public QAbstractTableModel
        {
        public:
            RangeModel(QList<Model::Domain::Range *> *ranges, QObject *parent = 0)
                : QAbstractTableModel(parent), _ranges(ranges) {}
            ~RangeModel();
            QList<Model::Domain::Range *> *ranges();

            void setRanges(QList<Model::Domain::Range *> *ranges);
            bool insertRange(int k, Model::Domain::Range *range);
            bool modifyRange(int k);
            bool removeRange(int k);
            int rowCount(const QModelIndex &parent) const;
            int columnCount(const QModelIndex &parent) const;
            QVariant data(const QModelIndex &index, int role) const;
            QVariant headerData(int section, Qt::Orientation orientation, int role) const;
        private:
            QList<Model::Domain::Range *> *_ranges;
        };
    }

}

#endif // RANGEMODEL_H
