/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef RANGESEDITOR_H
#define RANGESEDITOR_H

#define RANGES_EDITOR_MINIMUM_WIDTH        320
#define COLUMN_RANGE_ID_WIDTH              50
#define COLUMN_RANGE_FROMNUMBER_WIDTH      60
#define COLUMN_RANGE_TONUMBER_WIDTH        60
#define COLUMN_RANGE_PRICE_WIDTH           60

#include "range.h"
#include "types.h"
#include <QWidget>

QT_BEGIN_NAMESPACE
class QDialogButtonBox;
class QVBoxLayout;
class QPushButton;
class QTableView;
//class QTableWidget;
QT_END_NAMESPACE

namespace View
{
    namespace Management
    {

        class RatesEditor;
        class RangeModel;
        class RateDialog;

        class RangesEditor : public QWidget
        {
            Q_OBJECT
        public:
            RangesEditor(int rateId, QWidget *parent = 0);
            ~RangesEditor();

        signals:
           void rangeSaved();
        private slots:
            void rowSelectionChanged();
            void addRange();
            void modRange();
            void delRange();
        private:
            void createWidgets();
            void createRangeWidgets();
            void createConnections();
            bool verifyDeleteRange();

            RateDialog *_rateDialog;
            RangeModel *_rangeModel;
            QTableView *_rangesTableView;

            QPushButton *_addRangeButton;
            QPushButton *_modRangeButton;
            QPushButton *_delRangeButton;

            QDialogButtonBox *rangesbuttonBox;
            QVBoxLayout *rangesbuttonLayout;

            int _precisionMoney;
            int _rateId;
            int _rateIndex;
          };
      }
}

#endif // RANGESEDITOR_H
