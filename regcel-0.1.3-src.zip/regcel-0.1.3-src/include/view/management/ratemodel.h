/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef RATEMODEL_H
#define RATEMODEL_H
#include <QAbstractTableModel>
#include <QList>

namespace Model
{
    namespace Domain
    {
        class Rate;
    }
}

namespace View
{
    namespace Management
    {
        class RateModel : public QAbstractTableModel
        {
        public:
            RateModel(QList<Model::Domain::Rate *> *rates, QObject *parent = 0)
                : QAbstractTableModel(parent), _rates(rates) {}
            ~RateModel();
            QList<Model::Domain::Rate *> *rates();
            void setRates(QList<Model::Domain::Rate *> *rates);
            bool insertRate(int k, Model::Domain::Rate *rate);
            bool modifyRate(int k);
            bool removeRate(int k);
            int rowCount(const QModelIndex &parent) const;
            int columnCount(const QModelIndex &parent) const;
            QVariant data(const QModelIndex &index, int role) const;
            QVariant headerData(int section, Qt::Orientation orientation, int role) const;
        private:
            QList<Model::Domain::Rate *> *_rates;
        };
    }
}

#endif // RATEMODEL_H
