/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef RATESEDITOR_H
#define RATESEDITOR_H

#include <QWidget>

#define RATES_EDITOR_MINIMUM_WIDTH 375
#define COLUMN_RATE_ID_WIDTH 50
#define COLUMN_RATE_NAME_WIDTH 250

QT_BEGIN_NAMESPACE
class QTableView;
class QPushButton;
QT_END_NAMESPACE

namespace Model
{
    namespace Domain
    {
        class Rate;
    }
}

namespace View
{
    namespace Management
    {
        class RangeModel;
        class RateModel;

        class RatesEditor : public QWidget
        {
            Q_OBJECT
        public:
            RatesEditor(QWidget *parent = 0);
            ~RatesEditor();
        protected:
            void closeEvent(QCloseEvent *event);
        signals:
           void finished();
        private slots:
            void rowSelectionChanged();
            void addRate();
            void modRate();
            void delRate();
        private:
            void createWidgets();
            void createRateWidgets();

            void createConnections();
            bool verifyDeleteRate();


            QTableView *_ratesTableView;
            RateModel *_rateModel;
            RangeModel *_rangeModel;
            QPushButton *_addRateButton;
            QPushButton *_modRateButton;
            QPushButton *_delRateButton;
            QPushButton *_closeButton;




        };
    }
}
#endif // RATESEDITOR_H
