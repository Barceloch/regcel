/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef REGISTEDITOR_H
#define REGISTEDITOR_H
#include "mainwindow.h"
#include <QWidget>

#define REGIST_EDITOR_MINIMUM_WIDTH 850
#define COLUMN_REGIST_ID_WIDTH 60
#define COLUMN_REGIST_ENTITYFOLIO_WIDTH 60
#define COLUMN_REGIST_ENTITYNAME_WIDTH 200
#define COLUMN_REGIST_DATE_WIDTH 85
#define COLUMN_REGIST_TIME_WIDTH 85
#define COLUMN_REGIST_LECTI_WIDTH 85
#define COLUMN_REGIST_LECTF_WIDTH 85
#define COLUMN_REGIST_KWH_WIDTH 95
#define COLUMN_REGIST_IMPORT_WIDTH 95

QT_BEGIN_NAMESPACE
class QTableView;
class QPushButton;
QT_END_NAMESPACE

namespace Model
{
    namespace Domain
    {
        class Regist;
    }
}

namespace View
{
    namespace Management
    {
        class RegistModel;
        class EntityModel;

        class RegistEditor : public QWidget
        {
            Q_OBJECT
            friend class GetRegist;
        public:
            RegistEditor(QWidget *parent = 0);

        protected:
            void closeEvent(QCloseEvent *event);
        signals:
           void finished();
        private slots:
            void rowSelectionChanged();
            void getRegists();
            void addRegist();
            void modRegist();
            void delRegist();
        private:
            void createWidgets();
            void createRegistWidgets();

            void createConnections();
            bool verifyDeleteRegist();


            QTableView *_registsTableView;
            EntityModel *_entityModel;
            RegistModel *_registModel;

            QPushButton *_getRegistButton;
            QPushButton *_addRegistButton;
            QPushButton *_modRegistButton;
            QPushButton *_delRegistButton;
            QPushButton *_closeButton;


        };
    }
}
#endif // REGISTEDITOR_H
