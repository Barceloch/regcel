/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#ifndef REGISTMODEL_H
#define REGISTMODEL_H
#include <QAbstractTableModel>
#include <QList>

namespace Model
{
    namespace Domain
    {
        class Regist;
    }
}

namespace View
{
    namespace Management
    {
        class RegistModel : public QAbstractTableModel
        {
        public:
            RegistModel(QList<Model::Domain::Regist *> *regists, QObject *parent = 0)
                : QAbstractTableModel(parent), _regists(regists) {}
            ~RegistModel();
            QList<Model::Domain::Regist *> *regists();
            void setRegists(QList<Model::Domain::Regist *> *regists);
            bool insertRegist(int k, Model::Domain::Regist *regist);
            bool modifyRegist(int k);
            bool removeRegist(int k);
            int rowCount(const QModelIndex &parent) const;
            int columnCount(const QModelIndex &parent) const;
            QVariant data(const QModelIndex &index, int role) const;
            QVariant headerData(int section, Qt::Orientation orientation, int role) const;
        private:
            QList<Model::Domain::Regist *> *_regists;
        };
    }
}

#endif // REGISTMODEL_H
