/**
*   Copyright © (2013) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

CREATE TABLE IF NOT EXISTS entity (
    id        INTEGER,
    folio     INTEGER,
    name      TEXT    CONSTRAINT entity_name_nn_ct NOT NULL,
    country   TEXT,
    province  TEXT,
    city      TEXT,
    address   TEXT,
    pc        TEXT,
    telephone INTEGER,
    mobile    INTEGER,
    fax       INTEGER,
    email     TEXT,
    web       TEXT,
    CONSTRAINT entity_pk_ct  PRIMARY KEY(id)
    );

CREATE TABLE IF NOT EXISTS rate (
    id             INTEGER,
    name           TEXT    CONSTRAINT rate_name_nn_ct NOT NULL,
    description    TEXT,
    moreofNumber   INTEGER CONSTRAINT rate_moreofnumber_nn_ct NOT NULL,
    moreofPrice    REAL    CONSTRAINT rate_moreofprice_nn_ct NOT NULL,

    CONSTRAINT     rate_pk_ct           PRIMARY KEY(id),
    CONSTRAINT     rate_moreofprice_chk_ct    CHECK(moreofPrice>=0.0)
    );

CREATE TABLE IF NOT EXISTS range (
    id          INTEGER,
    rate        INTEGER CONSTRAINT range_rate_nn_ct NOT NULL,
    fromNumber  INTEGER CONSTRAINT range_fromnumber_nn_ct NOT NULL,
    toNumber    INTEGER CONSTRAINT range_tonumber_nn_ct NOT NULL,
    price       REAL    CONSTRAINT range_price_nn_ct NOT NULL,
    CONSTRAINT range_pk_ct             PRIMARY KEY(id),
    CONSTRAINT range_rate_fk_ct        FOREIGN KEY(rate)
    REFERENCES rate(id)
               ON UPDATE CASCADE
               ON DELETE CASCADE,
    CONSTRAINT product_price_chk_ct    CHECK(price>=0.0)
    );

CREATE TABLE IF NOT EXISTS regist (
    id           INTEGER,
    entity       INTEGER CONSTRAINT regist_entity_nn_ct NOT NULL,
    entityFolio  INTEGER,
    entityName   TEXT    CONSTRAINT regist_entityName_nn_ct NOT NULL,
    date         DATE,
    time         TEXT,
    lecti        REAL,
    lectf        REAL,
    kwh          REAL,
    import       REAL,
    CONSTRAINT regist_pk_ct  PRIMARY KEY(id),

    CONSTRAINT regist_entity_fk_ct        FOREIGN KEY(entity)
    REFERENCES entity(id)
    ON UPDATE CASCADE
    ON DELETE CASCADE
);



