/**
*   Copyright 2013 Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include <QApplication>
#include <QLibraryInfo>
#include <QDir>
#include <QSplashScreen>
#include <QTranslator>
#include <QLocale>
#include <iostream>
#include "mainwindow.h"
#include "persistencemanager.h"
#include "global.h"

void setUpApplication(QApplication *app, QTranslator *translator);
bool verifyConfig(bool *firstExecution);
bool verifyStorage();
bool initApplication(View::MainWindow *mainWindow, bool firstExecution);

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    //QApplication::addLibraryPath(QApplication::applicationDirPath() + QDir::separator() + "plugins");

    QSplashScreen *splash = new QSplashScreen;
    splash->setPixmap(QPixmap(":/images/regcelSplash.png"));
    splash->show();

    Qt::Alignment topRight = Qt::AlignRight | Qt::AlignTop;
    splash->showMessage(QObject::trUtf8("Cargando configuración..."),
                        topRight, Qt::red);
    qApp->processEvents();

    QTranslator translator;
    bool firstLogin = false;

    setUpApplication(&app, &translator);

    std::cout << QString("%1 %2").arg(app.applicationName()).arg(app.applicationVersion()).toStdString() << std::endl;
    std::cout << QObject::trUtf8("Iniciando ...").toStdString() << std::endl << std::endl;

    if(!verifyConfig(&firstLogin)) {
        std::cout << QObject::trUtf8("Configuración          :  Error  :  Se cerrará la aplicación").toStdString() << std::endl;
        return 1;
    } else
        std::cout << QObject::trUtf8("Configuración          :  OK").toStdString() << std::endl;

    splash->showMessage(QObject::trUtf8("Conectando almacenamiento..."),
                        topRight, Qt::red);
    qApp->processEvents();

    if(!verifyStorage()) {
        std::cout << QObject::trUtf8("Almacenamiento         :  Error  :  Se cerrará la aplicación").toStdString() << std::endl;
        return 1;
    } else
        std::cout << QObject::trUtf8("Almacenamiento         :  OK").toStdString() << std::endl;

    View::MainWindow mainWindow;
    mainWindow.show();

    splash->showMessage(QObject::trUtf8("Autentificando..."),
                        topRight, Qt::red);
    qApp->processEvents();

    if(!initApplication(&mainWindow, firstLogin)) {
        std::cout << QObject::trUtf8("Autentificación        :  Error  :  Se cerrará la aplicación").toStdString() << std::endl;
        return 1;
    } else
        std::cout << QObject::trUtf8("Autentificación        :  OK").toStdString() << std::endl;

    std::cout << std::endl << QObject::trUtf8("Ejecutando ...").toStdString() << std::endl;

    splash->finish(&mainWindow);
    return app.exec();
}

void setUpApplication(QApplication *app, QTranslator *translator)
{
    app -> setOrganizationName(ORGANIZATION_NAME);
    app -> setOrganizationDomain(ORGANIZATION_DOMAIN);
    app -> setApplicationName(APPLICATION_NAME);
    app -> setApplicationVersion(APPLICATION_VERSION);

    translator -> load("regcel_" + QLocale::system().name(), ":/translations");
    translator->load("qt_es",QLibraryInfo::location(QLibraryInfo::TranslationsPath));
    app -> installTranslator(translator);
}

bool verifyConfig(bool *firstLogin)
{
    if(!Persistence::Manager::existsConfig() && !Persistence::Manager::createConfig())
            return false;

    *firstLogin = Persistence::Manager::readConfig("Password").toString().isEmpty();

    return true;
}

bool verifyStorage()
{
    if(!Persistence::Manager::existsStorage())
        return Persistence::Manager::createStorage();

    return true;
}

bool initApplication(View::MainWindow *mainWindow, bool firstLogin)
{
    return firstLogin ? mainWindow -> firstExecution() : mainWindow -> login();
}
