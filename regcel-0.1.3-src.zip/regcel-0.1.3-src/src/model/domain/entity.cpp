/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "entity.h"

Model::Domain::Entity::Entity(int id)
    : _id(id)
{
    _name = _country = _province = _city = _address = _pc = _email = _web = QString();
    _folio = _telephone = _mobile = _fax = 0;
}

Model::Domain::Entity::Entity(const Entity &entity)
{
    *this = entity;
}


Model::Domain::Entity &Model::Domain::Entity::operator=(const Entity &entity)
{
    _id            = entity._id;
    _folio         = entity._folio;
    _name          = entity._name;
    _country       = entity._country;
    _province      = entity._province;
    _city          = entity._city;
    _address       = entity._address;
    _pc            = entity._pc;
    _telephone     = entity._telephone;
    _mobile        = entity._fax;
    _fax           = entity._fax;
    _email         = entity._email;
    _web           = entity._web;

    return *this;
}
bool Model::Domain::Entity::operator==(const Entity &entity) const
{
    return _id == entity._id;
}

bool Model::Domain::Entity::operator!=(const Entity &entity) const
{
    return !(*this == entity);
}

void Model::Domain::Entity::setId(int id)
{
    _id = id;
}

int Model::Domain::Entity::id() const
{
    return _id;
}

void Model::Domain::Entity::setFolio(int folio)
{
    _folio = folio;
}

int Model::Domain::Entity::folio() const
{
    return _folio;
}
void Model::Domain::Entity::setName(const QString &name)
{
    _name = name;
}

const QString &Model::Domain::Entity::name() const
{
    return _name;
}

void Model::Domain::Entity::setCountry(const QString &country)
{
    _country = country;
}

const QString &Model::Domain::Entity::country() const
{
    return _country;
}

void Model::Domain::Entity::setProvince(const QString &province)
{
    _province = province;
}

const QString &Model::Domain::Entity::province() const
{
    return _province;
}

void Model::Domain::Entity::setCity(const QString &city)
{
    _city = city;
}

const QString &Model::Domain::Entity::city() const
{
    return _city;
}

void Model::Domain::Entity::setAddress(const QString &address)
{
    _address = address;
}

const QString &Model::Domain::Entity::address() const
{
    return _address;
}

void Model::Domain::Entity::setPc(const QString &pc)
{
    _pc = pc;
}

const QString &Model::Domain::Entity::pc() const
{
    return _pc;
}

void Model::Domain::Entity::setTelephone(int telephone)
{
    _telephone = telephone;
}

int Model::Domain::Entity::telephone() const
{
    return _telephone;
}
void Model::Domain::Entity::setMobile(int mobile)
{
    _mobile = mobile;
}

int Model::Domain::Entity::mobile() const
{
    return _mobile;
}

void Model::Domain::Entity::setFax(int fax)
{
    _fax = fax;
}

int Model::Domain::Entity::fax() const
{
    return _fax;
}

void Model::Domain::Entity::setEmail(const QString &email)
{
    _email = email;
}

const QString &Model::Domain::Entity::email() const
{
    return _email;
}

void Model::Domain::Entity::setWeb(const QString &web)
{
    _web = web;
}

const QString &Model::Domain::Entity::web() const
{
    return _web;
}



