/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "ostream.h"

std::ostream &Model::Domain::operator<<(std::ostream &os, const Entity &entity)
{
    return os << entity._id                     << std::endl
              << entity._folio                  << std::endl
              << entity._name.toStdString()     << std::endl
              << entity._country.toStdString()  << std::endl
              << entity._province.toStdString() << std::endl
              << entity._city.toStdString()     << std::endl
              << entity._address.toStdString()  << std::endl
              << entity._pc.toStdString()       << std::endl
              << entity._telephone              << std::endl
              << entity._mobile                 << std::endl
              << entity._fax                    << std::endl
              << entity._email.toStdString()    << std::endl
              << entity._web.toStdString()      << std::endl;
}

std::ostream &Model::Domain::operator<<(std::ostream &os, const Rate &rate)
{
    return os << rate._id                                  << std::endl
              << rate._name.toStdString()                  << std::endl
              << rate._description.toStdString()           << std::endl
              << rate._moreofNumber                        << std::endl
              << rate._moreofPrice                         << std::endl;
}

std::ostream &Model::Domain::operator<<(std::ostream &os, const Range &range)
{
    return os << range._id                  << std::endl
              << *range._rate               << std::endl
              << range._fromNumber          << std::endl
              << range._toNumber            << std::endl
              << range._price               << std::endl;
}

std::ostream &Model::Domain::operator<<(std::ostream &os, const Regist &regist)
{
    return os << regist._id                                 << std::endl
              << *regist._entity                            << std::endl
              << regist._entityFolio                        << std::endl
              << regist._entityName.toStdString()           << std::endl
              << regist._date.toString().toStdString()      << std::endl
              << regist._time.toString().toStdString()      << std::endl
              << regist._lecti                              << std::endl
              << regist._lectf                              << std::endl
              << regist._kwh                                << std::endl
              << regist._import                             << std::endl;
}
