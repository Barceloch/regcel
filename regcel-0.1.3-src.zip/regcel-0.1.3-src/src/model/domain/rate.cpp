/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "rate.h"
#include "range.h"

Model::Domain::Rate::Rate(int id)
    : _id(id)
{
    _name = _description = QString();
    _moreofNumber = 0;
    _moreofPrice = 0.0;
}

Model::Domain::Rate::Rate(const Rate &rate)
{
    *this = rate;
}

Model::Domain::Rate &Model::Domain::Rate::operator=(const Rate &rate)
{
    _id            = rate._id;
    _name          = rate._name;
    _description   = rate._description;
    _moreofNumber  = rate._moreofNumber;
    _moreofPrice   = rate._moreofPrice;

    return *this;
}

bool Model::Domain::Rate::operator==(const Rate &rate) const
{
    return  _id == rate._id;
}

bool Model::Domain::Rate::operator!=(const Rate &rate) const
{
    return !(*this == rate);
}

void Model::Domain::Rate::setId(int id)
{
    _id = id;
}

int Model::Domain::Rate::id() const
{
    return _id;
}

void Model::Domain::Rate::setName(const QString &name)
{
    _name = name;
}

const QString &Model::Domain::Rate::name() const
{
    return _name;
}

void Model::Domain::Rate::setDescription(const QString &description)
{
    _description = description;
}

const QString &Model::Domain::Rate::description() const
{
    return _description;
}


void Model::Domain::Rate::setMoreOfNumber(int moreofNumber)
{
    _moreofNumber = moreofNumber;
}

int Model::Domain::Rate::moreofNumber() const
{
    return _moreofNumber;
}

void Model::Domain::Rate::setMoreOfPrice(double moreofPrice)
{
    _moreofPrice = moreofPrice;
}

double Model::Domain::Rate::moreofPrice() const
{
    return _moreofPrice;
}

