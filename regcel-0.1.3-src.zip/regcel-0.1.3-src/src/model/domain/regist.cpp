/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "entity.h"
#include "regist.h"

Model::Domain::Regist::Regist(int id)
    : _id(id)
{
    _entity = 0;
    _entityFolio = 0;
    _entityName = QString();
    _date = QDate::currentDate();
    _time = QTime::currentTime();
    _lecti = _lectf = _kwh = _import = 0.0;

}

Model::Domain::Regist::Regist(const Regist &regist)
{
    *this = regist;
}

Model::Domain::Regist::~Regist()
{
    if(_entity)
        delete _entity;
}

Model::Domain::Regist &Model::Domain::Regist::operator=(const Model::Domain::Regist &regist)
{
    _id             = regist._id;
    _entity         = (regist._entity) ? new Entity(*regist._entity) : 0;
    _entityFolio    = regist._entityFolio;
    _entityName     = regist._entityName;
    _date           = regist._date;
    _time           = regist._time;
    _lecti          = regist._lecti;
    _lectf          = regist._lectf;
    _kwh            = regist._kwh;
    _import         = regist._import;


    return *this;
}

bool Model::Domain::Regist::operator==(const Model::Domain::Regist &regist) const
{
    return _id == regist._id;
}

bool Model::Domain::Regist::operator!=(const Model::Domain::Regist &regist) const
{
    return !(*this == regist);
}

//SET ID
void Model::Domain::Regist::setId(int id)
{
    _id = id;
}

int Model::Domain::Regist::id() const
{
    return _id;
}

void Model::Domain::Regist::setEntity(Entity *entity)
{
    if(_entity)
        delete _entity;

    _entity = entity;
}

Model::Domain::Entity *Model::Domain::Regist::entity() const
{
    return _entity;
}

void Model::Domain::Regist::setEntityFolio(int entityFolio)
{
    _entityFolio = entityFolio;
}

int Model::Domain::Regist::entityFolio() const
{
    return _entityFolio;
}

void Model::Domain::Regist::setEntityName(const QString &entityName)
{
    _entityName = entityName;
}

const QString &Model::Domain::Regist::entityName() const
{
    return _entityName;
}

//SET DATE
void Model::Domain::Regist::setDate(const QDate &date)
{
    _date = date;
}

const QDate &Model::Domain::Regist::date() const
{
    return _date;
}
//SET TIME
void Model::Domain::Regist::setTime(const QTime &time)
{
    _time = time;
}

const QTime &Model::Domain::Regist::time() const
{
    return _time;
}

//SET LECT I
void Model::Domain::Regist::setLectI(double lecti)
{
    _lecti = lecti;
}

double Model::Domain::Regist::lecti() const
{
    return _lecti;
}
//SET LEC F
void Model::Domain::Regist::setLectF(double lectf)
{
    _lectf = lectf;
}

double Model::Domain::Regist::lectf() const
{
    return _lectf;
}
//SET Kw/h
void Model::Domain::Regist::setKwh(double kwh)
{
    _kwh = kwh;
}

double Model::Domain::Regist::kwh() const
{
    return _kwh;
}
//SET IMPORT
void Model::Domain::Regist::setImport(double import)
{
    _import = import;
}


double Model::Domain::Regist::import() const
{
    return _import;
}

