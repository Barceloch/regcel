/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "registmanager.h"
#include "entitymanager.h"
#include "sqlagent.h"
#include "types.h"

bool Model::Management::RegistManager::create(const Model::Domain::Regist &regist)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("INSERT INTO regist VALUES(%1, %2, %3, '%4', '%5', '%6', '%7', '%8', '%9', '%10')")
                      .arg(regist.id())
                      .arg(regist.entity()->id())
                      .arg(regist.entityFolio())
                      .arg(regist.entityName())
                      .arg(regist.date().toString(DATE_FORMAT))
                      .arg(regist.time().toString(TIME_FORMAT))
                      .arg(regist.lecti())
                      .arg(regist.lectf())
                      .arg(regist.kwh())
                      .arg(regist.import());

    return agent -> insert(sql);
}

bool Model::Management::RegistManager::modify(const Model::Domain::Regist &regist)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("UPDATE regist SET entity=%2, entityFolio=%3, entityName='%4', date='%5', time='%6', lecti='%7', "
                          "lectf='%8', kwh='%9', import='%10' WHERE id=%1")
                      .arg(regist.id())
                      .arg(regist.entity()->id())
                      .arg(regist.entityFolio())
                      .arg(regist.entityName())
                      .arg(regist.date().toString(DATE_FORMAT))
                      .arg(regist.time().toString(TIME_FORMAT))
                      .arg(regist.lecti())
                      .arg(regist.lectf())
                      .arg(regist.kwh())
                      .arg(regist.import());


    return agent -> update(sql);
}

bool Model::Management::RegistManager::remove(int id)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("DELETE FROM regist WHERE id=%1").arg(id);

    return agent -> _delete(sql);
}

Model::Domain::Regist *Model::Management::RegistManager::get(int id)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM regist WHERE id=%1").arg(id);
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    Model::Domain::Regist *regist = 0;

    if(!(result -> isEmpty())) {
        Model::Domain::Entity *entity    = EntityManager::get((result -> at(0)).at(1).toInt());
        int entityFolio                  = (result -> at(0)).at(2).toInt();
        QString entityName               = (result -> at(0)).at(3).toString();
        QDate date                       = QDate::fromString((result -> at(0)).at(4).toString(), DATE_FORMAT);
        QTime time                       = QTime::fromString((result -> at(0)).at(5).toString(), TIME_FORMAT);
        double lecti                     = (result -> at(0)).at(6).toDouble();
        double lectf                     = (result -> at(0)).at(7).toDouble();
        double kwh                       = (result -> at(0)).at(8).toDouble();
        double import                    = (result -> at(0)).at(9).toDouble();

        regist = new Model::Domain::Regist(id);
        regist->setEntity(entity);
        regist->setEntityFolio(entityFolio);
        regist->setEntityName(entityName);
        regist->setDate(date);
        regist->setTime(time);
        regist->setLectI(lecti);
        regist->setLectF(lectf);
        regist->setKwh(kwh);
        regist->setImport(import);
    }

    delete result;

    return regist;
}

QList<Model::Domain::Regist *> *Model::Management::RegistManager::getAll()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM regist");
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QList<Model::Domain::Regist *> *regists = new QList<Model::Domain::Regist *>;

    foreach(QVector<QVariant> row, *result) {
        int id                           = row.at(0).toInt();
        Model::Domain::Entity *entity    = EntityManager::get(row.at(1).toInt());
        int entityFolio                  = row.at(2).toInt();
        QString entityName               = row.at(3).toString();
        QDate date                       = QDate::fromString(row.at(4).toString(), DATE_FORMAT);
        QTime time                       = QTime::fromString(row.at(5).toString(), TIME_FORMAT);
        double lecti                     = row.at(6).toDouble();
        double lectf                     = row.at(7).toDouble();
        double kwh                       = row.at(8).toDouble();
        double import                    = row.at(9).toDouble();

        Model::Domain::Regist *regist = new Model::Domain::Regist(id);
        regist->setEntity(entity);
        regist->setEntityFolio(entityFolio);
        regist->setEntityName(entityName);
        regist->setDate(date);
        regist->setTime(time);
        regist->setLectI(lecti);
        regist->setLectF(lectf);
        regist->setKwh(kwh);
        regist->setImport(import);
        regists -> push_back(regist);

    }

    delete result;

    return regists;
}
QList<Model::Domain::Regist *> *Model::Management::RegistManager::getByEntity(int entityId)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM regist WHERE entity=%1")
                           .arg(entityId);
    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QList<Model::Domain::Regist *> *regists = new QList<Model::Domain::Regist *>;

    foreach(QVector<QVariant> row, *result) {
        int id                           = row.at(0).toInt();
        Model::Domain::Entity *entity    = EntityManager::get(row.at(1).toInt());
        int entityFolio                  = row.at(2).toInt();
        QString entityName               = row.at(3).toString();
        QDate date                       = QDate::fromString(row.at(4).toString(), DATE_FORMAT);
        QTime time                       = QTime::fromString(row.at(5).toString(), TIME_FORMAT);
        double lecti                     = row.at(6).toDouble();
        double lectf                     = row.at(7).toDouble();
        double kwh                       = row.at(8).toDouble();
        double import                    = row.at(9).toDouble();

        Model::Domain::Regist *regist = new Model::Domain::Regist(id);
        regist->setEntity(entity);
        regist->setEntityFolio(entityFolio);
        regist->setEntityName(entityName);
        regist->setDate(date);
        regist->setTime(time);
        regist->setLectI(lecti);
        regist->setLectF(lectf);
        regist->setKwh(kwh);
        regist->setImport(import);
        regists -> push_back(regist);

    }

    delete result;

    return regists;
}

QList<Model::Domain::Regist *> *Model::Management::RegistManager::getByDateRange(const QDate &beginDate, const QDate &endDate)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM regist WHERE date>='%1' AND date<='%2'")
                            .arg(beginDate.toString(DATE_FORMAT))
                            .arg(endDate.toString(DATE_FORMAT));

    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QList<Model::Domain::Regist *> *regists = new QList<Model::Domain::Regist *>;

    foreach(QVector<QVariant> row, *result) {
        int id                           = row.at(0).toInt();
        Model::Domain::Entity *entity    = EntityManager::get(row.at(1).toInt());
        int entityFolio                  = row.at(2).toInt();
        QString entityName               = row.at(3).toString();
        QDate date                       = QDate::fromString(row.at(4).toString(), DATE_FORMAT);
        QTime time                       = QTime::fromString(row.at(5).toString(), TIME_FORMAT);
        double lecti                     = row.at(6).toDouble();
        double lectf                     = row.at(7).toDouble();
        double kwh                       = row.at(8).toDouble();
        double import                    = row.at(9).toDouble();

        Model::Domain::Regist *regist = new Model::Domain::Regist(id);
        regist->setEntity(entity);
        regist->setEntityFolio(entityFolio);
        regist->setEntityName(entityName);
        regist->setDate(date);
        regist->setTime(time);
        regist->setLectI(lecti);
        regist->setLectF(lectf);
        regist->setKwh(kwh);
        regist->setImport(import);
        regists -> push_back(regist);

    }

    delete result;

    return regists;
}

QList<Model::Domain::Regist *> *Model::Management::RegistManager::getByEntityANDateRange(int entityId, const QDate &beginDate, const QDate &endDate)
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT * FROM regist WHERE entity=%1 AND date>='%2' AND date<='%3'")
                           .arg(entityId)
                           .arg(beginDate.toString(DATE_FORMAT))
                           .arg(endDate.toString(DATE_FORMAT));

    QVector<QVector<QVariant> > *result = agent -> select(sql);
    QList<Model::Domain::Regist *> *regists = new QList<Model::Domain::Regist *>;

    foreach(QVector<QVariant> row, *result) {
        int id                           = row.at(0).toInt();
        Model::Domain::Entity *entity    = EntityManager::get(row.at(1).toInt());
        int entityFolio                  = row.at(2).toInt();
        QString entityName               = row.at(3).toString();
        QDate date                       = QDate::fromString(row.at(4).toString(), DATE_FORMAT);
        QTime time                       = QTime::fromString(row.at(5).toString(), TIME_FORMAT);
        double lecti                     = row.at(6).toDouble();
        double lectf                     = row.at(7).toDouble();
        double kwh                       = row.at(8).toDouble();
        double import                    = row.at(9).toDouble();

        Model::Domain::Regist *regist = new Model::Domain::Regist(id);
        regist->setEntity(entity);
        regist->setEntityFolio(entityFolio);
        regist->setEntityName(entityName);
        regist->setDate(date);
        regist->setTime(time);
        regist->setLectI(lecti);
        regist->setLectF(lectf);
        regist->setKwh(kwh);
        regist->setImport(import);
        regists -> push_back(regist);

    }

    delete result;

    return regists;
}

int Model::Management::RegistManager::getId()
{
    Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
    QString sql = QString("SELECT count(*) FROM regist");
    QVector<QVector<QVariant> > *result = agent -> select(sql);

    if(!(result -> isEmpty())) {
        int count = (result -> at(0)).at(0).toInt();
        delete result;
        if(count == 0)
            return 1;
        else {
            sql = QString("SELECT max(id) FROM regist");
            result = agent -> select(sql);
            int id = (result -> at(0)).at(0).toInt();
            delete result;
            return id + 1;
        }
    }

    delete result;

    return NO_ID;
}

