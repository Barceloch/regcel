/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "persistencemanager.h"
#include "sqlagent.h"
#include "global.h"
#include <QSettings>
#include <QFile>
#include <QDir>

bool Persistence::Manager::existsConfig()
{
    QSettings setting(ORGANIZATION_NAME, APPLICATION_NAME);

    return setting.value("Executed", false).toBool();
}

bool Persistence::Manager::createConfig(bool overwrite)
{
    if(existsConfig() && !overwrite)
        return false;

    QSettings setting(ORGANIZATION_NAME, APPLICATION_NAME);

    setting.setValue("Executed",                  true);
    setting.setValue("Password",                  "");
    setting.beginGroup("Application");
    setting.setValue("Currency",                  DEFAULT_APPLICATION_CURRENCY);
    setting.beginGroup("Precision");
    setting.setValue("Money",                     DEFAULT_APPLICATION_MONEY_PRECISION);
    setting.endGroup();
    setting.endGroup();
    setting.beginGroup("Storage");
    setting.setValue("Type",                      DEFAULT_STORAGE_TYPE);
    setting.setValue("Path",                      DEFAULT_STORAGE_PATH);
    setting.beginGroup("DBMS");
    setting.setValue("Driver",                    DEFAULT_STORAGE_DBMS_DRIVER);
    setting.setValue("Name",                      DEFAULT_STORAGE_DBMS_NAME);
    setting.setValue("Host",                      DEFAULT_STORAGE_DBMS_HOST);
    setting.setValue("Port",                      DEFAULT_STORAGE_DBMS_PORT);
    setting.setValue("User",                      DEFAULT_STORAGE_DBMS_USER);
    setting.setValue("Pass",                      DEFAULT_STORAGE_DBMS_PASS);
    setting.endGroup();
    setting.endGroup();

    return true;
}

bool Persistence::Manager::deleteConfig()
{
    QSettings setting(ORGANIZATION_NAME, APPLICATION_NAME);

    if(!existsConfig())
        return false;

    setting.clear();

    return true;
}

QVariant Persistence::Manager::readConfig(const QString &key, const QString &group)
{
    QSettings setting(ORGANIZATION_NAME, APPLICATION_NAME);

    if(existsConfig()) {
        setting.beginGroup(group);
        return setting.value(key);
    }

    return QVariant();
}

bool Persistence::Manager::writeConfig(const QVariant &value, const QString &key, const QString &group)
{
    QSettings setting(ORGANIZATION_NAME, APPLICATION_NAME);

    if(!existsConfig())
        return false;

    setting.beginGroup(group);
    if(!setting.contains(key))
        return false;
    setting.setValue(key, value);
    setting.endGroup();

    return true;
}

bool Persistence::Manager::existsStorage()
{
    if(!existsConfig())
        return false;

    switch(static_cast<DBMSType>(readConfig("Type", "Storage").toInt())) {
    case SQLITE:
        QString driver = readConfig("Driver", "Storage/DBMS").toString();
        if(driver == "QSQLITE")
            return QFile(readConfig("Name", "Storage/DBMS").toString()).exists();
        break;
    }

    return false;
}

bool Persistence::Manager::createStorage(bool overwrite)
{
    if(!existsConfig() || (existsStorage() && !overwrite))
        return false;

    QDir storagePath(readConfig("Path", "Storage").toString());;

    if(!storagePath.exists() && !storagePath.mkpath(storagePath.path()))
            return false;

    switch(static_cast<DBMSType>(readConfig("Type", "Storage").toInt())) {
    case SQLITE:
        return createSQLiteSchema();
    }

    return false;
}

bool Persistence::Manager::deleteStorage()
{
    if(!existsStorage())
        return false;

    switch(static_cast<DBMSType>(readConfig("Type", "Storage").toInt())) {
    case SQLITE:
        return QFile::remove(readConfig("Name", "Storage/DBMS").toString());
    }

    return false;
}

bool Persistence::Manager::createSQLiteSchema()
{
    SQLAgent *agent = SQLAgent::instance();

    if(!agent -> connect())
        return false;

    bool entity = agent -> create("CREATE TABLE IF NOT EXISTS entity (\n"
                                  "    id        INTEGER,\n"
                                  "    folio     INTEGER,\n"
                                  "    name      TEXT    CONSTRAINT entity_name_nn_ct NOT NULL,\n"
                                  "    country   TEXT,\n"
                                  "    province  TEXT,\n"
                                  "    city      TEXT,\n"
                                  "    address   TEXT,\n"
                                  "    pc        TEXT,\n"
                                  "    telephone INTEGER,\n"
                                  "    mobile    INTEGER,\n"
                                  "    fax       INTEGER,\n"
                                  "    email     TEXT,\n"
                                  "    web       TEXT,\n"
                                  "    CONSTRAINT entity_pk_ct  PRIMARY KEY(id)\n"
                                  ")");

    bool rate = agent -> create("CREATE TABLE IF NOT EXISTS rate (\n"
                                       "    id             INTEGER,\n"
                                       "    name           TEXT    CONSTRAINT rate_name_nn_ct NOT NULL,\n"
                                       "    description    TEXT,\n"
                                       "    moreofNumber   INTEGER CONSTRAINT rate_moreofnumber_nn_ct NOT NULL,\n"
                                       "    moreofPrice    REAL    CONSTRAINT rate_moreofprice_nn_ct NOT NULL,\n"
                                       "    CONSTRAINT     rate_pk_ct           PRIMARY KEY(id),\n"
                                       "    CONSTRAINT     rate_moreofprice_chk_ct    CHECK(moreofPrice>=0.0)\n"
                                       ")");

    bool range = agent -> create("CREATE TABLE IF NOT EXISTS range (\n"
                                       "    id          INTEGER,\n"
                                       "    rate        INTEGER CONSTRAINT range_rate_nn_ct NOT NULL,\n"
                                       "    fromNumber  INTEGER CONSTRAINT range_fromnumber_nn_ct NOT NULL,\n"
                                       "    toNumber    INTEGER CONSTRAINT range_tonumber_nn_ct NOT NULL,\n"
                                       "    price       REAL    CONSTRAINT range_price_nn_ct NOT NULL,\n"
                                       "    CONSTRAINT range_pk_ct             PRIMARY KEY(id),\n"
                                       "    CONSTRAINT range_rate_fk_ct        FOREIGN KEY(rate)\n"
                                       "                                       REFERENCES rate(id)\n"
                                       "                                           ON UPDATE CASCADE\n"
                                       "                                           ON DELETE CASCADE,\n"
                                       "    CONSTRAINT product_price_chk_ct    CHECK(price>=0.0)\n"
                                       ")");

    bool regist = agent -> create("CREATE TABLE IF NOT EXISTS regist (\n"
                                      "    id           INTEGER,\n"
                                      "    entity       INTEGER CONSTRAINT regist_entity_nn_ct NOT NULL,\n"
                                      "    entityFolio  INTEGER,\n"
                                      "    entityName   TEXT    CONSTRAINT regist_entityName_nn_ct NOT NULL,\n"
                                      "    date         DATE,\n"
                                      "    time         TEXT,\n"
                                      "    lecti        REAL,\n"
                                      "    lectf        REAL,\n"
                                      "    kwh          REAL,\n"
                                      "    import       REAL,\n"
                                      "    CONSTRAINT regist_pk_ct  PRIMARY KEY(id),\n"
                                      "    CONSTRAINT regist_entity_fk_ct        FOREIGN KEY(entity)\n"
                                      "                                        REFERENCES entity(id)\n"
                                      "                                            ON UPDATE CASCADE\n"
                                      "                                           ON DELETE CASCADE\n"
                                      ")");

    agent -> disconnect();

    return entity && rate && range && regist && addDefaultRate() && addOldDefaultRate();
}

bool Persistence::Manager::addDefaultRate()

{

    SQLAgent *agent = SQLAgent::instance();

    if(!agent -> connect())

        return false;

    bool data_rate = agent->insert("INSERT INTO rate VALUES(1,'Nueva - Tarifa recidencial','Nuevos precios de la tarifa recidencial',5000,20.0)");


    bool data_range000_100   = agent->insert("INSERT INTO range VALUES(1,1,0,100,0.33)");
    bool data_range101_150   = agent->insert("INSERT INTO range VALUES(2,1,101,150,1.07)");
    bool data_range151_200   = agent->insert("INSERT INTO range VALUES(3,1,151,200,1.43)");
    bool data_range201_250   = agent->insert("INSERT INTO range VALUES(4,1,201,250,2.46)");
    bool data_range251_300   = agent->insert("INSERT INTO range VALUES(5,1,251,300,3.00)");
    bool data_range301_350   = agent->insert("INSERT INTO range VALUES(6,1,301,350,4.00)");    
    bool data_range351_400   = agent->insert("INSERT INTO range VALUES(7,1,351,400,5.00)");
    bool data_range401_450   = agent->insert("INSERT INTO range VALUES(8,1,401,450,6.00)");
    bool data_range451_500   = agent->insert("INSERT INTO range VALUES(9,1,451,500,7.00)");
    bool data_range501_600   = agent->insert("INSERT INTO range VALUES(10,1,501,600,9.20)");
    bool data_range601_700   = agent->insert("INSERT INTO range VALUES(11,1,601,700,9.45)");
    bool data_range701_1000   = agent->insert("INSERT INTO range VALUES(12,1,701,1000,9.85)");
    bool data_range1001_1800   = agent->insert("INSERT INTO range VALUES(13,1,1001,1800,10.80)");
    bool data_range1801_2600   = agent->insert("INSERT INTO range VALUES(14,1,1801,2600,11.80)");
    bool data_range2601_3400   = agent->insert("INSERT INTO range VALUES(15,1,2601,3400,12.90)");
    bool data_range3401_4200   = agent->insert("INSERT INTO range VALUES(16,1,3401,4200,13.95)");
    bool data_range4201_5000   = agent->insert("INSERT INTO range VALUES(17,1,4201, 5000,15.00)");    

    return data_range000_100 && data_range101_150 && data_range151_200 && data_range201_250 && data_range251_300 &&
           data_range301_350 && data_range351_400 && data_range401_450 && data_range451_500 && data_range501_600 && 
           data_range601_700 && data_range701_1000 && data_range1001_1800 && data_range1801_2600 &&  data_range2601_3400 && 
           data_range3401_4200 && data_range4201_5000 && data_rate;

}

bool Persistence::Manager::addOldDefaultRate()

{

    SQLAgent *agent = SQLAgent::instance();

    if(!agent -> connect())

        return false;

    bool data_rate = agent->insert("INSERT INTO rate VALUES(2,'Vieja - Tarifa recidencial','La vieja tarifa para los hogares',5000,5.0)");


    bool data_range000_100   = agent->insert("INSERT INTO range VALUES(18,2,0,100,0.09)");
    bool data_range101_150   = agent->insert("INSERT INTO range VALUES(19,2,100,150,0.3)");
    bool data_range151_200   = agent->insert("INSERT INTO range VALUES(20,2,150,200,0.4)");
    bool data_range201_250   = agent->insert("INSERT INTO range VALUES(21,2,200,250,0.6)");
    bool data_range251_300   = agent->insert("INSERT INTO range VALUES(22,2,250,300,0.8)");
    bool data_range301_350   = agent->insert("INSERT INTO range VALUES(23,2,300,350,1.5)");
    bool data_range351_500   = agent->insert("INSERT INTO range VALUES(24,2,350,500,1.8)");
    bool data_range501_1000  = agent->insert("INSERT INTO range VALUES(25,2,500,1000,2.0)");
    bool data_range1001_5000 = agent->insert("INSERT INTO range VALUES(26,2,1000,5000,3.0)");

    return data_range000_100 && data_range101_150 && data_range151_200 && data_range201_250 && data_range251_300 &&
           data_range301_350 && data_range351_500 && data_range501_1000 && data_range1001_5000 && data_rate;

}

bool Persistence::Manager::connectStorage()
{
    bool ok = false;

    try {
        Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
        switch(static_cast<DBMSType>(readConfig("Type", "Storage").toInt())) {
        case SQLITE:
            ok = agent -> connect() && agent -> create("PRAGMA foreign_keys=ON;");
            break;
        }
    } catch(Persistence::SQLAgentException sqlException) {}

    return ok;
}

void Persistence::Manager::disconnectStorage()
{
    try {
        Persistence::SQLAgent *agent = Persistence::SQLAgent::instance();
        agent -> disconnect();
        delete agent;
    } catch(Persistence::SQLAgentException sqlException) {}
}

bool Persistence::Manager::importStorage(const QString &fileName)
{
    switch(static_cast<DBMSType>(readConfig("Type", "Storage").toInt())) {
    case SQLITE:
        QFile storage(readConfig("Name", "Storage/DBMS").toString());

        if(storage.remove())
            return QFile(fileName).copy(readConfig("Name", "Storage/DBMS").toString());
    }

    return false;
}

bool Persistence::Manager::exportStorage(const QString &fileName)
{
    switch(static_cast<DBMSType>(readConfig("Type", "Storage").toInt())) {
    case SQLITE:
        QFile file(fileName);

        if(file.exists() && !file.remove())
                return false;

        return QFile(readConfig("Name", "Storage/DBMS").toString()).copy(fileName);
    }

    return false;
}
