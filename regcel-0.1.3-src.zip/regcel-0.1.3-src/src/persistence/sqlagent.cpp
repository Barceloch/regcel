/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "sqlagent.h"
#include "persistencemanager.h"
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlRecord>

Persistence::SQLAgent *Persistence::SQLAgent::instance()
{
    if(!_instance)
        _instance = new SQLAgent;

    return _instance;
}

Persistence::SQLAgent::~SQLAgent()
{
    QString connectionName = _database -> connectionName();

    disconnect();

    _instance = 0;
    delete _database;

    QSqlDatabase::removeDatabase(connectionName);
}

bool Persistence::SQLAgent::connect()
{
    return _database -> open();
}

void Persistence::SQLAgent::disconnect()
{
    if(isConnected())
        _database -> close();
}

bool Persistence::SQLAgent::isConnected()
{
    return _database -> isOpen();
}

bool Persistence::SQLAgent::create(const QString &sql)
{
    return manipulation(sql);
}

bool Persistence::SQLAgent::insert(const QString &sql)
{
    return manipulation(sql);
}

bool Persistence::SQLAgent::update(const QString &sql)
{
    return manipulation(sql);
}

QVector<QVector<QVariant> > *Persistence::SQLAgent::select(const QString &sql)
{
    return query(sql);
}

bool Persistence::SQLAgent::_delete(const QString &sql)
{
    return manipulation(sql);
}

Persistence::SQLAgent::SQLAgent()
{
    if(!Persistence::Manager::existsConfig())
        throw SQLAgentException("Database Configuration not found");

    _database = new QSqlDatabase(QSqlDatabase::addDatabase(Manager::readConfig("Driver", "Storage/DBMS").toString()));

    _database -> setDatabaseName(Manager::readConfig("Name", "Storage/DBMS").toString());
    _database -> setHostName(Manager::readConfig("Host", "Storage/DBMS").toString());
    _database -> setPort(Manager::readConfig("Port", "Storage/DBMS").toInt());
    _database -> setUserName(Manager::readConfig("User", "Storage/DBMS").toString());
    _database -> setPassword(Manager::readConfig("Pass", "Storage/DBMS").toString());
}

bool Persistence::SQLAgent::manipulation(const QString &sql)
{
    QSqlQuery query;

    return query.exec(sql);
}

QVector<QVector<QVariant> > *Persistence::SQLAgent::query(const QString &sql)
{
    QSqlQuery query;

    query.setForwardOnly(true);

    if(!query.exec(sql))
         return 0;

    QVector<QVector<QVariant> > *result = new QVector<QVector<QVariant> >;
    int cols = query.record().count();
    while(query.next()) {
        result -> push_back(QVector<QVariant>());
        for(int col = 0 ; col < cols; ++col)
            (result -> back()).push_back(query.value(col));
    }

    return result;
}

Persistence::SQLAgent *Persistence::SQLAgent::_instance = 0;
