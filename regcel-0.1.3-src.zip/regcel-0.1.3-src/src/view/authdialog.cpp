/**
*   Copyright 2021 Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "authdialog.h"
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>

View::AuthDialog::AuthDialog(QWidget *parent)
    : QDialog(parent)
{
    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Autentificación"));
    setWindowIcon(QIcon(":/images/password.png"));
    setFixedSize(sizeHint());
}

void View::AuthDialog::done(int result)
{
    if(result) {
        _password = _authLineEdit -> text();
        _authLineEdit -> clear();
    }

    QDialog::done(result);
}

const QString View::AuthDialog::password() const
{
    return _password;
}

void View::AuthDialog::textChangedOnLineEdit()
{
    bool isEmpty = _authLineEdit -> text().isEmpty();
    _okPushButton -> setEnabled(!isEmpty);
}

void View::AuthDialog::createWidgets()
{
    _authLabel = new QLabel(trUtf8("Introduzca la contraseña de acceso."));
    _authLineEdit = new QLineEdit;
    _authLineEdit -> setEchoMode(QLineEdit::Password);
    _authLabel -> setBuddy(_authLineEdit);

    QVBoxLayout *topLayout = new QVBoxLayout;
    topLayout -> addWidget(_authLabel);
    topLayout -> addWidget(_authLineEdit);

    _okPushButton = new QPushButton(trUtf8("&Aceptar"));
    _okPushButton -> setIcon(QIcon(":/images/ok.png"));
    _okPushButton -> setDefault(true);
    _okPushButton -> setEnabled(false);

    _cancelPushButton = new QPushButton(trUtf8("&Cancelar"));
    _cancelPushButton -> setIcon(QIcon(":/images/cancel.png"));

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_okPushButton);
    bottomLayout -> addWidget(_cancelPushButton);
    bottomLayout -> addStretch();

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addLayout(topLayout);
    mainLayout -> addLayout(bottomLayout);

    setLayout(mainLayout);
}

void View::AuthDialog::createConnections()
{
    connect(_authLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(textChangedOnLineEdit()));
    connect(_okPushButton, SIGNAL(clicked()),
            this, SLOT(accept()));
    connect(_cancelPushButton, SIGNAL(clicked()),
            this, SLOT(reject()));
}
