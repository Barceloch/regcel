/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "entityselector.h"
#include "entityviewer.h"
#include "entitymodel.h"
#include "entitymanager.h"
#include "entitydialog.h"

#include "regist.h"
#include "registeditor.h"
#include "registmanager.h"
#include "registmodel.h"

#include "ratemanager.h"
#include "ratemodel.h"
#include "rateviewer.h"

#include "rangemanager.h"
#include "rangemodel.h"

#include "invoiceeditor.h"
#include "types.h"
#include <QtGui>

View::Invoicing::InvoiceEditor::InvoiceEditor(QWidget *parent)
    : QWidget(parent) 
{

    createWidgets();
    createConnections();

    setWindowTitle(trUtf8("Crear factura"));
    setWindowIcon(QIcon(":/images/saleinvoice.png"));

    setMinimumWidth(INVOICE_EDITOR_MINIMUM_WIDTH);
    setMinimumHeight(INVOICE_EDITOR_MINIMUM_HEIGHT);
    //resize(INVOICE_EDITOR_MINIMUM_WIDTH, INVOICE_EDITOR_MINIMUM_HEIGHT);
    setAttribute(Qt::WA_DeleteOnClose);

}

void View::Invoicing::InvoiceEditor::closeEvent(QCloseEvent *event)
{
    if (verifyCloseInvoice()){
        emit disablePrint();
        emit finished();
        event->accept();
   }else
        event->ignore();
}

void View::Invoicing::InvoiceEditor::rowSelectionChanged()
{
    int row = _invoiceTable -> currentIndex().row();
    _deleteButton -> setEnabled(row != -1);

}

void View::Invoicing::InvoiceEditor::selectedEntity()
{
    int index = _entityComboBox->currentIndex();
    _detailEntityPushButton->setEnabled(index > 0);
    printEnabled();
}

void View::Invoicing::InvoiceEditor::detailEntity()
{
    Model::Domain::Entity *entity = Model::Management::EntityManager::get(Model::Management::EntityManager::getAllNames().value(_entityComboBox -> currentText()));
    View::Management::EntityViewer viewer(entity);
    viewer.exec();
}
void View::Invoicing::InvoiceEditor::detailRate()
{
    Model::Domain::Rate *rate = Model::Management::RateManager::get(Model::Management::RateManager::getAllNames().value(_rateComboBox -> currentText()));
    View::Management::RateViewer viewer(rate);
    viewer.exec();

}
void View::Invoicing::InvoiceEditor::createWidgets()
{

    createEntityWidgets();

    QGridLayout *entityLayout = new QGridLayout;
    entityLayout -> addWidget(_entityNameLabel, 0, 0, 1, 1);
    entityLayout -> addWidget(_entityComboBox, 1, 0, 1, 1);
    entityLayout -> addWidget(_detailEntityPushButton, 1, 1, 1, 1);
    entityLayout -> addWidget(_invoiceDateLabel, 2, 0, 1, 1);
    entityLayout -> addWidget(_invoiceDateEdit, 3, 0, 1, 1);
    //NUEVO
    entityLayout -> addWidget(_calImportCheckBox, 4, 0, 1, 1);
    entityLayout -> addWidget(_rateLabel, 5, 0, 1, 1);
    entityLayout -> addWidget(_rateComboBox, 6, 0, 1, 1);
    entityLayout -> addWidget(_detailRatePushButton, 6, 1, 1, 1);

    QGroupBox *entityGroupBox = new QGroupBox(trUtf8("&Detalles"));
    entityGroupBox -> setLayout(entityLayout);

    //Agregar registros a la factura
    _entityLabel = new QLabel(trUtf8("De la entidad: "));
    _entityRegistComboBox = new QComboBox;
    _entityRegistComboBox ->addItem("Todas...");
    _entityRegistComboBox -> addItems(Model::Management::EntityManager::getAllNames().keys());
    _entityLabel -> setBuddy(_entityRegistComboBox);

    _beginDateLabel = new QLabel(trUtf8("Con fecha entre el: "));
    _beginDateDateEdit = new QDateEdit;
    _beginDateDateEdit->setDisplayFormat(DATE_FORMAT);
    _beginDateDateEdit->setDate(QDate::currentDate());
    _beginDateDateEdit->setAlignment(Qt::AlignCenter);
    _beginDateDateEdit->setCalendarPopup(true);
    _beginDateLabel -> setBuddy(_beginDateDateEdit);

    _endDateLabel = new QLabel(trUtf8("y el: "));
    _endDateDateEdit = new QDateEdit;
    _endDateDateEdit->setDisplayFormat(DATE_FORMAT);
    _endDateDateEdit->setDate(QDate::currentDate());
    _endDateDateEdit->setAlignment(Qt::AlignCenter);
    _endDateDateEdit->setCalendarPopup(true);
    _endDateLabel -> setBuddy(_endDateDateEdit);


    _addButton = new QPushButton(trUtf8("&Agregar"));
    _addButton -> setIcon(QIcon(":/images/add.png"));
    _addButton -> setDefault(true);
    //_addButton -> setEnabled(false);

    _deleteButton = new QPushButton(trUtf8("&Quitar"));
    _deleteButton -> setIcon(QIcon(":/images/delete.png"));
    _deleteButton -> setEnabled(false);


    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout -> addWidget(_addButton);
    buttonLayout -> addWidget(_deleteButton);

    QGridLayout *incoiceMcontrolLayout = new QGridLayout;
    incoiceMcontrolLayout -> addWidget(_entityLabel, 0, 0, 1, 1);
    incoiceMcontrolLayout -> addWidget(_entityRegistComboBox, 1, 0, 1, 1);
    incoiceMcontrolLayout -> addWidget(_beginDateLabel, 2, 0, 1, 1);
    incoiceMcontrolLayout -> addWidget(_beginDateDateEdit, 3, 0, 1, 1);
    incoiceMcontrolLayout -> addWidget(_endDateLabel, 4, 0, 1, 1);
    incoiceMcontrolLayout -> addWidget(_endDateDateEdit, 5, 0, 1, 1);
    incoiceMcontrolLayout ->addLayout(buttonLayout, 6, 0, 1, 1);

    QGroupBox *invoiceMcontrolGroupBox = new QGroupBox(trUtf8("Facturar registros"));
    invoiceMcontrolGroupBox -> setLayout(incoiceMcontrolLayout);

    _printButton = new QPushButton;
    _printButton -> setIcon(QIcon(":/images/printing.png"));
    _printButton -> setFixedSize(_detailEntityPushButton -> sizeHint());
    _printButton ->setToolTip(trUtf8("Imprimir"));
    _printButton -> setEnabled(false);

    _printPreviewButton = new QPushButton;
    _printPreviewButton -> setIcon(QIcon(":/images/preview.png"));
    _printPreviewButton -> setFixedSize(_detailEntityPushButton -> sizeHint());
    _printPreviewButton ->setToolTip(trUtf8("Vista previa"));
    _printPreviewButton -> setEnabled(false);

    _exportPdfButton = new QPushButton;
    _exportPdfButton -> setIcon(QIcon(":/images/exportpdf.png"));
    _exportPdfButton -> setFixedSize(_detailEntityPushButton -> sizeHint());
    _exportPdfButton ->setToolTip(trUtf8("Exportar en Pdf"));
    _exportPdfButton -> setEnabled(false);

    QHBoxLayout *printLayout = new QHBoxLayout;
    printLayout -> addWidget(_printButton);
    printLayout -> addWidget(_printPreviewButton);
    printLayout -> addWidget(_exportPdfButton);
    //printLayout ->addStretch();

    QVBoxLayout *topLeftLayout = new QVBoxLayout;
    topLeftLayout -> addWidget(entityGroupBox);
    topLeftLayout -> addWidget(invoiceMcontrolGroupBox);
    topLeftLayout ->addLayout(printLayout);
    topLeftLayout ->addStretch();

    createRegistWidgets();


    QGridLayout *notesLayout = new QGridLayout;
    notesLayout -> addWidget(_notes, 0, 0, 1, 1);

    QGroupBox *notesGroupBox = new QGroupBox(trUtf8("&Observaciones"));
    notesGroupBox->setMaximumHeight(150);
    notesGroupBox->setLayout(notesLayout);

    QGridLayout *totalLayout = new QGridLayout;
    totalLayout -> addWidget(_totalKwhLabel, 0, 0, 1, 1);
    totalLayout -> addWidget(_totalKwhResultLabel, 1, 0, 1, 1);
    totalLayout -> addWidget(_totalImportLabel, 2, 0, 1, 1);
    totalLayout -> addWidget(_totalImportResultLabel, 3, 0, 1, 1);

    QGroupBox *totalGroupBox = new QGroupBox(trUtf8("&Totales"));
    totalGroupBox->setMaximumWidth(150);
    totalGroupBox->setLayout(totalLayout);

    QHBoxLayout *registTotalLayout = new QHBoxLayout;
    registTotalLayout -> addWidget(totalGroupBox);
    registTotalLayout -> addWidget(notesGroupBox);

    QGridLayout *registLayout = new QGridLayout;
    registLayout -> addWidget(_invoiceTable, 0, 0, 1, 1);
    registLayout -> addWidget(_warnImportLabel, 1, 0, 1, 1);
    registLayout -> addLayout(registTotalLayout, 2, 0, 1, 1);


    QGroupBox *registGroupBox = new QGroupBox(trUtf8("&Registros a facturar"));
    registGroupBox -> setLayout(registLayout);

    QHBoxLayout *centerLayout = new QHBoxLayout;
    centerLayout -> addLayout(topLeftLayout);
    centerLayout -> addWidget(registGroupBox);

    _closeButton = new QPushButton(tr("&Cerrar"));
    _closeButton -> setIcon(QIcon(":/images/exit.png"));

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout -> addStretch();
    ///bottomLayout -> addWidget(_printButton);
    bottomLayout -> addWidget(_closeButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    //mainLayout -> addLayout(topLayout);
    mainLayout -> addLayout(centerLayout);
    mainLayout -> addLayout(bottomLayout);
    setLayout(mainLayout);
}

void View::Invoicing::InvoiceEditor::createEntityWidgets()
{
    _entityNameLabel = new QLabel(trUtf8("&Entidad principal:"));
    _entityComboBox = new QComboBox;
    _entityComboBox->addItem("Seleccionar...");
    _entityComboBox -> addItems(Model::Management::EntityManager::getAllNames().keys());
    _entityNameLabel -> setBuddy(_entityComboBox);

    _detailEntityPushButton = new QPushButton;
    _detailEntityPushButton -> setIcon(QIcon(":/images/about.png"));
    _detailEntityPushButton -> setFixedSize(_detailEntityPushButton -> sizeHint());
    _detailEntityPushButton -> setEnabled(false);

    _setEntityDefaultCheckBox = new QCheckBox(trUtf8("&Fijar por defecto"));

    _invoiceDateLabel  = new QLabel(trUtf8("Fecha de Factura: "));
    _invoiceDateEdit = new QDateEdit;
    _invoiceDateEdit->setDisplayFormat(DATE_FORMAT);
    _invoiceDateEdit->setDate(QDate::currentDate());
    _invoiceDateEdit->setAlignment(Qt::AlignCenter);
    _invoiceDateEdit->setCalendarPopup(true);
    _invoiceDateLabel -> setBuddy(_invoiceDateEdit);

    //NUEVO
    _calImportCheckBox = new QCheckBox(trUtf8("&Calcular Importe"));
    _rateLabel = new QLabel(trUtf8("&Tarifa:"));
    _rateComboBox = new QComboBox;
    _rateComboBox -> setEnabled(false);
    _rateComboBox -> addItem("Seleccionar...");
    _rateComboBox -> addItems(Model::Management::RateManager::getAllNames().keys());
    _rateLabel -> setBuddy(_entityComboBox);

    _detailRatePushButton = new QPushButton;
    _detailRatePushButton -> setIcon(QIcon(":/images/about.png"));
    _detailRatePushButton -> setFixedSize(_detailRatePushButton -> sizeHint());
    _detailRatePushButton -> setEnabled(_calImportCheckBox -> isChecked());

}

void View::Invoicing::InvoiceEditor::createRegistWidgets()
{
    _invoiceRegists = Model::Management::RegistManager::getByDateRange(QDate(2001, 1, 1), QDate(2001, 1, 1));

    _invoiceTable = new QTableView;
    _registModel = new View::Management::RegistModel(_invoiceRegists);
    _invoiceTable -> setModel(_registModel);
    _invoiceTable -> selectRow(0);
    //_invoiceTable -> setShowGrid(false);
    _invoiceTable -> setColumnWidth(ColumnRegistId,             COLUMN_REGIST_ID_WIDTH);
    _invoiceTable -> setColumnWidth(ColumnRegistEntityFolio,    COLUMN_REGIST_ENTITYFOLIO_WIDTH);
    _invoiceTable -> setColumnWidth(ColumnRegistEntityName,     COLUMN_REGIST_ENTITYNAME_WIDTH);
    _invoiceTable -> setColumnWidth(ColumnRegistDate,           COLUMN_REGIST_DATE_WIDTH);
    _invoiceTable -> setColumnWidth(ColumnRegistTime,           COLUMN_REGIST_TIME_WIDTH);
    _invoiceTable -> setColumnWidth(ColumnRegistLectI,          COLUMN_REGIST_LECTI_WIDTH);
    _invoiceTable -> setColumnWidth(ColumnRegistLectF,          COLUMN_REGIST_LECTF_WIDTH);
    _invoiceTable -> setColumnWidth(ColumnRegistKwh,            COLUMN_REGIST_KWH_WIDTH);
    _invoiceTable -> setColumnWidth(ColumnRegistImport,         COLUMN_REGIST_IMPORT_WIDTH);

    _invoiceTable->setColumnHidden(ColumnRegistId, true);
    _invoiceTable->setColumnHidden(ColumnRegistTime, true);

    _invoiceTable -> setSelectionMode(QAbstractItemView::SingleSelection);
    _invoiceTable -> setSelectionBehavior(QAbstractItemView::SelectRows);
    _invoiceTable -> setEditTriggers(QAbstractItemView::NoEditTriggers);
    _invoiceTable -> setFocusPolicy(Qt::NoFocus);

    _warnImportLabel = new QLabel(trUtf8("<font color=red><em>NOTA: Si no calcula el importe, no se aplica una tarifa al 'Consumo Total', por defecto, el 'Importe Total' mostrará la suma del importe en los registros agregados...</em></font>"));

    _notes = new QTextEdit;

    _totalKwhLabel = new QLabel(trUtf8("&Consumo total:"));
    _totalKwhResultLabel = new QLabel(trUtf8("<font color=green><strong>0.00</strong> Kw/h</font>"));
    _totalKwhLabel -> setBuddy(_totalKwhResultLabel);

    _totalImportLabel = new QLabel(trUtf8("&Importe total:"));
    _totalImportResultLabel = new QLabel(trUtf8("<font color=red><strong>0.00</strong> $</font>"));
    _totalImportLabel->setBuddy(_totalImportResultLabel);
}

void View::Invoicing::InvoiceEditor::insertRegist()
{
    if (_entityRegistComboBox->currentIndex() == 0){
        _invoiceRegists = Model::Management::RegistManager::getByDateRange(_beginDateDateEdit->date(), _endDateDateEdit->date());

    }else{
        _entityRegist = Model::Management::EntityManager::get(Model::Management::EntityManager::getAllNames().value(_entityRegistComboBox -> currentText()));
        _invoiceRegists = Model::Management::RegistManager::getByEntityANDateRange(_entityRegist->id(), _beginDateDateEdit->date(), _endDateDateEdit->date());
   }
   int registCount = _invoiceRegists->size();

   if (!_invoiceRegists->isEmpty()){
       while (registCount > 0) {
           Model::Domain::Regist *_registToInvoice = _invoiceRegists->at(registCount - 1);
           int row = _registModel -> rowCount(QModelIndex());
           _registModel->insertRegist(row, _registToInvoice);
           registCount -= 1;
       }
   }else {
       QMessageBox::warning(this, trUtf8("Resultado"),
                             trUtf8("No se encontrarón registros con la entidad y fecha especificada"),
                             QMessageBox::Ok);
       }
   rowSelectionChanged();
   importANDkwhTotals();
   printEnabled();
}

void View::Invoicing::InvoiceEditor::removeRegist()
{
    int row = _invoiceTable -> currentIndex().row();
    _registModel ->removeRegist(row);
    rowSelectionChanged();
    importANDkwhTotals();

    printEnabled();
}

void View::Invoicing::InvoiceEditor::createConnections()
{
    connect(_invoiceTable -> selectionModel(), SIGNAL(selectionChanged(QItemSelection,QItemSelection)),
            this, SLOT(rowSelectionChanged()));
    connect(_printButton, SIGNAL(clicked()),
            this, SLOT(printInvoice()));
    connect(_printPreviewButton, SIGNAL(clicked()),
            this, SLOT(printInvoicePreview()));
    connect(_exportPdfButton, SIGNAL(clicked()),
            this, SLOT(exportInvoiceToPdf()));
    connect(_entityComboBox, SIGNAL(currentIndexChanged(int)),
            this, SLOT(selectedEntity()));
    connect(_detailEntityPushButton, SIGNAL(clicked()),
            this, SLOT(detailEntity()));
    connect(_addButton, SIGNAL(clicked()),
            this, SLOT(insertRegist()));
    connect(_deleteButton, SIGNAL(clicked()),
            this, SLOT(removeRegist()));
    connect(_closeButton, SIGNAL(clicked()),
            this, SLOT(close()));

    connect(_calImportCheckBox, SIGNAL(stateChanged(int)),
            this, SLOT(selectRate()));
    connect(_rateComboBox, SIGNAL(currentIndexChanged(int)),
            this, SLOT(selectedRate()));
    connect(_detailRatePushButton, SIGNAL(clicked()),
            this, SLOT(detailRate()));
}
void View::Invoicing::InvoiceEditor::importANDkwhTotals()
{
    int rowsCount = _registModel->rowCount(QModelIndex());
    double totalKwh = 0.0, totalImport = 0.0;

    while (rowsCount >= 0) {
        QModelIndex kwhIndex = _registModel->index(rowsCount, 7, QModelIndex());
        QString textKwh = _registModel->data(kwhIndex, Qt::DisplayRole).toString();
        QModelIndex importIndex = _registModel->index(rowsCount, 8, QModelIndex());
        QString textImport = _registModel->data(importIndex, Qt::DisplayRole).toString();

        totalKwh += textKwh.split(' ').takeFirst().toDouble();
        totalImport += textImport.split(' ').takeFirst().toDouble();

        rowsCount -= 1;
    }

    _totalKwhResultLabel->setText(QString("<font color=green><strong>%1 </strong> Kw/h</font>").arg(QString::number(totalKwh, 'f', 2)));
        
    if (_calImportCheckBox->isChecked() && _rateComboBox->currentIndex() > 0)
        {
           Model::Domain::Rate *rate = Model::Management::RateManager::get(Model::Management::RateManager::getAllNames().value(_rateComboBox -> currentText()));     
           calculateImport(totalKwh, rate);

        }
    else
        {
            _totalImportResultLabel->setText(QString("<font color=red><strong>%1 </strong> $</font>").arg(QString::number(totalImport, 'f', 2)));
    
        }
}


void View::Invoicing::InvoiceEditor::calculateImport(double kwh, Model::Domain::Rate *rate)
{
    int precisionMoney = MAX_MONEY_PRECISION;

    QList<Model::Domain::Range *> *ranges = Model::Management::RangeManager::getByRate(rate->id());
    int rangesNumber = ranges->count();
    double import = 0.0;

    for (int range = 0; range <  rangesNumber && kwh > 0; ++range)
    {
        int maxKwh = ranges->at(range)->toNumber() - ranges->at(range)->fromNumber();
        double price = ranges->at(range)->price();
        if (kwh > maxKwh)
        {
            import += maxKwh * price;
            kwh -= maxKwh;
        }
        else
        {
            import += kwh * price;
            kwh = 0;
        }
    }
    if (kwh > 0)
    {
        import += kwh * rate->moreofPrice();
    }
    _totalImportResultLabel->setText(QString("<font color=red><strong>%1 </strong> $</font>").arg(QString::number(import,'f', precisionMoney)));
}

void View::Invoicing::InvoiceEditor::selectRate()
{
    _rateComboBox->setEnabled(_calImportCheckBox -> isChecked());

    int index = _rateComboBox->currentIndex();
    int rowsCount = _registModel->rowCount(QModelIndex());

    _detailRatePushButton->setEnabled(_calImportCheckBox -> isChecked() && index > 0);

    if (rowsCount > 0)
        importANDkwhTotals();
}

void View::Invoicing::InvoiceEditor::selectedRate()
{
    int index = _rateComboBox->currentIndex();
    int rowsCount = _registModel->rowCount(QModelIndex());

    _detailRatePushButton->setEnabled(index > 0);

    if (index > 0 && rowsCount > 0)
        importANDkwhTotals();
}

/*---------------PRINTING--------------------*/
void View::Invoicing::InvoiceEditor::printEnabled()
{
    int index = _entityComboBox->currentIndex();
    int row = _registModel->rowCount(QModelIndex());

    _printButton->setEnabled(index > 0 && row > 0);
    _printPreviewButton->setEnabled(index > 0 && row > 0);
    _exportPdfButton->setEnabled(index > 0 && row > 0);

    if (index > 0 && row > 0){
        emit enablePrint();
    }
    else{
        emit disablePrint();
    }

}
void View::Invoicing::InvoiceEditor::printInvoice()
{
    _entityPrincipal = Model::Management::EntityManager::get(Model::Management::EntityManager::getAllNames().value(_entityComboBox -> currentText()));

    QString pageDocument = makeHeader(*_entityPrincipal, *_invoiceDateEdit) +  makeRegistTable(*_registModel)
                           + makeNotesTable(*_notes) + makeTotalsTable(*_totalKwhResultLabel, *_totalImportResultLabel);;

    QTextDocument _textDocument;
    _textDocument.setDefaultStyleSheet(_css);
    _textDocument.setHtml(pageDocument);

#ifndef QT_NO_PRINTER
    QPrinter printer(QPrinter::HighResolution);
    QPrintDialog *dlg = new QPrintDialog(&printer, this);
    dlg->setWindowTitle(trUtf8("Imprimir factura"));
    if (dlg->exec() == QDialog::Accepted) {
        _textDocument.print(&printer);
    }
    delete dlg;
#endif
}

void View::Invoicing::InvoiceEditor::printInvoicePreview()
{
#ifndef QT_NO_PRINTER
    QPrinter printer(QPrinter::HighResolution);
    QPrintPreviewDialog preview(&printer, this);
    connect(&preview, SIGNAL(paintRequested(QPrinter*)), SLOT(printPreview(QPrinter*)));
    preview.setWindowTitle(trUtf8("Vista previa: Factura en RegCEl v0.1.3"));
    preview.exec();
#endif

}

void View::Invoicing::InvoiceEditor::printPreview(QPrinter *printer)
{
    _entityPrincipal = Model::Management::EntityManager::get(Model::Management::EntityManager::getAllNames().value(_entityComboBox -> currentText()));

    QString pageDocument = makeHeader(*_entityPrincipal, *_invoiceDateEdit) +  makeRegistTable(*_registModel)
                           + makeNotesTable(*_notes) + makeTotalsTable(*_totalKwhResultLabel, *_totalImportResultLabel);;

    QTextDocument _textDocument;
    _textDocument.setDefaultStyleSheet(_css);

#ifdef QT_NO_PRINTER
    Q_UNUSED(printer);
#else
    _textDocument.setHtml(pageDocument);
    _textDocument.print(printer);
#endif

}

void View::Invoicing::InvoiceEditor::exportInvoiceToPdf()
{
    _entityPrincipal = Model::Management::EntityManager::get(Model::Management::EntityManager::getAllNames().value(_entityComboBox -> currentText()));

    QString pageDocument = makeHeader(*_entityPrincipal, *_invoiceDateEdit) +  makeRegistTable(*_registModel)
                           + makeNotesTable(*_notes) + makeTotalsTable(*_totalKwhResultLabel, *_totalImportResultLabel);;

    QTextDocument _textDocument;
    _textDocument.setDefaultStyleSheet(_css);
    _textDocument.setHtml(pageDocument);

#ifndef QT_NO_PRINTER
    QString fileName = QFileDialog::getSaveFileName(this, "Exportar factura a PDF",
                                                    QString(), "*.pdf");
    if (!fileName.isEmpty()) {
        if (QFileInfo(fileName).suffix().isEmpty())
            fileName.append(".pdf");
        QPrinter printer(QPrinter::HighResolution);
        printer.setOutputFormat(QPrinter::PdfFormat);
        printer.setOutputFileName(fileName);
        _textDocument.print(&printer);
    }
#endif

}


QString View::Invoicing::InvoiceEditor::makeHeader(const Model::Domain::Entity &entity, const QDateEdit &date)
{

    return QString("<table id=\"business_table\" width=\"80%\">\n"
                   "   <tr><td id=\"business_name\">%1</td></tr>\n"
                   "   <tr><td><i>%2</i></td></tr>\n"
                   "   <tr><td><i><em id=\"city\">%3</em> %4 %5 %6 %7</i></td></tr>\n"
                   "   <tr><td><b>%8:</b> <i>%9</i></td></tr>\n"
                   "   <tr><td><b>%10:</b> <i>%11</i></td></tr>\n"
                   "   <tr><td><b>%12:</b> <i>%13</i></td></tr>\n"
                   "   <tr><td><b>%14:</b> <i>%15</i></td></tr>\n"
                   "   <tr><td><b>%16:</b> <i>%17</i></td></tr>\n"
                   "</table>\n"
                   "<table id=\"details_table\" width=\"20%\">\n"
                   "   <tr><th colspan=\"2\">%18</th></tr>\n"
                   "   <tr><td width=\"20%\"><b>%19</b></td><td width=\"80%\"><i>%20</i></td></tr>\n"
                   "   <tr><td width=\"20%\"><b>%21</b></td><td width=\"80%\"><i>%22</i></td></tr>\n"
                   "   <tr><td width=\"20%\"><b>%23</b></td><td width=\"80%\"><i>%24</i></td></tr>\n"
                   "</table>\n")
                   .arg(entity . name())
                   .arg(entity . address())
                   .arg(entity . city() + ": ")
                   .arg(QObject::trUtf8("Código Postal: "))
                   .arg(entity . pc() + ", ")
                   .arg(entity . province() + ", ")
                   .arg(entity . country() + ".")
                   .arg(QObject::trUtf8("Teléfono"))
                   .arg(entity . telephone() ? QString::number(entity . telephone()) : "")
                   .arg(QObject::trUtf8("Movil"))
                   .arg(entity . mobile() ? QString::number(entity . mobile()) : "")
                   .arg(QObject::trUtf8("Fax"))
                   .arg(entity . fax() ? QString::number(entity . fax()) : "")
                   .arg(QObject::trUtf8("Email"))
                   .arg(entity . email())
                   .arg(QObject::trUtf8("Web"))
                   .arg(entity . web())
                   //Details
                   .arg(QObject::trUtf8("Fecha"))
                   .arg(QObject::trUtf8("Día"))
                   .arg(date.date().day())
                   .arg(QObject::trUtf8("Mes"))
                   .arg(date.date().month())
                   .arg(QObject::trUtf8("Año"))
                   .arg(date.date().year());
}

QString View::Invoicing::InvoiceEditor::makeRegistTable(const View::Management::RegistModel &registModel)
{

    int registCount = registModel.rowCount(QModelIndex());

    QString table = QString("<table class=\"operations_table\" cellspacing=\"0\" cellpadding=\"1\" border=\"1\" width=\"100%\">\n"
                            "   <tr><th colspan=\"8\">%1</th></tr>\n"
                            "   <tr><th width=\"5%\">%2</th>\n"
                            "   <th width=\"6%\">%3</th>\n"
                            "   <th width=\"30%\">%4</th>\n"
                            "   <th width=\"15%\">%5</th>\n"
                            "   <th>%6</th>\n"
                            "   <th>%7</th>\n"
                            "   <th width=\"15%\">%8</th>\n"
                            "   <th>%9</th></tr>\n")
                            .arg(QObject::trUtf8("Registros"))
                            .arg(QObject::trUtf8("No."))
                            .arg(QObject::trUtf8("Folio"))
                            .arg(QObject::trUtf8("Entidad"))
                            .arg(QObject::trUtf8("Fecha"))
                            .arg(QObject::trUtf8("L. inicial"))
                            .arg(QObject::trUtf8("L. final"))
                            .arg(QObject::trUtf8("Consumo"))
                            .arg(QObject::trUtf8("Importe"));
     for(int reg = 0;reg < registCount ;reg++) {
         QModelIndex folioIndex = registModel.index(reg, 1, QModelIndex());
         QModelIndex entityIndex = registModel.index(reg, 2, QModelIndex());
         QModelIndex dateIndex = registModel.index(reg, 3, QModelIndex());
         QModelIndex lectiIndex = registModel.index(reg, 5, QModelIndex());
         QModelIndex lectfIndex = registModel.index(reg, 6, QModelIndex());
         QModelIndex kwhIndex = registModel.index(reg, 7, QModelIndex());
         QModelIndex importIndex = registModel.index(reg, 8, QModelIndex());

         QString textFolio   = registModel.data(folioIndex, Qt::DisplayRole).toString();
         QString textEntity  = registModel.data(entityIndex, Qt::DisplayRole).toString();
         QString textDate    = registModel.data(dateIndex, Qt::DisplayRole).toString();
         QString textLecti   = registModel.data(lectiIndex, Qt::DisplayRole).toString();
         QString textLectf   = registModel.data(lectfIndex, Qt::DisplayRole).toString();
         QString textKwh     = registModel.data(kwhIndex, Qt::DisplayRole).toString();
         QString textImport  = registModel.data(importIndex, Qt::DisplayRole).toString();

         table += QString("<tr><td align=\"center\">%1</td>\n"
                          "   <td align=\"center\">%2</td>\n"
                          "   <td align=\"left\">%3</td>\n"
                          "   <td align=\"center\">%4</td>\n"
                          "   <td align=\"center\">%5</td>\n"
                          "   <td align=\"center\">%6</td>\n"
                          "   <td class=\"K\" align=\"right\">%7</td>\n"
                          "   <td class=\"I\" align=\"right\">%8</td></tr>\n")
                          .arg(reg + 1)
                          .arg(textFolio)
                          .arg(textEntity)
                          .arg(textDate)
                          .arg(textLecti)
                          .arg(textLectf)
                          .arg(textKwh)
                          .arg(textImport);
       }

       table += QString("</table>\n");

    return table;
}


QString View::Invoicing::InvoiceEditor::makeNotesTable(const QTextEdit &notes)
{
    return QString("<table id=\"notes_table\" width=\"40%\">\n"
                   "<tr><th>%1</th></tr>\n"
                   "<tr><td>%2</td></tr>\n"
                   "</table>\n")
                   .arg(QObject::trUtf8("Observaciones"))
                   .arg(notes.toPlainText());
}

QString View::Invoicing::InvoiceEditor::makeTotalsTable(const QLabel &totalK, const QLabel &totalI)
{
    return QString("<table id=\"totals_table\" width=\"35%\">\n"
                   "<tr><th colspan=\"4\">%1</th></tr>\n"
                   "<tr><td><b>Consumo: </b></td><td align=\"left\"><b>%2</b></td></tr>\n"
                   "<tr><td><b>Importe: </b></td><td align=\"left\"><b>%3</b></td></tr>\n"
                   "</table>\n")
                   .arg(QObject::tr("Totales"))
                   .arg(totalK.text())
                   .arg(totalI.text());
}

const QString View::Invoicing::InvoiceEditor::_css = "body { color: black; background-color: white; }\n"
                                        "#business_table { float: left; background-color: white; font-size: 7pt; }\n"
                                        "#business_name { font-size: 30pt; font-style: italic; font-weight: bold; }\n"
                                        "#city { font-size: 14pt; font-style: italic; font-weight: bold; color: green;}\n"
                                        "#details_table { float: right; background-color: white; color: black; font-size: 10pt; }\n"
                                        ".operations_table { float: left; margin-top: 10pt; background-color: white; color: black; font-size: 10pt; }\n"
                                        ".K { background-color: #fff; color: green; }\n"
                                        ".I { background-color: #fff; color: red; }\n"
                                        "#totals_table { float: right; background-color: white; color: black; font-size: 10pt; }\n"
                                        "#notes_table { float: left; margin-top: 10pt; background-color: white; color: black; font-size: 10pt; }\n"
                                        "th { background-color: #f2f2f2; color: red; }\n";

bool View::Invoicing::InvoiceEditor::verifyCloseInvoice()
{
    return QMessageBox::question(this, trUtf8("Cerrar factura"),
                                 trUtf8("¿desea cerrar la factura?"),
                                 QMessageBox::Yes | QMessageBox::Default |
                                 QMessageBox::No) == QMessageBox::Yes;
}
