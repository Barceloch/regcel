/**
*   Copyright 2021 Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include <QtGui>
#include "mainwindow.h"
#include "persistencemanager.h"
#include "registerdialog.h"
#include "authdialog.h"
#include "invoiceeditor.h"
#include "rateseditor.h"
#include "rangeseditor.h"
#include "entityeditor.h"
#include "entitymodel.h"
#include "entitymanager.h"
#include "registeditor.h"
#include "entitydialog.h"
#include "global.h"

View::MainWindow::MainWindow()
{

    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("RegCEl v0.1.3"));
    setWindowIcon(QIcon(":/images/regcel.png"));
    setWindowState(Qt::WindowMaximized);
    _mdiArea->setBackground(QPixmap(":/images/mdiBackground.jpg"));

    _authorized = false;
    _connected = false;

    _entityEditor = 0;
    _ratesEditor = 0;
    _registEditor = 0;
    _invoiceEditor = 0;
    connectStorage();


}

View::MainWindow::~MainWindow()
{
    disconnectStorage();

}

void View::MainWindow::closeEvent(QCloseEvent *event)
{
    if(!_authorized)
        event -> accept();
    else if(verifyExit()) {
        closeOtherWindows();
        _mdiArea -> closeAllSubWindows();
        if(!_mdiArea -> currentSubWindow())
            event -> accept();
        else
            event -> ignore();
    } else
        event -> ignore();
}

bool View::MainWindow::firstExecution()
{
    QMessageBox::information(this, trUtf8("Primera ejecución"),
                                   trUtf8("Es la primera ejecución de RegCEl en este ordenador.\n"
                                      "deberá fijar una contraseña de acceso."),
                             QMessageBox::Ok);

    RegisterDialog dialog(this);

    if(dialog.exec()) {
        QString password = dialog.password();

        if((_authorized = Persistence::Manager::writeConfig(password, "Password")))
            QMessageBox::information(this, trUtf8("Primera ejecución"),
                                           trUtf8("Contraseña guardada. Bienvenido! a %1.").arg(APPLICATION_NAME),
                                           QMessageBox::Ok);
        else
            QMessageBox::critical(this, trUtf8("Primera ejecución"),
                                        trUtf8("La contraseña no ha sido guardada. Se cerrará la aplicación."),
                                        QMessageBox::Ok);
    } else {
        QMessageBox::critical(this, trUtf8("Primera ejecución"),
                                    trUtf8("Operación cancelada. Se cerrará la aplicación."),
                                    QMessageBox::Ok);

        Persistence::Manager::deleteConfig();
    }

    return _authorized;
}
void View::MainWindow::changuePassw()
{
    RegisterDialog dialog(this);

    if(dialog.exec()) {
        QString password = dialog.password();

        if((_authorized = Persistence::Manager::writeConfig(password, "Password")))
            QMessageBox::information(this, trUtf8("Cambiar contraseña"),
                                           trUtf8("Ha registrado una nueva contraseña."),
                                           QMessageBox::Ok);
        else
            QMessageBox::critical(this, trUtf8("Error"),
                                        trUtf8("La contraseña no pudo ser cambiada. Intentelo nuvamente."),
                                        QMessageBox::Ok);
    } else {
        QMessageBox::critical(this, trUtf8("Cambiar contraseña"),
                                    trUtf8("Operación cancelada."),
                                    QMessageBox::Ok);

        //Persistence::Manager::deleteConfig();
    }

}

bool View::MainWindow::login()
{
    AuthDialog dialog(this);
    QString password = Persistence::Manager::readConfig("Password").toString();
    int attempts = 0;

    do {
        if(!dialog.exec()) {
            QMessageBox::critical(this, trUtf8("Autentificación Fallida"),
                                       trUtf8("Autentificación cancelada.Se cerrará la aplicación."),
                                       QMessageBox::Ok);
            return false;
        } else if(dialog.password() != password) {
            if(attempts < MAX_AUTH_ATTEMPTS - 1)
                QMessageBox::warning(this, trUtf8("Autentificación Fallida"),
                                           trUtf8("Contraseña Incorrecta!. Tienes %1 intentos más.")
                                               .arg(MAX_AUTH_ATTEMPTS - attempts - 1),
                                           QMessageBox::Ok);
            ++attempts;
        } else
            _authorized = true;
    } while(!_authorized && attempts < MAX_AUTH_ATTEMPTS);

    if(attempts == MAX_AUTH_ATTEMPTS)
        QMessageBox::critical(this, trUtf8("Autentificación Fallida"),
                                    trUtf8("Exedido máximo de intentos. Se cerrará la aplicación."),
                                    QMessageBox::Ok);

    return _authorized;
}

void View::MainWindow::connectStorage()
{
    if(!(_connected = Persistence::Manager::connectStorage()))
        QMessageBox::critical(this, trUtf8("Conectar Almacenamiento"),
                                    trUtf8("Conexión Fallida.\n"
                                       "Revize su cofiguración de basedatos."),
                                    QMessageBox::Ok);

    setStorageConnected(_connected);
}

void View::MainWindow::disconnectStorage()
{
    Persistence::Manager::disconnectStorage();
    setStorageConnected((_connected = false));


    //deleteAllEditors();
    closeOtherWindows();
}

void View::MainWindow::importStorage()
{
    QString fileName = QFileDialog::getOpenFileName(this,
                                                    trUtf8("Importar Almacenamiento"),
                                                    QDesktopServices::storageLocation(QDesktopServices::HomeLocation),
                                                    trUtf8("Todos los Archivos (*.*)"));

    if(fileName.isEmpty() || !verifyImportStorage())
        return;

    QApplication::setOverrideCursor(Qt::WaitCursor);
    bool ok = Persistence::Manager::importStorage(fileName);
    QApplication::restoreOverrideCursor();

    if(!ok)
        QMessageBox::warning(this, trUtf8("Importar Almacenamiento"),
                                   trUtf8("Importación Fallida.\n"
                                      "Verifique si existe el archivo o el directorio, y si tiene suficientes privilegios."),
                                   QMessageBox::Ok);
    else
        statusBar() -> showMessage(trUtf8("Importación Completada"), 5000);
}

void View::MainWindow::exportStorage()
{
    QString fileName = QFileDialog::getSaveFileName(this, trUtf8("Exportar Almacenamiento"),
                                                QDesktopServices::storageLocation(QDesktopServices::HomeLocation),
                                                trUtf8("Todos lo Archivos (*.*)"));

    if(fileName.isEmpty())
        return;

    QApplication::setOverrideCursor(Qt::WaitCursor);
    bool ok = Persistence::Manager::exportStorage(fileName);
    QApplication::restoreOverrideCursor();

    if(!ok)
        QMessageBox::warning(this, trUtf8("Exportar Almacenamiento"),
                                   trUtf8("Exportación Fallida.\n"
                                      "Verifique los privilegios del direcctorio de destino."),
                                   QMessageBox::Ok);
    else
        statusBar() -> showMessage(trUtf8("Exportación Completada"), 5000);
}

void View::MainWindow::manageEntity()
{
    if(!_entityEditor){

        _entitySubWindow = new QMdiSubWindow();
        _entityEditor = new View::Management::EntityEditor;
        _entitySubWindow->setWidget(_entityEditor);
        _entitySubWindow->setAttribute(Qt::WA_DeleteOnClose);

        _mdiArea -> addSubWindow(_entitySubWindow);
        _entitySubWindow->show();

        connect(_entityEditor, SIGNAL(finished()),
                    _mdiArea, SLOT(closeActiveSubWindow()));
        connect(_entityEditor, SIGNAL(finished()),
                    this, SLOT(deleteEntityEditor()));
    }else{
        _mdiArea->setActiveSubWindow(_entitySubWindow);
    }

}

void View::MainWindow::manageRate()
{
    if(!_ratesEditor){

        _ratesEditor = new View::Management::RatesEditor;
        _ratesSubWindow = new QMdiSubWindow;
        _ratesSubWindow->setWidget(_ratesEditor);
        _ratesSubWindow->setAttribute(Qt::WA_DeleteOnClose);

        _mdiArea -> addSubWindow(_ratesSubWindow);
        _ratesSubWindow->show();

        connect(_ratesEditor, SIGNAL(finished()),
                    _mdiArea, SLOT(closeActiveSubWindow()));
        connect(_ratesEditor, SIGNAL(finished()),
                    this, SLOT(deleteRatesEditor()));
    }else
        _mdiArea->setActiveSubWindow(_ratesSubWindow);
}

void View::MainWindow::manageRegist()
{
    if(!_registEditor){
        _registEditor = new View::Management::RegistEditor;
        _registSubWindow = new QMdiSubWindow;
        _registSubWindow->setWidget(_registEditor);
        _registSubWindow->setAttribute(Qt::WA_DeleteOnClose);

        _mdiArea -> addSubWindow(_registSubWindow);
        _registSubWindow->show();
        connect(_registEditor, SIGNAL(finished()),
                    _mdiArea, SLOT(closeActiveSubWindow()));
        connect(_registEditor, SIGNAL(finished()),
                    this, SLOT(deleteRegistEditor()));
    }else
        _mdiArea->setActiveSubWindow(_registSubWindow);
}

void View::MainWindow::createInvoice()
{
    if (!_invoiceEditor){
        QList<Model::Domain::Entity *> *entities = Model::Management::EntityManager::getAll();
        if(!entities->isEmpty()){

            _invoiceSubWindow = new QMdiSubWindow();
            _invoiceEditor = new View::Invoicing::InvoiceEditor;
            _invoiceSubWindow->setWidget(_invoiceEditor);
            _invoiceSubWindow->setAttribute(Qt::WA_DeleteOnClose);

            _mdiArea -> addSubWindow(_invoiceSubWindow);
            _invoiceSubWindow->show();

            connect(_invoiceEditor, SIGNAL(finished()),
                        _mdiArea, SLOT(closeActiveSubWindow()));
            connect(_invoiceEditor, SIGNAL(finished()),
                        this, SLOT(deleteInvoiceEditor()));

            connect(_invoiceEditor, SIGNAL(enablePrint()),
                    this, SLOT(printEnabled()));
            connect(_invoiceEditor, SIGNAL(disablePrint()),
                    this, SLOT(printDisabled()));

        }else{
            QMessageBox::warning(this, trUtf8("Facturación"),
                                  trUtf8("Aún no existen entidades ni registros en la base de datos"),
                                  QMessageBox::Ok);
        }
    }else{
        _mdiArea->setActiveSubWindow(_invoiceSubWindow);
    }
}

void View::MainWindow::about()
{
    QMessageBox::about(this, trUtf8("Sobre %1").arg(APPLICATION_NAME),
                       trUtf8("<h2>%1</h2>"
                          "<h3>RegCEl %2 - %3 <em><span style=\"font-size: 10pt; color: blue;\">(BarSoft)</span></em></h3>"
                          "<p>Desarrollado por: <strong><span style=\"font-size: 10pt; color: green;\">%4</span></strong> <a href= \"mailto:%5\" >%5</a></p>"
                          "<p>Sitio Web: <a href= \"%6\" >%6</a></p>"
                          "<p><a href=\"http://www.apache.org/licenses/LICENSE-2.0\"><img alt=\"Apache License\" style=\"border-width:0\" src=\":/images/apache-license.gif\" /></a><br />Licenciado bajo <a href=\"http://www.apache.org/licenses/LICENSE-2.0\" >Apache License Version 2.0</a></p>"
                          "<table id=\"colab_table\">\n"
                             "<tr><th>COLABORADORES:</th></tr>\n"
                             "<tr><td><a href= \"mailto:ymulen@uci.cu\" ><em>Ing. Yoelvis Mulen Llorente</em></a>, <a href= \"mailto:yvelez@uci.cu\" ><em>Ing. Yordan Velez Rodríguez</em></a></td></tr>\n"
                           "</table>\n")
                          .arg(APPLICATION_NAME_LONG)
                          .arg(APPLICATION_VERSION)
                          .arg(APPLICATION_YEARS)
                          .arg(AUTHOR_NAME)
                          .arg(AUTHOR_EMAIL)
                          .arg(APPLICATION_WEB));
}

void View::MainWindow::updateWindowMenu()
{
    bool hasWindowActive = _mdiArea -> activeSubWindow() != 0;

    _closeAction -> setEnabled(hasWindowActive);
    _closeAllAction -> setEnabled(hasWindowActive);
    _tileAction -> setEnabled(hasWindowActive);
    _cascadeAction -> setEnabled(hasWindowActive);
    _nextAction -> setEnabled(hasWindowActive);
    _previousAction -> setEnabled(hasWindowActive);
}
void View::MainWindow::printInvoice()
{
    statusBar() -> showMessage(trUtf8("Imprimir factura"), 2000);

    _invoiceEditor->printInvoice();
}
void View::MainWindow::printInvoicePreview()
{
    statusBar() -> showMessage(trUtf8("Vista preliminar de la factura"), 2000);

    _invoiceEditor->printInvoicePreview();
}
void View::MainWindow::exportInvoiceToPdf()
{
    statusBar() -> showMessage(trUtf8("Exportar factura a PDF"), 2000);

    _invoiceEditor->exportInvoiceToPdf();
}


void View::MainWindow::updateOtherWindows(QObject *object)
{
    QWidget *window = qobject_cast<QWidget *>(object);
    window -> close();
    _otherWindows.removeAll(window);
}

void View::MainWindow::createWidgets()
{
    createCentralWidget();
    createActions();
    createMenus();
    createToolBar();
    createStatusBar();
}

void View::MainWindow::createCentralWidget()
{
    _mdiArea = new QMdiArea;
    _mdiArea -> setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    _mdiArea -> setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    setCentralWidget(_mdiArea);
}
void View::MainWindow::printEnabled()
{
    _previewInvoiceAction->setEnabled(true);
    _printInvoiceAction->setEnabled(true);
    _exportInvoiceAction->setEnabled(true);
}
void View::MainWindow::printDisabled()
{
    _previewInvoiceAction->setEnabled(false);
    _printInvoiceAction->setEnabled(false);
    _exportInvoiceAction->setEnabled(false);
}

void View::MainWindow::createActions()
{

    _connectStorageAction = new QAction(trUtf8("&Conectar Almacenamiento"), this);
    _connectStorageAction -> setIcon(QIcon(":/images/storageon.png"));
    _connectStorageAction ->setShortcut(Qt::CTRL + Qt::SHIFT + Qt::Key_C);
    _connectStorageAction -> setStatusTip(trUtf8("Conectar con la base de datos"));

    _disconnectStorageAction = new QAction(trUtf8("&Desconectar Almacenamiento"), this);
    _disconnectStorageAction -> setIcon(QIcon(":/images/storageoff.png"));
    _disconnectStorageAction ->setShortcut(Qt::CTRL + Qt::SHIFT + Qt::Key_D);
    _disconnectStorageAction -> setStatusTip(trUtf8("Finalizar conexión con la base de datos"));

    _importStorageAction = new QAction(trUtf8("&Importar almacenamiento..."), this);
    _importStorageAction -> setIcon(QIcon(":/images/import.png"));
    _importStorageAction ->setShortcut(Qt::CTRL + Qt::SHIFT + Qt::Key_I);
    _importStorageAction -> setStatusTip(trUtf8("Importar basedatos desde un archivo existente"));

    _exportStorageAction = new QAction(trUtf8("&Exportar almacenamiento..."), this);
    _exportStorageAction -> setIcon(QIcon(":/images/export.png"));
    _exportStorageAction ->setShortcut(Qt::CTRL + Qt::SHIFT + Qt::Key_E);
    _exportStorageAction -> setStatusTip(trUtf8("Exportar basedatos a un archivo"));

    _exitAction = new QAction(trUtf8("C&errar"), this);
    _exitAction -> setIcon(QIcon(":/images/exit.png"));
    _exitAction ->setShortcut(Qt::CTRL + Qt::Key_E);
    _exitAction -> setStatusTip(trUtf8("Cerrar aplicación"));

    _manageEntityAction = new QAction(trUtf8("&Entidades"), this);
    _manageEntityAction -> setIcon(QIcon(":/images/entity.png"));
    _manageEntityAction ->setShortcut(Qt::CTRL + Qt::ALT + Qt::Key_E);
    _manageEntityAction -> setStatusTip(trUtf8("Gestionar Entidades"));

    _manageRegistAction = new QAction(trUtf8("&Registros"), this);
    _manageRegistAction -> setIcon(QIcon(":/images/loadinvoice.png"));
    _manageRegistAction ->setShortcut(Qt::CTRL + Qt::ALT + Qt::Key_R);
    _manageRegistAction -> setStatusTip(trUtf8("Gestionar Registros"));

    _manageRateAction = new QAction(trUtf8("&Tarifas"), this);
    _manageRateAction -> setIcon(QIcon(":/images/unpaid.png"));
    _manageRateAction ->setShortcut(Qt::CTRL + Qt::ALT + Qt::Key_T);
    _manageRateAction -> setStatusTip(trUtf8("Gestionar Tarifas"));

    _createInvoiceAction = new QAction(trUtf8("Crear &factura"), this);
    _createInvoiceAction -> setIcon(QIcon(":/images/saleinvoice.png"));
    _createInvoiceAction->setShortcut(Qt::CTRL + Qt::Key_F);
    _createInvoiceAction -> setStatusTip(trUtf8("Crear factura de consumo"));
    //_createInvoiceAction->setEnabled(false);

    _printInvoiceAction = new QAction(trUtf8("&Imprimir factura"), this);
    _printInvoiceAction -> setIcon(QIcon(":/images/printing.png"));
    _printInvoiceAction ->setShortcut(Qt::CTRL + Qt::Key_P);
    _printInvoiceAction -> setStatusTip(trUtf8("Imprimir factura"));
    _printInvoiceAction->setEnabled(false);

    _previewInvoiceAction = new QAction(trUtf8("&Vista previa"), this);
    _previewInvoiceAction -> setIcon(QIcon(":/images/preview.png"));
    _previewInvoiceAction -> setStatusTip(trUtf8("Vista previa de la factura"));
    _previewInvoiceAction->setEnabled(false);

    _exportInvoiceAction = new QAction(trUtf8("&Exportar a PDF"), this);
    _exportInvoiceAction -> setIcon(QIcon(":/images/exportpdf.png"));
    _exportInvoiceAction ->setShortcut(Qt::CTRL + Qt::Key_E);
    _exportInvoiceAction -> setStatusTip(trUtf8("Exportar factura a PDF"));
    _exportInvoiceAction->setEnabled(false);

    _changuePasswAction = new QAction(trUtf8("Contraseña"), this);
    _changuePasswAction -> setIcon(QIcon(":/images/password.png"));
    _changuePasswAction -> setStatusTip(trUtf8("Cambiar Contraseña"));

    _closeAction = new QAction(trUtf8("&Cerrar"), this);
    _closeAction ->setShortcut(Qt::ALT + Qt::Key_C);
    _closeAction -> setStatusTip(trUtf8("Cerrar la ventana activa"));

    _closeAllAction = new QAction(trUtf8("Cerrar &todo"), this);
    _closeAllAction ->setShortcut(Qt::ALT + Qt::Key_T);
    _closeAllAction -> setStatusTip(trUtf8("Cerrar todas las ventanas"));

    _tileAction = new QAction(trUtf8("Mosaico"), this);
    _tileAction ->setShortcut(Qt::ALT + Qt::Key_M);
    _tileAction -> setStatusTip(trUtf8("Ordenar ventanas en Mosaico"));

    _cascadeAction = new QAction(trUtf8("Cascada"), this);
    _cascadeAction ->setShortcut(Qt::ALT + Qt::Key_C);
    _cascadeAction -> setStatusTip(trUtf8("Ordenar ventanas en Cascada"));

    _nextAction = new QAction(trUtf8("Siguiente"), this);
    _nextAction -> setShortcuts(QKeySequence::NextChild);
    _nextAction -> setStatusTip(trUtf8("Ir a la ventana siguiente"));

    _previousAction = new QAction(trUtf8("Anterior"), this);
    _previousAction -> setShortcuts(QKeySequence::PreviousChild);
    _previousAction -> setStatusTip(trUtf8("Ir a la ventana anterior"));

    _aboutAction = new QAction(trUtf8("Sobre"), this);
    _aboutAction -> setIcon(QIcon(":/images/about.png"));
    _aboutAction -> setStatusTip(trUtf8("Ver información sobre la aplicación"));

    _aboutQtAction = new QAction(trUtf8("Sobre &Qt"), this);
    _aboutQtAction -> setIcon(QIcon(":/images/aboutqt.png"));
    _aboutQtAction -> setStatusTip(trUtf8("Ver información sobre las librerias Qt"));
}

void View::MainWindow::createMenus()
{
    _applicationMenu = menuBar() -> addMenu(trUtf8("&Aplicación"));
    _applicationMenu -> addAction(_createInvoiceAction);
    _applicationMenu -> addAction(_exportInvoiceAction);
    _applicationMenu -> addSeparator();
    _applicationMenu -> addAction(_connectStorageAction);
    _applicationMenu -> addAction(_disconnectStorageAction);
    _applicationMenu -> addSeparator();
    _applicationMenu -> addAction(_importStorageAction);
    _applicationMenu -> addAction(_exportStorageAction);
    _applicationMenu -> addSeparator();
    _applicationMenu -> addAction(_previewInvoiceAction);
    _applicationMenu -> addAction(_printInvoiceAction);
    _applicationMenu -> addSeparator();
    _applicationMenu -> addAction(_changuePasswAction);
    _applicationMenu -> addAction(_exitAction);

    _managementMenu = menuBar() -> addMenu(trUtf8("&Gestión"));
    _managementMenu -> addAction(_manageEntityAction);
    _managementMenu -> addAction(_manageRateAction);
    _managementMenu -> addAction(_manageRegistAction);


    _windowMenu = menuBar() -> addMenu(trUtf8("&Ventana"));
    _windowMenu -> addAction(_closeAction);
    _windowMenu -> addAction(_closeAllAction);
    _windowMenu -> addSeparator();
    _windowMenu -> addAction(_tileAction);
    _windowMenu -> addAction(_cascadeAction);
    _windowMenu -> addSeparator();
    _windowMenu -> addAction(_nextAction);
    _windowMenu -> addAction(_previousAction);

    _helpMenu = menuBar() -> addMenu(trUtf8("A&yuda"));
    _helpMenu -> addAction(_aboutAction);
    _helpMenu -> addAction(_aboutQtAction);

    updateWindowMenu();
}

void View::MainWindow::createToolBar()
{

    _invoiceToolBar = addToolBar(trUtf8("Factura"));
    _invoiceToolBar -> addAction(_createInvoiceAction);
    _invoiceToolBar -> addAction(_previewInvoiceAction);
    _invoiceToolBar -> addAction(_printInvoiceAction);
    _invoiceToolBar -> addAction(_exportInvoiceAction);
    _invoiceToolBar -> setToolButtonStyle(Qt::ToolButtonIconOnly);

    _managementToolBar = addToolBar(trUtf8("Gestion"));
    _managementToolBar -> addAction(_manageEntityAction);
    _managementToolBar -> addAction(_manageRateAction);
    _managementToolBar -> addAction(_manageRegistAction);
    _managementToolBar -> setToolButtonStyle(Qt::ToolButtonIconOnly);

    _appToolBar = addToolBar(trUtf8("Aplicacion"));
    _appToolBar -> addAction(_connectStorageAction);
    _appToolBar -> addAction(_disconnectStorageAction);
    _appToolBar -> addAction(_importStorageAction);
    _appToolBar -> addAction(_exportStorageAction);
    _appToolBar -> setToolButtonStyle(Qt::ToolButtonIconOnly);

    _helpToolBar = addToolBar(trUtf8("Ayuda"));
    _helpToolBar -> addAction(_aboutAction);
    _helpToolBar -> addAction(_aboutQtAction);
    _helpToolBar -> setToolButtonStyle(Qt::ToolButtonIconOnly);

}

void View::MainWindow::createStatusBar()
{
    _storageIconLabel = new QLabel;
    _storageStateLabel = new QLabel;

    statusBar() ->addWidget(_storageIconLabel);
    statusBar() ->addWidget(_storageStateLabel);
}

void View::MainWindow::createConnections()
{
    connect(_mdiArea, SIGNAL(subWindowActivated(QMdiSubWindow *)),
            this, SLOT(updateWindowMenu()));
    connect(_changuePasswAction, SIGNAL(triggered()),
            this, SLOT(changuePassw()));
    connect(_connectStorageAction, SIGNAL(triggered()),
            this, SLOT(connectStorage()));
    connect(_disconnectStorageAction, SIGNAL(triggered()),
            this, SLOT(disconnectStorage()));
    connect(_importStorageAction, SIGNAL(triggered()),
            this, SLOT(importStorage()));
    connect(_exportStorageAction, SIGNAL(triggered()),
            this, SLOT(exportStorage()));
    connect(_exitAction, SIGNAL(triggered()),
            this, SLOT(close()));    
    connect(_manageRegistAction, SIGNAL(triggered()),
            this, SLOT(manageRegist()));
    connect(_manageEntityAction, SIGNAL(triggered()),
            this, SLOT(manageEntity()));
    connect(_manageRateAction, SIGNAL(triggered()),
            this, SLOT(manageRate()));
    connect(_createInvoiceAction, SIGNAL(triggered()),
            this, SLOT(createInvoice()));
    connect(_previewInvoiceAction, SIGNAL(triggered()),
            this, SLOT(printInvoicePreview()));
    connect(_printInvoiceAction, SIGNAL(triggered()),
            this, SLOT(printInvoice()));
    connect(_exportInvoiceAction, SIGNAL(triggered()),
            this, SLOT(exportInvoiceToPdf()));
    connect(_closeAction, SIGNAL(triggered()),
            _mdiArea, SLOT(closeActiveSubWindow()));
    connect(_closeAllAction, SIGNAL(triggered()),
            _mdiArea, SLOT(closeAllSubWindows()));
    connect(_closeAllAction, SIGNAL(triggered()),
            this, SLOT(deleteAllEditors()));
    connect(_tileAction, SIGNAL(triggered()),
            _mdiArea, SLOT(tileSubWindows()));
    connect(_cascadeAction, SIGNAL(triggered()),
            _mdiArea, SLOT(cascadeSubWindows()));
    connect(_nextAction, SIGNAL(triggered()),
            _mdiArea, SLOT(activateNextSubWindow()));
    connect(_previousAction, SIGNAL(triggered()),
            _mdiArea, SLOT(activatePreviousSubWindow()));
    connect(_aboutAction, SIGNAL(triggered()),
            this, SLOT(about()));
    connect(_aboutQtAction, SIGNAL(triggered()),
            qApp, SLOT(aboutQt()));

}


void View::MainWindow::closeOtherWindows()
{
    foreach(QWidget *window, _otherWindows)
        window -> close();
}

void View::MainWindow::deleteEntityEditor()
{
    if(_entityEditor) {
        delete _entityEditor;
        _entityEditor = 0;
    }
}

void View::MainWindow::deleteRatesEditor()
{
    if(_ratesEditor) {
        delete _ratesEditor;
        _ratesEditor = 0;
    }
}
void View::MainWindow::deleteRegistEditor()
{
    if(_registEditor) {
        delete _registEditor;
        _registEditor = 0;
    }
}

void View::MainWindow::deleteInvoiceEditor()
{
    if(_invoiceEditor) {
        delete _invoiceEditor;
        _invoiceEditor = 0;
    }
}

void View::MainWindow::deleteAllEditors()
{
    if(_entityEditor) {
        delete _entityEditor;
        _entityEditor = 0;
    }
    if(_ratesEditor) {
        delete _ratesEditor;
        _ratesEditor = 0;
    }
    if(_registEditor) {
        delete _registEditor;
        _registEditor = 0;
    }
    if(_invoiceEditor) {
        delete _invoiceEditor;
        _invoiceEditor = 0;
    }
}

void View::MainWindow::setStorageConnected(bool connected)
{
    QString host = Persistence::Manager::readConfig("Host", "Storage/DBMS").toString();

    _connectStorageAction -> setEnabled(!connected);
    _disconnectStorageAction -> setEnabled(connected);
    _importStorageAction -> setEnabled(!connected);
    _exportStorageAction -> setEnabled(!connected);

    _manageRateAction -> setEnabled(connected);
    _manageRegistAction -> setEnabled(connected);
    _manageEntityAction -> setEnabled(connected);
    _createInvoiceAction ->setEnabled(connected);
    _managementMenu -> setEnabled(connected);

    _storageIconLabel -> setPixmap(QPixmap(QString(":/images/storage%1.png")
                                           .arg(connected ? "on" : "off"))
                                   .scaled(QSize(16, 16)));
    _storageStateLabel -> setText(connected ? trUtf8("Conectado a %1").arg(host) : trUtf8("Desconectado"));
}

bool View::MainWindow::verifyImportStorage()
{
    return QMessageBox::warning(this, trUtf8("Confirmar Importación"),
                                       trUtf8("Toda la información almacenada anteriormente será eliminada.\n"
                                          "¿desea continuar?"),
                                       QMessageBox::Yes | QMessageBox::Default |
                                       QMessageBox::No) == QMessageBox::Yes;
}

bool View::MainWindow::verifyExit()
{

    return QMessageBox::question(this, trUtf8("Salir"),
                                 trUtf8("¿desea cerrar el programa?"),
                                 QMessageBox::Yes | QMessageBox::Default |
                                 QMessageBox::No) == QMessageBox::Yes;
}
