/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "entityselector.h"
#include "entitymodel.h"
#include "entitymanager.h"
#include "entitydialog.h"
#include "entity.h"
#include <QtGui>

View::Management::EntitySelector::EntitySelector(SelectorBehavior behavior,
                                                 QWidget *parent)
    : QDialog(parent), _behavior(behavior)
{
    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Entidad"));
    setWindowIcon(QIcon(":/images/entity.png"));
    setMinimumWidth(ENTITY_SELECTOR_MINIMUM_WIDTH);

    _entity = 0;
    _created = false;
}

View::Management::EntitySelector::~EntitySelector()
{
    delete _entityModel;
}

void View::Management::EntitySelector::done(int result)
{
    if(result) {
        int row = _entitiesTableView -> currentIndex().row();
        _entity = new Model::Domain::Entity(*(_entityModel -> entities() -> at(row)));
    }

    QDialog::done(result);
}

Model::Domain::Entity *View::Management::EntitySelector::entity() const
{
    return _entity;
}

bool View::Management::EntitySelector::created() const
{
    return _created;
}

void View::Management::EntitySelector::rowSelectionChanged()
{
    int row = _entitiesTableView -> currentIndex().row();
    _selectButton -> setEnabled(row != -1);
}

void View::Management::EntitySelector::createEntity()
{
    Model::Domain::Entity *entity = new Model::Domain::Entity(NO_ID);
    EntityDialog dialog(entity, this);

    if(dialog.exec()) {
        if(Model::Management::EntityManager::create(*entity)) {
            int row = _entitiesTableView -> currentIndex().row();
            _entityModel -> insertEntity(row + 1, entity);
            QModelIndex index = _entityModel -> index(row + 1, ColumnEntityId);
            _entitiesTableView -> setCurrentIndex(index);
            _created = true;
            QDialog::accept();
        } else {
            QMessageBox::critical(this, trUtf8("Error"),
                                  trUtf8("Error al añadir la entidad"),
                                  QMessageBox::Ok);
            delete entity;
        }
    } else
        delete entity;
}

void View::Management::EntitySelector::createWidgets()
{
    _entitiesTableView = new QTableView;
    _entityModel = new EntityModel(Model::Management::EntityManager::getAll());
    _entitiesTableView -> setModel(_entityModel);
    _entitiesTableView -> setAlternatingRowColors(true);
    _entitiesTableView -> setShowGrid(false);
    _entitiesTableView -> setColumnWidth(ColumnEntityId, COLUMN_ENTITY_ID_WIDTH);
    _entitiesTableView -> setColumnWidth(ColumnEntityName, COLUMN_ENTITY_NAME_WIDTH);
    _entitiesTableView -> setColumnWidth(ColumnEntityFolio, COLUMN_ENTITY_FOLIO_WIDTH);
    _entitiesTableView -> setSelectionMode(QAbstractItemView::SingleSelection);
    _entitiesTableView -> setSelectionBehavior(QAbstractItemView::SelectRows);
    _entitiesTableView -> setEditTriggers(QAbstractItemView::NoEditTriggers);
    _entitiesTableView -> setFocusPolicy(Qt::NoFocus);

    QHBoxLayout *topLayout = new QHBoxLayout;
    topLayout -> addWidget(_entitiesTableView);

    QGroupBox *entitiesGroupBox = new QGroupBox(trUtf8("Lista de entidades"));
    entitiesGroupBox -> setLayout(topLayout);

    _createButton = new QPushButton(trUtf8("Crear"));
    _createButton -> setIcon(QIcon(":/images/entity.png"));
    _createButton -> setVisible(_behavior == CreateAndSelect);

    _selectButton = new QPushButton(trUtf8("&Seleccionar"));
    _selectButton -> setIcon(QIcon(":/images/ok.png"));
    _selectButton -> setDefault(true);
    _selectButton -> setEnabled(false);

    _cancelButton = new QPushButton(trUtf8("&Cancelar"));
    _cancelButton -> setIcon(QIcon(":/images/cancel.png"));

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout -> addWidget(_createButton);
    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_selectButton);
    bottomLayout -> addWidget(_cancelButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addWidget(entitiesGroupBox);
    mainLayout -> addLayout(bottomLayout);

    setLayout(mainLayout);
}


void View::Management::EntitySelector::createConnections()
{
    connect(_entitiesTableView -> selectionModel(), SIGNAL(selectionChanged(QItemSelection,QItemSelection)),
            this, SLOT(rowSelectionChanged()));
    connect(_entitiesTableView, SIGNAL(doubleClicked(QModelIndex)),
            this, SLOT(accept()));
    connect(_createButton, SIGNAL(clicked()),
            this, SLOT(createEntity()));
    connect(_selectButton, SIGNAL(clicked()),
            this, SLOT(accept()));
    connect(_cancelButton, SIGNAL(clicked()),
            this, SLOT(reject()));
}
