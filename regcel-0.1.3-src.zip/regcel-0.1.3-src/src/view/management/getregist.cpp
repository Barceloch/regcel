/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "entitymanager.h"
#include "registmanager.h"
#include "registmodel.h"
#include "registeditor.h"
#include "entity.h"
#include "getregist.h"
#include "types.h"
#include <QtGui>

View::Management::GetRegist::GetRegist(int &model, int &entityId, QDate &beginDate, QDate &endDate, QWidget *parent)
    : QDialog(parent), _model(model), _entityId(entityId), _beginDate(beginDate), _endDate(endDate)
{

    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Búscar Registros"));
    setWindowIcon(QIcon(":/images/search.png"));
    setFixedSize(sizeHint());
    giveModel = 0;

}
void View::Management::GetRegist::done(int result)
{
    if(result)
        getModel(giveModel);

    QDialog::done(result);
}

void View::Management::GetRegist::getModel(int giveModel){
    switch(giveModel) {
    case 0:{
       _model = 0;
        break;
        }
    case 1:{
       _model = 1;
        getEntityId();
        break;
        }
    case 2:{
        _model = 2;
        getBeginDate();
        getEndDate();
        break;
        }
    case 3:{
        _model = 3;
        getEntityId();
        getBeginDate();
        getEndDate();
        break;
        }
    }
}

void View::Management::GetRegist::getModeSelected()
{

    switch(_getByComboBox->currentIndex()) {
    case 0:{
        _entityComboBox->setEnabled(false);
        _beginDateDateEdit->setEnabled(false);
        _endDateDateEdit->setEnabled(false);
        giveModel = 0;
        break;
        }
    case 1:{
        _entityComboBox->setEnabled(_getByComboBox->currentIndex() == 1);
        _beginDateDateEdit->setEnabled(false);
        _endDateDateEdit->setEnabled(false);
        giveModel = 1;
        break;
        }
    case 2:{
        _entityComboBox->setEnabled(false);
        _beginDateDateEdit->setEnabled(_getByComboBox->currentIndex() == 2);
        _endDateDateEdit->setEnabled(_getByComboBox->currentIndex() == 2);
        giveModel = 2;
        break;
        }
    case 3:{
        _entityComboBox->setEnabled(_getByComboBox->currentIndex() == 3);
        _beginDateDateEdit->setEnabled(_getByComboBox->currentIndex() == 3);
        _endDateDateEdit->setEnabled(_getByComboBox->currentIndex() == 3);
        giveModel = 3;
        break;
        }
    }
}

void View::Management::GetRegist::getEntityId(){
    _entityId = Model::Management::EntityManager::get(
                                             Model::Management::EntityManager::getAllNames()
                                            .value(_entityComboBox -> currentText()))->id();
}
void View::Management::GetRegist::getBeginDate(){
    _beginDate = _beginDateDateEdit->date();
}
void View::Management::GetRegist::getEndDate(){
     _endDate = _endDateDateEdit->date();
}

void View::Management::GetRegist::createWidgets()
{
    _getByLabel = new QLabel(trUtf8("&Buscar: "));
    _getByComboBox = new QComboBox;
    QStringList modes;
    _getByComboBox->addItems(modes << "Todos..." << "Por entidad"<< "Por fecha"<< "Por entidad y fecha");
    _getByLabel -> setBuddy(_getByComboBox);


    _entityLabel = new QLabel(trUtf8("&Entidad:"));
    _entityComboBox = new QComboBox;
    _entityComboBox -> addItems(Model::Management::EntityManager::getAllNames().keys());
    _entityComboBox->setEnabled(false);
    _entityLabel -> setBuddy(_entityComboBox);

    _beginDateLabel = new QLabel(trUtf8("&Fecha Inicial:"));
    _beginDateDateEdit = new QDateEdit;
    _beginDateDateEdit->setDisplayFormat(DATE_FORMAT);
    _beginDateDateEdit->setDate(QDate::currentDate());
    _beginDateDateEdit->setAlignment(Qt::AlignCenter);
    _beginDateDateEdit->setCalendarPopup(true);
    _beginDateDateEdit->setEnabled(false);
    _beginDateLabel -> setBuddy(_beginDateDateEdit);

    _endDateLabel = new QLabel(trUtf8("&Fecha Final:"));
    _endDateDateEdit = new QDateEdit;
    _endDateDateEdit->setDisplayFormat(DATE_FORMAT);
    _endDateDateEdit->setDate(QDate::currentDate());
    _endDateDateEdit->setAlignment(Qt::AlignCenter);
    _endDateDateEdit->setCalendarPopup(true);
    _endDateDateEdit->setEnabled(false);
    _endDateLabel -> setBuddy(_endDateDateEdit);

    QGridLayout *valuesLayout = new QGridLayout;
    valuesLayout -> addWidget(_entityLabel, 0, 0, 1, 1);
    valuesLayout -> addWidget(_entityComboBox, 0, 1, 1, 1);
    valuesLayout -> addWidget(_beginDateLabel, 1, 0, 1, 1);
    valuesLayout -> addWidget(_endDateLabel, 1, 1, 1, 1);
    valuesLayout -> addWidget(_beginDateDateEdit, 2, 0, 1, 1);
    valuesLayout -> addWidget(_endDateDateEdit, 2, 1, 1, 1);

    QGroupBox *valuesGroupBox = new QGroupBox(trUtf8("&Parámetros de búsqueda"));
    valuesGroupBox -> setLayout(valuesLayout);

    QGridLayout *topLayout = new QGridLayout;
    topLayout -> addWidget(_getByLabel, 0, 0, 1, 1);
    topLayout -> addWidget(_getByComboBox, 0, 1, 1, 1);
    topLayout -> addWidget(valuesGroupBox, 1, 0, 1, 3);

    _getButton = new QPushButton(trUtf8("&Buscar"));
    _getButton -> setIcon(QIcon(":/images/search.png"));
    _getButton -> setDefault(true);
    _cancelButton = new QPushButton(trUtf8("&Cancelar"));
    _cancelButton -> setIcon(QIcon(":/images/cancel.png"));

    QHBoxLayout *bottomLayout = new QHBoxLayout;

    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_getButton);
    bottomLayout -> addWidget(_cancelButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;

    mainLayout -> addLayout(topLayout);
    mainLayout -> addLayout(bottomLayout);

    setLayout(mainLayout);
}


void View::Management::GetRegist::createConnections()
{
    connect(_getByComboBox, SIGNAL(currentIndexChanged(int)),
            this, SLOT(getModeSelected()));
    connect(_entityComboBox, SIGNAL(currentIndexChanged(int)),
            this, SLOT(getEntityId()));
    connect(_beginDateDateEdit, SIGNAL(dateChanged(QDate)),
            this, SLOT(getBeginDate()));
    connect(_endDateDateEdit, SIGNAL(dateChanged(QDate)),
            this, SLOT(getEndDate()));
    connect(_getButton, SIGNAL(clicked()),
            this, SLOT(accept()));
    connect(_cancelButton, SIGNAL(clicked()),
            this, SLOT(reject()));
}



