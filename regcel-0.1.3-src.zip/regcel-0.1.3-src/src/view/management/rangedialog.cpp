/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "rangedialog.h"
#include "ratedialog.h"
#include "range.h"
#include "rangemanager.h"
#include "ratemanager.h"
#include "persistencemanager.h"
#include "types.h"
#include <QtGui>

View::Management::RangeDialog::RangeDialog(Model::Domain::Range *range, int rateId, QWidget *parent)
    : QDialog(parent), _range(range), _rateId(rateId)
{
    _precisionMoney = MAX_MONEY_PRECISION;

    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Range")+"[*]");
    resize(350, 50);
    loadRange();

}

void View::Management::RangeDialog::done(int result)
{
    if(result)
        saveRange();

    QDialog::done(result);
}

void View::Management::RangeDialog::rangeModified(bool modified)
{
    setWindowModified(modified);
    _saveButton -> setEnabled(isSaveable() && modified);
}

void View::Management::RangeDialog::createWidgets()
{
    _idLabel = new QLabel(trUtf8("&Id:"));
    _idLineEdit = new QLineEdit;
    _idLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _idLineEdit ->setReadOnly(true);
    _idLabel -> setBuddy(_idLineEdit);

    _rateLabel = new QLabel(trUtf8("&TarifaID:"));
    _rateLineEdit = new QLineEdit;
    _rateLineEdit ->setText(QString::number(_rateId));
    _rateLineEdit->setEnabled(false);
    _rateLabel -> setBuddy(_rateLineEdit);

    _fromLabel = new QLabel(trUtf8("&De"));
    _fromLineEdit = new QLineEdit;
    _fromLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _fromLineEdit->setReadOnly(true);
    _fromLabel -> setBuddy(_fromLineEdit);

    _toLabel = new QLabel(trUtf8("Hasta: "));
    _toLineEdit = new QLineEdit;
    _toLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _toLabel -> setBuddy(_toLineEdit);

    _priceLabel = new QLabel(trUtf8("&Valen:"));
    _priceLineEdit = new QLineEdit;
    _priceLineEdit -> setValidator(new QRegExpValidator(QRegExp("[0-9]+(.[0-9]+)?"), this));
    _priceLabel -> setBuddy(_priceLineEdit);

    QHBoxLayout *rangeValuesLayout = new QHBoxLayout;
    rangeValuesLayout->addWidget(_fromLabel);
    rangeValuesLayout->addWidget(_fromLineEdit);
    rangeValuesLayout->addWidget(_toLabel);
    rangeValuesLayout->addWidget(_toLineEdit);
    rangeValuesLayout->addWidget(_priceLabel);
    rangeValuesLayout->addWidget(_priceLineEdit);

    QGroupBox *valuesGroupBox = new QGroupBox(trUtf8("&Valores del rango"));
    valuesGroupBox -> setLayout(rangeValuesLayout);

    QGridLayout *topLayout = new QGridLayout;
    topLayout -> addWidget(_idLabel, 0, 0, 1, 1);
    topLayout -> addWidget(_rateLabel, 0, 2, 1, 1);
    topLayout -> addWidget(_idLineEdit, 1, 0, 1, 1);
    topLayout -> addWidget(_rateLineEdit, 1, 2, 1, 3);
    topLayout -> addWidget(valuesGroupBox, 2, 0, 1, 0);

    _saveButton = new QPushButton(trUtf8("&Guardar"));
    _saveButton -> setIcon(QIcon(":/images/save.png"));
    _saveButton -> setDefault(true);
    _saveButton -> setEnabled(false);
    _cancelButton = new QPushButton(trUtf8("&Cancelar"));
    _cancelButton -> setIcon(QIcon(":/images/cancel.png"));

    QHBoxLayout *bottomLayout = new QHBoxLayout;

    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_saveButton);
    bottomLayout -> addWidget(_cancelButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;

    mainLayout -> addLayout(topLayout);
    mainLayout -> addLayout(bottomLayout);

    setLayout(mainLayout);
}



void View::Management::RangeDialog::createConnections()
{
    connect(_fromLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(rangeModified()));
    connect(_toLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(rangeModified()));
    connect(_priceLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(rangeModified()));
    connect(_saveButton, SIGNAL(clicked()),
            this, SLOT(accept()));
    connect(_cancelButton, SIGNAL(clicked()),
            this, SLOT(reject()));
}

void View::Management::RangeDialog::loadRange()
{
    QList<Model::Domain::Range *> *ranges = Model::Management::RangeManager::getByRate(_rateId);

    _idLineEdit -> setText(IS_NEW(_range -> id()) ? QString::number(Model::Management::RangeManager::getId()) :
                                                          QString::number(_range -> id()));
    _fromLineEdit->setText(QString::number(!ranges->isEmpty() ? ranges->takeLast()->toNumber() + 1 : 0));
    _toLineEdit->setText(QString::number(_range->toNumber()));
    _priceLineEdit -> setText(QString::number(_range->price(),'f', _precisionMoney));

    rangeModified(false);
}

void View::Management::RangeDialog::saveRange()
{

    _range -> setId(_idLineEdit -> text().toInt());
    _range -> setRate(Model::Management::RateManager::get(_rateLineEdit ->text().toInt()));
    _range ->setFromNumber(_fromLineEdit->text().toInt());
    _range ->setToNumber(_toLineEdit->text().toInt());
    _range ->setPrice(_priceLineEdit -> text().toDouble());

}
bool View::Management::RangeDialog::isSaveable()
{
    return !(_idLineEdit -> text().isEmpty()) &&
           !(_fromLineEdit -> text().isEmpty()) &&
           !(_toLineEdit -> text().isEmpty()) &&
           !(_priceLineEdit -> text().isEmpty()) &&
           (_toLineEdit->text().toInt() > _fromLineEdit->text().toInt());
}
