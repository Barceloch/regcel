/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "rangeseditor.h"
#include "rateseditor.h"
#include "rangemodel.h"
#include "rangemanager.h"
#include "rangedialog.h"
#include "range.h"
#include <QtGui>

View::Management::RangesEditor::RangesEditor(int rateId, QWidget *parent)
    : QWidget(parent), _rateId(rateId)
{
    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Editor de Rangos"));
    setWindowIcon(QIcon(":/images/unpaid.png"));
    //setMinimumWidth(RANGES_EDITOR_MINIMUM_WIDTH);
}

View::Management::RangesEditor::~RangesEditor()
{
    delete _rangeModel;
}

void View::Management::RangesEditor::rowSelectionChanged()
{
    int row = _rangesTableView -> currentIndex().row();
    _modRangeButton -> setEnabled(row != -1);
    _delRangeButton -> setEnabled(row != -1);
}

void View::Management::RangesEditor::addRange()
{
    Model::Domain::Range *range = new Model::Domain::Range;
    RangeDialog dialog(range, _rateId, this);

    if(dialog.exec()) {
        if(Model::Management::RangeManager::create(*range)) {
            int row = _rangeModel -> rowCount(QModelIndex());
            _rangeModel -> insertRange(row, range);
        } else {
            QMessageBox::critical(this, trUtf8("Error"),
                                  trUtf8("Error añadiendo el rango"),
                                  QMessageBox::Ok);
            delete range;
        }
        emit rangeSaved();
        rowSelectionChanged();
    } else
        delete range;
}

void View::Management::RangesEditor::modRange()
{
    int row = _rangesTableView -> currentIndex().row();
    Model::Domain::Range *range = _rangeModel -> ranges() -> at(row);
    RangeDialog dialog(range, _rateId, this);

    if(dialog.exec()) {
        if(Model::Management::RangeManager::modify(*range))
            _rangeModel -> modifyRange(row);
        else
            QMessageBox::critical(this, trUtf8("Error"),
                                  trUtf8("Error modificando el rango"),
                                  QMessageBox::Ok);
        emit rangeSaved();
        rowSelectionChanged();
    }

}

void View::Management::RangesEditor::delRange()
{
    if(!verifyDeleteRange())
        return;

    int row = _rangesTableView -> currentIndex().row();
    Model::Management::RangeManager::remove(_rangeModel -> ranges() -> at(row) -> id());
    _rangeModel -> removeRange(row);
    emit rangeSaved();
    rowSelectionChanged();

}


void View::Management::RangesEditor::createWidgets()
{
    createRangeWidgets();

    rangesbuttonLayout = new QVBoxLayout;
    rangesbuttonLayout->addStretch();
    rangesbuttonLayout->addWidget(_addRangeButton);
    rangesbuttonLayout->addWidget(_modRangeButton);
    rangesbuttonLayout->addWidget(_delRangeButton);
    rangesbuttonLayout->addStretch();


    QGridLayout *rangesLayout = new QGridLayout;
    rangesLayout -> addWidget(_rangesTableView, 0, 0, 1, 1);
    rangesLayout -> addLayout(rangesbuttonLayout, 0, 1, 1, 1);


    QGroupBox *rangesGroupBox = new QGroupBox(trUtf8("&Lista de rangos"));
    rangesGroupBox -> setLayout(rangesLayout);


    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addWidget(rangesGroupBox);
    setLayout(mainLayout);

}

void View::Management::RangesEditor::createRangeWidgets()
{
    _rangesTableView = new QTableView;
    //_rangeModel = new RangeModel(Model::Management::RangeManager::getAll());
    _rangeModel = new RangeModel(Model::Management::RangeManager::getByRate(_rateId));
    _rangesTableView -> setModel(_rangeModel);
    //_rangesTableView -> setAlternatingRowColors(true);
    _rangesTableView -> setShowGrid(false);
    _rangesTableView -> setColumnWidth(ColumnRangeId, COLUMN_RANGE_ID_WIDTH);
    _rangesTableView -> setColumnWidth(ColumnRangeFromNumber, COLUMN_RANGE_FROMNUMBER_WIDTH);
    _rangesTableView -> setColumnWidth(ColumnRangeToNumber, COLUMN_RANGE_TONUMBER_WIDTH);
    _rangesTableView -> setColumnWidth(ColumnRangePrice, COLUMN_RANGE_PRICE_WIDTH);   
    _rangesTableView->setColumnHidden(ColumnRangeId, true);
    _rangesTableView -> setSelectionMode(QAbstractItemView::SingleSelection);
    _rangesTableView -> setSelectionBehavior(QAbstractItemView::SelectRows);
    _rangesTableView -> setEditTriggers(QAbstractItemView::NoEditTriggers);
    _rangesTableView -> setFocusPolicy(Qt::NoFocus);

    _addRangeButton = new QPushButton(trUtf8("&Añadir"));
    _addRangeButton -> setIcon(QIcon(":/images/add.png"));
    _modRangeButton = new QPushButton(trUtf8("E&ditar"));
    _modRangeButton -> setIcon(QIcon(":/images/modify.png"));
    _modRangeButton -> setEnabled(false);
    _delRangeButton = new QPushButton(trUtf8("&Eliminar"));
    _delRangeButton -> setIcon(QIcon(":/images/delete.png"));
    _delRangeButton -> setEnabled(false);
}


void View::Management::RangesEditor::createConnections()
{
    connect(_rangesTableView -> selectionModel(), SIGNAL(selectionChanged(QItemSelection, QItemSelection)),
            this, SLOT(rowSelectionChanged()));
    connect(_rangesTableView, SIGNAL(doubleClicked(QModelIndex)),
            this, SLOT(modRange()));
    connect(_addRangeButton, SIGNAL(clicked()),
            this, SLOT(addRange()));
    connect(_modRangeButton, SIGNAL(clicked()),
            this, SLOT(modRange()));
    connect(_delRangeButton, SIGNAL(clicked()),
            this, SLOT(delRange()));
}

bool View::Management::RangesEditor::verifyDeleteRange()
{
    return QMessageBox::question(this, trUtf8("Confirmar Eliminación"),
                                       trUtf8("Todos los valores de este rango serán eliminados.\n"
                                          "¿desea continuar?"),
                                       QMessageBox::Yes | QMessageBox::Default |
                                       QMessageBox::No) == QMessageBox::Yes;
}

