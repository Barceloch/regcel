/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "ratedialog.h"
#include "rate.h"
#include "ratemanager.h"
#include "rangeseditor.h"
#include "rangemanager.h"
#include "persistencemanager.h"
#include "types.h"
#include <QtGui>

View::Management::RateDialog::RateDialog(Model::Domain::Rate *rate, int rateId, bool showR, QWidget *parent)
    : QDialog(parent), _rate(rate), _rateId(rateId), _showR(showR)
{
    _precisionMoney = MAX_MONEY_PRECISION;

    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Tarifa")+"[*]");
    setFixedSize(sizeHint());
    loadRate();

}

void View::Management::RateDialog::done(int result)
{
    if(result)
        saveRate();

    QDialog::done(result);
}


void View::Management::RateDialog::rateModified(bool modified)
{
    setWindowModified(modified);
    _saveButton -> setEnabled(isSaveable() && modified);

}

void View::Management::RateDialog::createWidgets()
{
    _idLabel = new QLabel(trUtf8("&Id:"));
    _idLineEdit = new QLineEdit;
    _idLineEdit -> setValidator(new QRegExpValidator(QRegExp("[1-9][0-9]*"), this));
    _idLineEdit ->setReadOnly(true);
    _idLabel -> setBuddy(_idLineEdit);


    _nameLabel = new QLabel(trUtf8("&Nombre:"));
    _nameLineEdit = new QLineEdit;
    _nameLabel -> setBuddy(_nameLineEdit);

    _descriptionLabel = new QLabel(trUtf8("&Descripción:"));
    _descriptionTextEdit = new QTextEdit;
    _descriptionLabel -> setBuddy(_descriptionTextEdit);
    _descriptionTextEdit->setMaximumHeight(50);

    _moreofLabel = new QLabel(trUtf8("Más de: "));
    _moreofLineEdit = new QLineEdit;
    _moreofLineEdit->setReadOnly(true);
    _moreofLabel -> setBuddy(_moreofLineEdit);

    _priceLabel = new QLabel(trUtf8("&Valen:"));
    _priceLineEdit = new QLineEdit;
    _priceLineEdit -> setValidator(new QRegExpValidator(QRegExp("[0-9]+(.[0-9]+)?"), this));
    _priceLabel -> setBuddy(_priceLineEdit);

    QHBoxLayout *endRangeLayout = new QHBoxLayout;
    endRangeLayout->addWidget(_moreofLabel);
    endRangeLayout->addWidget(_moreofLineEdit);
    endRangeLayout->addWidget(_priceLabel);
    endRangeLayout->addWidget(_priceLineEdit);


    createRangesWidgets();

    QGridLayout *topLayout = new QGridLayout;
    topLayout -> addWidget(_idLabel, 0, 0, 1, 1);
    topLayout -> addWidget(_idLineEdit, 0, 1, 1, 3);

    topLayout -> addWidget(_nameLabel, 1, 0, 1, 1);
    topLayout -> addWidget(_nameLineEdit, 1, 1, 1, 3);

    topLayout -> addWidget(_descriptionLabel, 2, 0, 1, 2);
    topLayout -> addWidget(_descriptionTextEdit, 3, 0, 1, 4);

    if (_showR == true) {
        topLayout -> addWidget(_rangesEditor, 4, 0, 1, 0);
        topLayout -> addLayout(endRangeLayout, 5, 0, 1, 0);
    }
    _saveButton = new QPushButton(trUtf8("&Guardar"));
    _saveButton -> setIcon(QIcon(":/images/save.png"));
    _saveButton -> setDefault(true);
    _saveButton -> setEnabled(false);
    _cancelButton = new QPushButton(trUtf8("&Cancelar"));
    _cancelButton -> setIcon(QIcon(":/images/cancel.png"));

    QHBoxLayout *bottomLayout = new QHBoxLayout;

    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_saveButton);
    bottomLayout -> addWidget(_cancelButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;

    mainLayout -> addLayout(topLayout);
    mainLayout -> addLayout(bottomLayout);

    setLayout(mainLayout);
}

void View::Management::RateDialog::createRangesWidgets()
{
    _rangesEditor = new RangesEditor(_rateId);
    connect(_rangesEditor, SIGNAL(rangeSaved()),
            this, SLOT(rateModified()));
    connect(_rangesEditor, SIGNAL(rangeSaved()),
            this, SLOT(moreOf()));
}
void View::Management::RateDialog::moreOf()
{
    QList<Model::Domain::Range *> *ranges = Model::Management::RangeManager::getByRate(_rateId);
    if (!ranges->isEmpty())
        _moreofLineEdit->setText(QString::number(ranges->takeLast()->toNumber()));
    else
        _moreofLineEdit->setText(QString::number(0));
}

void View::Management::RateDialog::createConnections()
{
    connect(_nameLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(rateModified()));
    connect(_descriptionTextEdit, SIGNAL(textChanged()),
            this, SLOT(rateModified()));
    connect(_moreofLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(rateModified()));
    connect(_priceLineEdit, SIGNAL(textChanged(QString)),
            this, SLOT(rateModified()));
    connect(_saveButton, SIGNAL(clicked()),
            this, SLOT(accept()));
    connect(_cancelButton, SIGNAL(clicked()),
            this, SLOT(reject()));

}

void View::Management::RateDialog::loadRate()
{
    _idLineEdit -> setText(IS_NEW(_rate -> id()) ? QString::number(Model::Management::RateManager::getId()) :
                                                      QString::number(_rate -> id()));
    _nameLineEdit -> setText(_rate->name());
    _descriptionTextEdit -> setPlainText(_rate->description());
    _moreofLineEdit->setText(QString::number(_rate->moreofNumber()));
    _priceLineEdit -> setText(QString::number(_rate->moreofPrice(),'f', _precisionMoney));

    rateModified(false);
}

void View::Management::RateDialog::saveRate()
{
    _rate -> setId(_idLineEdit -> text().toInt());
    _rate -> setName(_nameLineEdit -> text());
    _rate -> setDescription(_descriptionTextEdit -> toPlainText());
    _rate ->setMoreOfNumber(_moreofLineEdit->text().toInt());
    _rate->setMoreOfPrice(_priceLineEdit -> text().toDouble());

}
bool View::Management::RateDialog::isSaveable()
{
    return !(_idLineEdit -> text().isEmpty()) &&
           !(_nameLineEdit -> text().isEmpty()) &&
           !(_moreofLineEdit -> text().isEmpty()) &&
           !(_priceLineEdit -> text().isEmpty());
}
bool View::Management::RateDialog::itemsEnable()
{
    return !(_nameLineEdit -> text().isEmpty());
}
