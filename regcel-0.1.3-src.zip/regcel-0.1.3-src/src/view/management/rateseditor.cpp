/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "rateseditor.h"
#include "ratemodel.h"
#include "rangemodel.h"
#include "ratemanager.h"
#include "rangemanager.h"
#include "ratedialog.h"
#include "rate.h"
#include <QtGui>

View::Management::RatesEditor::RatesEditor(QWidget *parent)
    : QWidget(parent)
{
    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Editor de tarifas"));
    setWindowIcon(QIcon(":/images/unpaid.png"));
    setMinimumWidth(RATES_EDITOR_MINIMUM_WIDTH);
    setAttribute(Qt::WA_DeleteOnClose);
}

View::Management::RatesEditor::~RatesEditor()
{
    delete _rateModel;
}

void View::Management::RatesEditor::closeEvent(QCloseEvent *event)
{
    emit finished();
    event->accept();

}

void View::Management::RatesEditor::rowSelectionChanged()
{
    int row = _ratesTableView -> currentIndex().row();
    _modRateButton -> setEnabled(row != -1);
    _delRateButton -> setEnabled(row != -1);
}

void View::Management::RatesEditor::addRate()
{
    Model::Domain::Rate *rate = new Model::Domain::Rate;
    int rateId = Model::Management::RateManager::getId();
    bool showR = false;
    RateDialog dialog(rate, rateId, showR, this);

    if(dialog.exec()) {
        if(Model::Management::RateManager::create(*rate)) {
            int row = _rateModel -> rowCount(QModelIndex());
            _rateModel -> insertRate(row, rate);

        } else {
            QMessageBox::critical(this, trUtf8("Error"),
                                  trUtf8("Error añadiendo la tarifa"),
                                  QMessageBox::Ok);
            delete rate;
        }

        rowSelectionChanged();
    } else
        delete rate;
}

void View::Management::RatesEditor::modRate()
{  
    int row = _ratesTableView -> currentIndex().row();
    Model::Domain::Rate *rate = _rateModel -> rates() -> at(row);

    int rateId = rate->id();
    bool showR = true;

    RateDialog dialog(rate, rateId, showR, this);

    if(dialog.exec()) {
        if(Model::Management::RateManager::modify(*rate))
            _rateModel -> modifyRate(row);
        else
            QMessageBox::critical(this, trUtf8("Error"),
                                  trUtf8("Error midificando la tarifa"),
                                  QMessageBox::Ok);

        rowSelectionChanged();
    }

}

void View::Management::RatesEditor::delRate()
{
    if(!verifyDeleteRate())
        return;

    int row = _ratesTableView -> currentIndex().row();
    QList<Model::Domain::Range *> *oldRanges = Model::Management::RangeManager::getByRate(_rateModel -> rates() -> at(row) -> id());
    delete oldRanges;

    Model::Management::RateManager::remove(_rateModel -> rates() -> at(row) -> id());
    _rateModel -> removeRate(row);
    rowSelectionChanged();
}


void View::Management::RatesEditor::createWidgets()
{
    createRateWidgets();

    QGridLayout *ratesLayout = new QGridLayout;
    ratesLayout -> addWidget(_ratesTableView, 0, 0, 1, 6);
    ratesLayout -> addWidget(_addRateButton, 1, 3, 1, 1);
    ratesLayout -> addWidget(_modRateButton, 1, 4, 1, 1);
    ratesLayout -> addWidget(_delRateButton, 1, 5, 1, 1);

    QGroupBox *ratesGroupBox = new QGroupBox(trUtf8("&Lista de tarifas"));
    ratesGroupBox -> setLayout(ratesLayout);


    _closeButton = new QPushButton(trUtf8("&Cerrar"));
    _closeButton -> setIcon(QIcon(":/images/ok.png"));
    _closeButton -> setFixedSize(_closeButton -> sizeHint());

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout -> addStretch();
    bottomLayout -> addWidget(_closeButton);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addWidget(ratesGroupBox);
    mainLayout -> addLayout(bottomLayout);

    setLayout(mainLayout);

}

void View::Management::RatesEditor::createRateWidgets()
{
    _ratesTableView = new QTableView;
    _rateModel = new RateModel(Model::Management::RateManager::getAll());
    _ratesTableView -> setModel(_rateModel);
    //_ratesTableView -> setAlternatingRowColors(true);
    _ratesTableView -> setShowGrid(false);
    _ratesTableView -> setColumnWidth(ColumnRateId, COLUMN_RATE_ID_WIDTH);
    _ratesTableView -> setColumnWidth(ColumnRateName, COLUMN_RATE_NAME_WIDTH);
    _ratesTableView -> setSelectionMode(QAbstractItemView::SingleSelection);
    _ratesTableView -> setSelectionBehavior(QAbstractItemView::SelectRows);
    _ratesTableView -> setEditTriggers(QAbstractItemView::NoEditTriggers);
    _ratesTableView -> setFocusPolicy(Qt::NoFocus);

    _addRateButton = new QPushButton(trUtf8("&Añadir"));
    _addRateButton -> setIcon(QIcon(":/images/add.png"));
    _modRateButton = new QPushButton(trUtf8("E&ditar"));
    _modRateButton -> setIcon(QIcon(":/images/modify.png"));
    _modRateButton -> setEnabled(false);
    _delRateButton = new QPushButton(trUtf8("&Eliminar"));
    _delRateButton -> setIcon(QIcon(":/images/delete.png"));
    _delRateButton -> setEnabled(false);
}


void View::Management::RatesEditor::createConnections()
{
    connect(_ratesTableView -> selectionModel(), SIGNAL(selectionChanged(QItemSelection, QItemSelection)),
            this, SLOT(rowSelectionChanged()));
    connect(_ratesTableView, SIGNAL(doubleClicked(QModelIndex)),
            this, SLOT(modRate()));
    connect(_addRateButton, SIGNAL(clicked()),
            this, SLOT(addRate()));
    connect(_modRateButton, SIGNAL(clicked()),
            this, SLOT(modRate()));
    connect(_delRateButton, SIGNAL(clicked()),
            this, SLOT(delRate()));
    connect(_closeButton, SIGNAL(clicked()),
            this, SLOT(close()));
}

bool View::Management::RatesEditor::verifyDeleteRate()
{
    return QMessageBox::question(this, trUtf8("Confirmar eliminación"),
                                       trUtf8("Todos los rangos de esta tarifa serán aliminados.\n"
                                          "¿desea continuar?"),
                                       QMessageBox::Yes | QMessageBox::Default |
                                       QMessageBox::No) == QMessageBox::Yes;
}


