/**
*   Copyright © (2021) - Yunior Barceló Chávez - barceloch@gmail.com
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.
**/

#include "rateviewer.h"
#include "rangemanager.h"
#include "rangemodel.h"
#include "range.h"
#include "rate.h"
#include "types.h"
#include <QtGui>

View::Management::RateViewer::RateViewer(Model::Domain::Rate *rate, QWidget *parent)
    : QDialog(parent), _rate(rate)
{
    createWidgets();
    createConnections();
    setWindowTitle(trUtf8("Rangos de la Tarifa"));
    //setWindowIcon(QIcon(":/images/unpaid.png"));
    setMinimumWidth(RATE_VIEWER_MINIMUM_WIDTH);
}

void View::Management::RateViewer::createWidgets()
{
    createRangeWidgets();

    QGridLayout *rangesLayout = new QGridLayout;
    rangesLayout -> addWidget(_rangesTableView, 0, 0, 1, 1);

    QGridLayout *moreOfLayout = new QGridLayout;
    moreOfLayout -> addWidget(_moreOfLabel,             0, 0, 1, 1);
    moreOfLayout -> addWidget(_moreOf,                  0, 1, 1, 1);
    moreOfLayout -> addWidget(_moreOfPriceLabel,        0, 2, 1, 1);
    moreOfLayout -> addWidget(_moreOfPrice,             0, 3, 1, 1);



    QGroupBox *rangesGroupBox = new QGroupBox(trUtf8("&Rangos"));
    rangesGroupBox -> setLayout(rangesLayout);
    //rangesGroupBox -> setLayout(moreOfLayout);

    _closeButton = new QPushButton(trUtf8("Cerrar"));
    _closeButton -> setIcon(QIcon(":/images/ok.png"));
    _closeButton -> setDefault(true);
    //_closeButton -> setFixedSize(_closeButton -> sizeHint());

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout -> addWidget(rangesGroupBox);
    mainLayout -> addLayout(moreOfLayout);
    mainLayout -> addWidget(_closeButton, 0, Qt::AlignCenter);
    setLayout(mainLayout);

}

void View::Management::RateViewer::createRangeWidgets()
{
    _rangesTableView = new QTableView;
    //_rangeModel = new RangeModel(Model::Management::RangeManager::getAll());
    _rangeModel = new RangeModel(Model::Management::RangeManager::getByRate(_rate->id()));
    _rangesTableView -> setModel(_rangeModel);
    _rangesTableView -> setAlternatingRowColors(true);
    _rangesTableView -> setShowGrid(false);
    _rangesTableView -> setColumnWidth(ColumnRangeId, COLUMN_RANGE_ID_WIDTH);
    _rangesTableView -> setColumnWidth(ColumnRangeFromNumber, COLUMN_RANGE_FROMNUMBER_WIDTH);
    _rangesTableView -> setColumnWidth(ColumnRangeToNumber, COLUMN_RANGE_TONUMBER_WIDTH);
    _rangesTableView -> setColumnWidth(ColumnRangePrice, COLUMN_RANGE_PRICE_WIDTH);
    _rangesTableView->setColumnHidden(ColumnRangeId, true);
    _rangesTableView -> setSelectionMode(QAbstractItemView::SingleSelection);
    _rangesTableView -> setSelectionBehavior(QAbstractItemView::SelectRows);
    _rangesTableView -> setEditTriggers(QAbstractItemView::NoEditTriggers);
    _rangesTableView -> setFocusPolicy(Qt::NoFocus);

    _moreOfLabel = new QLabel(trUtf8("Más de:"));
    _moreOf = new QLineEdit;
    _moreOf -> setText(QString("%1 Kw/h").arg(QString::number(_rate->moreofNumber())));
    _moreOf->setReadOnly(true);
    _moreOf -> setAlignment(Qt::AlignCenter);
    _moreOfLabel->setBuddy(_moreOf);

    _moreOfPriceLabel = new QLabel(trUtf8("valen:"));
    _moreOfPrice = new QLineEdit;
    _moreOfPrice->setText(QString("%1 $").arg(QString::number(_rate->moreofPrice(),'f',MAX_MONEY_PRECISION)));
    _moreOfPrice->setReadOnly(true);
    _moreOfPrice -> setAlignment(Qt::AlignCenter);
    _moreOfPriceLabel->setBuddy(_moreOfPrice);

}


void View::Management::RateViewer::createConnections()
{
    connect(_closeButton, SIGNAL(clicked()),
            this, SLOT(accept()));
}



